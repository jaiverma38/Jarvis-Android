# JARVIS Android Starter (v0.1.0)

This is a source starter project, not a finished AI assistant APK.

## Included now
- Kotlin + Jetpack Compose dark interface
- Hindi speech input through Android SpeechRecognizer (requires device speech service)
- Hindi text-to-speech through Android TextToSpeech
- A few explicit local commands: greetings, current time, and opening Android Settings
- GitHub Actions workflow to build a debug APK in the cloud

## Not connected yet
- Local LLM / LiteRT-LM
- Gemini or other online AI
- Wake-word always-listening service
- Persistent conversation memory
- Advanced phone automation

These are intentionally not represented as working features yet.

## Build without a computer
1. Create a GitHub repository named `JARVIS-Android`.
2. Upload the contents of this ZIP to the repository (keep the `.github` folder).
3. Open the repository's Actions tab.
4. Select `Build JARVIS APK` and press `Run workflow`.
5. When the run completes, open it and download the `JARVIS-debug-APK` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`. Allow installation from the browser/files app when Android asks.

The workflow builds a debug APK. It is for testing, not a production release.

## Local build
A compatible Android Gradle toolchain is required. The project uses AGP 8.9.2, Gradle 8.11.1, JDK 17, and Android SDK 35.

## Security
No API key is included. Do not commit API keys, passwords, signing keys, or private information to a public repository.
