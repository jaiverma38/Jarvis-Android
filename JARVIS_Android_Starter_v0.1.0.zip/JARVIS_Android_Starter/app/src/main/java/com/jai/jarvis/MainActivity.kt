package com.jai.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.util.Locale

data class ChatLine(val from: String, val message: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var voiceResult: ((String) -> Unit)? = null

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) voiceResult?.invoke(spoken)
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchSpeech()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        setContent {
            var input by remember { mutableStateOf("") }
            val messages = remember {
                mutableStateListOf(
                    ChatLine("JARVIS", "Namaste! Main JARVIS hoon. Abhi basic voice aur phone-command prototype mode mein hoon.")
                )
            }

            fun handleCommand(raw: String) {
                val command = raw.trim()
                if (command.isEmpty()) return
                messages.add(ChatLine("YOU", command))
                val response = runLocalCommand(command)
                messages.add(ChatLine("JARVIS", response))
                speak(response)
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF56C8FF),
                    background = Color(0xFF07111F),
                    surface = Color(0xFF101E30)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF07111F)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("J.A.R.V.I.S", style = MaterialTheme.typography.headlineMedium,
                            color = Color(0xFF70D6FF))
                        Text("PERSONAL ANDROID ASSISTANT • PROTOTYPE",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.LightGray)
                        LazyColumn(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(messages) { line ->
                                val isJarvis = line.from == "JARVIS"
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = if (isJarvis) Alignment.Start else Alignment.End
                                ) {
                                    Text(line.from, color = Color(0xFF70D6FF),
                                        style = MaterialTheme.typography.labelSmall)
                                    Text(
                                        line.message,
                                        color = Color.White,
                                        modifier = Modifier
                                            .background(
                                                if (isJarvis) Color(0xFF132B43) else Color(0xFF20445D),
                                                RoundedCornerShape(14.dp)
                                            )
                                            .padding(12.dp)
                                    )
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = input,
                                onValueChange = { input = it },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("JARVIS ko command do…") },
                                singleLine = true
                            )
                            IconButton(onClick = {
                                voiceResult = { input = it; handleCommand(it); input = "" }
                                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                                    PackageManager.PERMISSION_GRANTED) {
                                    launchSpeech()
                                } else {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }) { Icon(Icons.Default.Mic, "Voice", tint = Color(0xFF70D6FF)) }
                            IconButton(onClick = {
                                val text = input
                                input = ""
                                handleCommand(text)
                            }) { Icon(Icons.Default.Send, "Send", tint = Color(0xFF70D6FF)) }
                        }
                        Text(
                            "Prototype: AI model, wake word and online API are not connected yet.",
                            color = Color.LightGray,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }

    private fun launchSpeech() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS ko bolo")
        }
        try {
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            speak("Speech recognition service available nahi hai.")
        }
    }

    private fun runLocalCommand(command: String): String {
        val lower = command.lowercase(Locale.ROOT)
        return when {
            lower.contains("open settings") || lower.contains("settings kholo") ||
                lower.contains("सेटिंग") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                "Phone settings khol raha hoon."
            }
            lower == "hello" || lower == "hi" || lower.contains("namaste") ||
                lower.contains("नमस्ते") -> "Namaste! Main sun raha hoon. Abhi main basic prototype hoon."
            lower.contains("time") || lower.contains("समय") ->
                "Phone ka current time ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())} hai."
            else -> "Ye command abhi mere prototype mein configured nahi hai. Local AI model agle development stage mein connect hoga."
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
