package com.jarvis.assistant

import com.jarvis.assistant.wake.WakeWordPipeline
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeWordPipelineTest {

    private class Spy(val score: Float) {
        var melCalls = 0
        var embedCalls = 0
        var classifyCalls = 0
        var lastMelSize = 0
        var lastEmbedSize = 0
        var lastClassifySize = 0

        fun pipeline() = WakeWordPipeline(
            mel = { x ->
                melCalls++
                lastMelSize = x.size
                FloatArray(8 * WakeWordPipeline.MEL_BINS) { 0.5f }
            },
            embed = { w ->
                embedCalls++
                lastEmbedSize = w.size
                FloatArray(WakeWordPipeline.EMB_SIZE) { 0.1f }
            },
            classify = { f ->
                classifyCalls++
                lastClassifySize = f.size
                score
            }
        )
    }

    private val silence = ShortArray(WakeWordPipeline.CHUNK)

    @Test fun warmupThenScores() {
        val spy = Spy(0.9f)
        val p = spy.pipeline()
        for (i in 1 until WakeWordPipeline.WARMUP_CHUNKS) assertEquals(0f, p.process(silence), 0f)
        assertEquals(0.9f, p.process(silence), 0f)
        assertEquals(WakeWordPipeline.WARMUP_CHUNKS, spy.melCalls)
        assertEquals(WakeWordPipeline.WARMUP_CHUNKS, spy.embedCalls)
        assertEquals(1, spy.classifyCalls)
    }

    @Test fun modelInputsHaveExpectedSizes() {
        val spy = Spy(0.1f)
        val p = spy.pipeline()
        repeat(WakeWordPipeline.WARMUP_CHUNKS) { p.process(silence) }
        assertEquals(WakeWordPipeline.CHUNK + WakeWordPipeline.CONTEXT, spy.lastMelSize)
        assertEquals(WakeWordPipeline.MEL_WINDOW * WakeWordPipeline.MEL_BINS, spy.lastEmbedSize)
        assertEquals(WakeWordPipeline.EMB_FRAMES * WakeWordPipeline.EMB_SIZE, spy.lastClassifySize)
    }

    @Test fun resetRestartsWarmup() {
        val spy = Spy(0.9f)
        val p = spy.pipeline()
        repeat(WakeWordPipeline.WARMUP_CHUNKS + 2) { p.process(silence) }
        p.reset()
        assertEquals(0f, p.process(silence), 0f)
    }

    @Test fun audioContextSlidesAcrossChunks() {
        var seen = FloatArray(0)
        val p = WakeWordPipeline(
            mel = { x -> seen = x; FloatArray(8 * WakeWordPipeline.MEL_BINS) },
            embed = { FloatArray(WakeWordPipeline.EMB_SIZE) },
            classify = { 0f }
        )
        val a = ShortArray(WakeWordPipeline.CHUNK) { 7 }
        val b = ShortArray(WakeWordPipeline.CHUNK) { 9 }
        p.process(a)
        p.process(b)
        // Latest 1760 samples: the last 480 of chunk a, then all of chunk b.
        assertEquals(7f, seen[0], 0f)
        assertEquals(7f, seen[WakeWordPipeline.CONTEXT - 1], 0f)
        assertEquals(9f, seen[WakeWordPipeline.CONTEXT], 0f)
        assertTrue(seen.size == WakeWordPipeline.CHUNK + WakeWordPipeline.CONTEXT)
    }

    @Test(expected = IllegalArgumentException::class)
    fun wrongChunkSizeIsRejected() {
        Spy(0f).pipeline().process(ShortArray(100))
    }
}
