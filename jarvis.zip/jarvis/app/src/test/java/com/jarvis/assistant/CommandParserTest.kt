package com.jarvis.assistant

import com.jarvis.assistant.actions.Action
import com.jarvis.assistant.actions.BrightnessMode
import com.jarvis.assistant.actions.CommandParser
import com.jarvis.assistant.actions.InfoTopic
import com.jarvis.assistant.actions.Risk
import com.jarvis.assistant.actions.SettingsPanel
import com.jarvis.assistant.actions.VolumeMode
import com.jarvis.assistant.actions.risk
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {

    @Test fun torchOnAndOff() {
        assertEquals(Action.Torch(true), CommandParser.parse("torch on"))
        assertEquals(Action.Torch(false), CommandParser.parse("Torch band karo"))
        assertEquals(Action.Torch(true), CommandParser.parse("hey jarvis, flashlight on"))
        assertEquals(Action.Torch(null), CommandParser.parse("torch"))
    }

    @Test fun timers() {
        assertEquals(Action.Timer(300), CommandParser.parse("timer 5 minutes"))
        assertEquals(Action.Timer(5400), CommandParser.parse("set a timer for 1 hour 30 minutes"))
        assertEquals(Action.Timer(45), CommandParser.parse("timer 45 seconds"))
        assertNull(CommandParser.parse("timer"))
    }

    @Test fun alarms() {
        assertEquals(Action.Alarm(6, 30), CommandParser.parse("alarm 6:30 am"))
        assertEquals(Action.Alarm(19, 0), CommandParser.parse("set alarm at 7 pm"))
        assertNull(CommandParser.parse("cancel alarm 7"))
    }

    @Test fun volume() {
        assertEquals(Action.Volume(VolumeMode.SET, 40), CommandParser.parse("volume 40"))
        assertEquals(Action.Volume(VolumeMode.UP, null), CommandParser.parse("volume up"))
        assertEquals(Action.Volume(VolumeMode.DOWN, null), CommandParser.parse("volume kam karo"))
        assertEquals(Action.Volume(VolumeMode.MUTE, 0), CommandParser.parse("mute"))
    }

    @Test fun brightnessNeedsConfirmation() {
        val a = CommandParser.parse("brightness 50")
        assertEquals(Action.Brightness(BrightnessMode.SET, 50), a)
        assertEquals(Risk.CONFIRM, a!!.risk())
        assertEquals(Action.Brightness(BrightnessMode.UP, null), CommandParser.parse("brightness up"))
    }

    @Test fun appsAndSettings() {
        assertEquals(Action.OpenApp("youtube"), CommandParser.parse("open youtube"))
        assertEquals(Action.OpenApp("whatsapp"), CommandParser.parse("whatsapp kholo"))
        assertEquals(Action.OpenSettings(SettingsPanel.WIFI), CommandParser.parse("open wifi settings"))
        assertEquals(Action.OpenSettings(SettingsPanel.BLUETOOTH), CommandParser.parse("open bluetooth"))
    }

    @Test fun deviceInfo() {
        assertEquals(Action.DeviceInfo(InfoTopic.BATTERY), CommandParser.parse("battery"))
        assertEquals(Action.DeviceInfo(InfoTopic.BATTERY), CommandParser.parse("what is my battery level"))
        assertEquals(Action.DeviceInfo(InfoTopic.STORAGE), CommandParser.parse("storage"))
    }

    @Test fun sensitiveActionsNeedConfirmation() {
        val dial = CommandParser.parse("call 9876543210")
        assertEquals(Action.Dial("9876543210"), dial)
        assertEquals(Risk.CONFIRM, dial!!.risk())

        val sms = CommandParser.parse("text 9876543210 saying I will be late")
        assertEquals(Action.ComposeSms("9876543210", "I will be late"), sms)
        assertEquals(Risk.CONFIRM, sms!!.risk())

        val mem = CommandParser.parse("remember that my locker code hint is blue")
        assertTrue(mem is Action.Remember)
        assertEquals(Risk.CONFIRM, mem!!.risk())

        assertEquals(Risk.CONFIRM, Action.ReadNotifications.risk())
        assertEquals(Risk.LOW, Action.Torch(true).risk())
    }

    @Test fun normalChatIsNotACommand() {
        assertNull(CommandParser.parse("what is the capital of France"))
        assertNull(CommandParser.parse("tell me a joke about batteries"))
        assertNull(CommandParser.parse("how do I open a bank account"))
        assertNull(CommandParser.parse(""))
    }

    @Test fun tooShortNumbersAreRejected() {
        assertNull(CommandParser.parse("call 123"))
    }
}
