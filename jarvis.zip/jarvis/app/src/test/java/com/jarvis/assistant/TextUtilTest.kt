package com.jarvis.assistant

import com.jarvis.assistant.util.SpeechText
import com.jarvis.assistant.util.ThinkFilter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextUtilTest {

    @Test fun removesCompleteThinkBlock() {
        assertEquals("Hello", ThinkFilter.strip("<think>reasoning here</think>Hello"))
    }

    @Test fun hidesUnfinishedThinkBlock() {
        assertEquals("", ThinkFilter.strip("<think>still thinking"))
        assertEquals("Hello", ThinkFilter.strip("Hello <think>x"))
    }

    @Test fun handlesClosingTagOnly() {
        assertEquals("Hi", ThinkFilter.strip("some reasoning</think> Hi"))
    }

    @Test fun plainTextUnchanged() {
        assertEquals("Just text.", ThinkFilter.strip("Just text."))
    }

    @Test fun speechCleanRemovesMarkdownAndLinks() {
        assertEquals("Hello see link now", SpeechText.clean("**Hello** see https://example.com now"))
    }

    @Test fun detectsDevanagari() {
        assertTrue(SpeechText.looksDevanagari("नमस्ते दुनिया"))
        assertFalse(SpeechText.looksDevanagari("namaste duniya"))
    }
}
