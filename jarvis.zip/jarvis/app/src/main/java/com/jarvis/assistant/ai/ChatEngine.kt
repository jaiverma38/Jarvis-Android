package com.jarvis.assistant.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.jarvis.assistant.data.AiMode
import com.jarvis.assistant.data.OnlineKind
import com.jarvis.assistant.data.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NetworkMonitor(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val _online = MutableStateFlow(check())
    val online: StateFlow<Boolean> = _online.asStateFlow()

    init {
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    _online.value = check()
                }

                override fun onLost(network: Network) {
                    _online.value = check()
                }

                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    _online.value = check()
                }
            })
        } catch (e: SecurityException) {
            // Without ACCESS_NETWORK_STATE we only report the value read at startup.
        }
    }

    fun isOnline(): Boolean = check()

    private fun check(): Boolean {
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}

sealed interface Route {
    data class Use(val provider: AiProvider) : Route
    data class Blocked(val reason: String) : Route
}

/**
 * Decides which provider answers. In OFFLINE mode the network is never used for AI,
 * and there is no silent fallback from offline to online in any mode.
 */
class ChatEngine(
    private val settings: SettingsStore,
    private val network: NetworkMonitor,
    val local: LiteRtProvider,
    private val gemini: GeminiProvider,
    private val openAi: OpenAiCompatProvider
) {
    private fun onlineProvider(): Pair<AiProvider, Boolean> =
        when (settings.current.onlineKind) {
            OnlineKind.GEMINI -> gemini to gemini.isConfigured()
            OnlineKind.OPENAI_COMPAT -> openAi to openAi.isConfigured()
        }

    fun route(): Route {
        val (online, configured) = onlineProvider()
        return when (settings.current.aiMode) {
            AiMode.OFFLINE ->
                if (local.isModelInstalled()) Route.Use(local)
                else Route.Blocked(
                    "No on-device model is installed yet. Open the Models tab and download one, " +
                        "or switch AI mode in Settings."
                )
            AiMode.ONLINE -> when {
                !configured -> Route.Blocked("Online AI is selected but no API key or model is set. Open Settings.")
                !network.isOnline() -> Route.Blocked("You are offline, and AI mode is set to Online only.")
                else -> Route.Use(online)
            }
            AiMode.AUTO -> when {
                configured && network.isOnline() -> Route.Use(online)
                local.isModelInstalled() -> Route.Use(local)
                else -> Route.Blocked(
                    "Auto mode needs either internet plus an API key, or a downloaded on-device model."
                )
            }
        }
    }
}
