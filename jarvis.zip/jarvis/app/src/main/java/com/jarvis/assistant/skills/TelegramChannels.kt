package com.jarvis.assistant.skills

import com.jarvis.assistant.ai.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

data class TgPost(val id: Int, val text: String)

/**
 * Reads the public web preview of a Telegram channel (t.me/s/<name>). No login and no key, so it works only for
 * PUBLIC channels. Private channels and groups cannot be read this way. Only the channel name is sent.
 */
object TelegramChannels {
    private val postStart = Regex("data-post=\"[^\"/]+/(\\d+)\"")
    private val textBlock = Regex("tgme_widget_message_text[^>]*>(.*?)</div>", RegexOption.DOT_MATCHES_ALL)

    /** Accepts "durov", "@durov" or "https://t.me/durov" and returns the channel name, or null. */
    fun channelName(raw: String): String? {
        val s = raw.trim().removePrefix("https://").removePrefix("http://").removePrefix("t.me/").removePrefix("s/")
            .removePrefix("@").substringBefore('/').substringBefore('?')
        return Regex("^[A-Za-z][A-Za-z0-9_]{3,31}$").find(s)?.value
    }

    suspend fun fetch(name: String): List<TgPost>? = withContext(Dispatchers.IO) {
        runCatching {
            val html = Http.getText("https://t.me/s/$name", 8_000, "text/html")
            val starts = postStart.findAll(html).toList()
            starts.mapIndexed { i, m ->
                val end = if (i + 1 < starts.size) starts[i + 1].range.first else html.length
                val seg = html.substring(m.range.first, end)
                val text = textBlock.find(seg)?.groupValues?.get(1)?.let { plain(it) }.orEmpty()
                TgPost(m.groupValues[1].toInt(), text.ifBlank { "(photo, video or file)" })
            }.sortedBy { it.id }
        }.getOrNull()
    }

    private fun plain(s: String): String =
        s.replace(Regex("<br\\s*/?>"), " ").replace(Regex("<[^>]+>"), "")
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<")
            .replace("&gt;", ">").replace("&nbsp;", " ").replace(Regex("\\s+"), " ").trim()

    /** Checks every saved channel and describes what is new since the last check. Marks those posts as seen. */
    suspend fun report(store: TelegramStore, address: String): String {
        val channels = store.all()
        if (channels.isEmpty()) {
            return "You have no Telegram channels yet, $address. Add one like: telegram channel add durov " +
                "(public channels only)."
        }
        val results = withTimeoutOrNull(25_000) {
            coroutineScope {
                channels.map { (name, last) -> async { Triple(name, last, fetch(name)) } }.map { it.await() }
            }
        } ?: return "Telegram did not answer in time, $address. Please try again."

        val lines = ArrayList<String>()
        var anyNew = false
        for ((name, last, posts) in results) {
            when {
                posts == null -> lines += "@$name: I could not reach it."
                posts.isEmpty() -> lines += "@$name: no public posts visible. It may be private or the name may be wrong."
                last == 0 -> {
                    store.setLastSeen(name, posts.last().id)
                    lines += "@$name: now tracking. Latest post: ${posts.last().text.take(140)}"
                }
                else -> {
                    val fresh = posts.filter { it.id > last }
                    if (fresh.isNotEmpty()) {
                        anyNew = true
                        store.setLastSeen(name, fresh.last().id)
                        val more = if (fresh.size > 1) "${fresh.size} new posts. Latest: " else "1 new post: "
                        lines += "@$name: $more${fresh.last().text.take(140)}"
                    }
                }
            }
        }
        if (lines.isEmpty() && !anyNew) return "No new updates in your ${channels.size} Telegram channel(s), $address."
        return lines.joinToString("\n")
    }
}
