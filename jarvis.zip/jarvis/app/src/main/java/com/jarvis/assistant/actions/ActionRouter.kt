package com.jarvis.assistant.actions

import android.Manifest
import android.app.ActivityManager
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContentUris
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.ContactsContract
import android.provider.MediaStore
import android.view.KeyEvent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.jarvis.assistant.data.ChatRepository
import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.notifications.JarvisNotificationListener
import com.jarvis.assistant.security.AuditLog
import java.util.Locale
import kotlin.math.roundToInt

data class ActionResult(val ok: Boolean, val message: String)

/**
 * The only code that touches phone features on behalf of the assistant. Every action is a fixed,
 * allowlisted case of [Action]. It never bypasses Android permissions: where Android needs the
 * user to grant something, it opens the proper system page and says so.
 */
class ActionRouter(
    private val ctx: Context,
    private val audit: AuditLog,
    private val settings: SettingsStore,
    private val repo: ChatRepository
) {
    private val cameraManager = ctx.getSystemService(CameraManager::class.java)
    private val audioManager = ctx.getSystemService(AudioManager::class.java)

    @Volatile
    private var torchIsOn = false

    init {
        try {
            cameraManager.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchIsOn = enabled
                }
            }, null)
        } catch (e: Exception) {
            // Torch state tracking is optional.
        }
    }

    /** Short text shown in the Confirm dialog. */
    fun describe(a: Action): String = when (a) {
        is Action.Brightness -> when (a.mode) {
            BrightnessMode.SET -> "Set screen brightness to ${a.percent}%? This changes a system setting."
            BrightnessMode.UP -> "Increase screen brightness? This changes a system setting."
            BrightnessMode.DOWN -> "Decrease screen brightness? This changes a system setting."
        }
        is Action.Dial -> "Open the phone dialer with ${a.number}? You will still have to press the call button."
        is Action.ComposeSms ->
            "Open the messaging app with a draft to ${a.number}? You will still have to press send."
        is Action.WhatsAppCall ->
            "Start a WhatsApp ${if (a.video) "video" else "voice"} call to \"${a.contact}\"?"
        is Action.WhatsAppMessage ->
            "Open a WhatsApp chat with \"${a.contact}\" and put this message in the box?\n\"${a.body}\"\n" +
                "You will still have to press send."
        is Action.Remember -> "Save this to JARVIS memory on this phone?\n\"${a.text}\""
        Action.ReadNotifications ->
            "Read your latest notifications? Their content will be shown (and spoken if voice replies are on)."
        else -> "Run this action?"
    }

    suspend fun execute(a: Action): ActionResult {
        val result = try {
            run(a)
        } catch (e: SecurityException) {
            ActionResult(false, "Android did not allow that action.")
        } catch (e: ActivityNotFoundException) {
            ActionResult(false, "No app on this phone can handle that.")
        } catch (e: CameraAccessException) {
            ActionResult(false, "The camera flash is not available right now, another app may be using it.")
        } catch (e: Exception) {
            ActionResult(false, "That did not work: ${e.javaClass.simpleName}.")
        }
        runCatching { audit.record(a.javaClass.simpleName, auditDetail(a), if (result.ok) "ok" else "failed") }
        return result
    }

    private fun auditDetail(a: Action): String = when (a) {
        is Action.OpenApp -> a.query
        is Action.OpenSettings -> a.panel.name
        is Action.Torch -> a.on?.let { if (it) "on" else "off" } ?: "toggle"
        is Action.Volume -> "${a.mode} ${a.percent ?: ""}".trim()
        is Action.Brightness -> "${a.mode} ${a.percent ?: ""}".trim()
        is Action.Timer -> "${a.seconds}s"
        is Action.Alarm -> "%02d:%02d".format(a.hour, a.minute)
        is Action.DeviceInfo -> a.topic.name
        is Action.Dial -> "number ending ${a.number.takeLast(2)}"
        is Action.ComposeSms -> "number ending ${a.number.takeLast(2)}, text not logged"
        is Action.CloseApp -> a.query
        is Action.PlayMusic -> "app ${a.app ?: "default"}, song not logged"
        is Action.MediaControl -> a.command.name
        is Action.WhatsAppCall -> "contact not logged"
        is Action.WhatsAppMessage -> "contact and text not logged"
        Action.ReadNotifications -> "content not logged"
        is Action.Remember -> "content not logged"
        Action.Help -> ""
    }

    private suspend fun run(a: Action): ActionResult = when (a) {
        is Action.OpenApp -> openApp(a.query)
        is Action.OpenSettings -> openSettings(a.panel)
        is Action.Torch -> torch(a.on)
        is Action.Volume -> volume(a)
        is Action.Brightness -> brightness(a)
        is Action.Timer -> timer(a.seconds)
        is Action.Alarm -> alarm(a.hour, a.minute)
        is Action.DeviceInfo -> deviceInfo(a.topic)
        is Action.Dial -> {
            launch(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", a.number, null)))
            ActionResult(true, "Dialer opened. Press the call button when you are ready.")
        }
        is Action.ComposeSms -> {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a.number)))
                .putExtra("sms_body", a.body)
            launch(i)
            ActionResult(true, "Message draft opened. Press send when you are ready.")
        }
        is Action.CloseApp -> closeApp(a.query)
        is Action.PlayMusic -> playMusic(a.song, a.app)
        is Action.MediaControl -> mediaKey(a.command)
        is Action.WhatsAppCall -> whatsappCall(a.contact, a.video)
        is Action.WhatsAppMessage -> whatsappMessage(a.contact, a.body)
        Action.ReadNotifications -> readNotifications()
        is Action.Remember ->
            if (repo.addFact(a.text)) ActionResult(true, "Okay, I will remember that.")
            else ActionResult(false, "Memory is full. Delete something in Privacy first.")
        Action.Help -> ActionResult(true, HELP)
    }

    private fun launch(intent: Intent) {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---- apps and settings ----

    /** Finds an installed app by its name on the home screen. Returns (package, label). */
    @Suppress("DEPRECATION")
    private fun findPackage(query: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val aliases = mapOf(
            "yt" to "youtube", "ytmusic" to "youtubemusic", "insta" to "instagram", "fb" to "facebook",
            "wa" to "whatsapp", "saavn" to "jiosaavn"
        )
        val key = norm(query)
        val q = aliases[key] ?: key
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
        return apps.firstOrNull { norm(it.second) == q }
            ?: apps.filter { norm(it.second).startsWith(q) }.minByOrNull { it.second.length }
            ?: apps.filter { norm(it.second).contains(q) }.minByOrNull { it.second.length }
    }

    private fun openApp(query: String): ActionResult {
        val match = findPackage(query)
            ?: return ActionResult(false, "I could not find an app called \"$query\" on this phone.")
        val intent = ctx.packageManager.getLaunchIntentForPackage(match.first)
            ?: return ActionResult(false, "I could not open that app.")
        launch(intent)
        return ActionResult(true, "Opening ${match.second}.")
    }

    /**
     * Android does not let an app close another app directly. This sends the phone to the home screen and then
     * stops the app's background processes, which is what "force stop from recents" achieves for most apps.
     */
    private suspend fun closeApp(query: String): ActionResult {
        val match = findPackage(query)
            ?: return ActionResult(false, "I could not find an app called \"$query\" on this phone.")
        if (match.first == ctx.packageName) {
            return ActionResult(false, "Use the Turn off JARVIS button to close me.")
        }
        runCatching { launch(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) }
        delay(900)
        ctx.getSystemService(ActivityManager::class.java).killBackgroundProcesses(match.first)
        return ActionResult(
            true,
            "Closed ${match.second}: moved to the home screen and stopped it. Some apps restart themselves."
        )
    }

    // ---- music ----

    private fun playMusic(song: String, appQuery: String?): ActionResult {
        var pkg: String? = null
        var label = "your music app"
        if (appQuery != null) {
            val m = findPackage(appQuery)
                ?: return ActionResult(false, "I could not find an app called \"$appQuery\" on this phone.")
            pkg = m.first
            label = m.second
        }
        val play = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, song)
        if (pkg != null) play.setPackage(pkg)
        try {
            launch(play)
            return ActionResult(
                true,
                "Asking $label to play \"$song\". Some apps only open their search results instead of playing."
            )
        } catch (e: ActivityNotFoundException) {
            // fall through to a search page below
        }
        val q = Uri.encode(song)
        val fallback: Intent = when (pkg) {
            "com.spotify.music" -> Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:$q"))
            "com.google.android.apps.youtube.music" ->
                Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=$q"))
            else -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q"))
        }
        if (pkg != null) fallback.setPackage(pkg)
        return try {
            launch(fallback)
            ActionResult(true, "Opened a search for \"$song\" in $label. Tap the song to play it.")
        } catch (e: ActivityNotFoundException) {
            ActionResult(false, "$label cannot play music by voice. Open it and search for \"$song\".")
        }
    }

    /** Play, pause, next and previous go to whatever app is playing, through the system media keys. */
    private fun mediaKey(cmd: MediaCommand): ActionResult {
        val code = when (cmd) {
            MediaCommand.PLAY -> KeyEvent.KEYCODE_MEDIA_PLAY
            MediaCommand.PAUSE -> KeyEvent.KEYCODE_MEDIA_PAUSE
            MediaCommand.NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
            MediaCommand.PREVIOUS -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
        }
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ActionResult(true, when (cmd) {
            MediaCommand.PLAY -> "Play."
            MediaCommand.PAUSE -> "Paused."
            MediaCommand.NEXT -> "Next track."
            MediaCommand.PREVIOUS -> "Previous track."
        })
    }

    // ---- WhatsApp (through the contacts WhatsApp adds to the phone) ----

    private val waPackages = listOf("com.whatsapp", "com.whatsapp.w4b")

    private fun hasContacts() =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun bestName(rows: List<Pair<Long, String>>, name: String): Pair<Long, String>? {
        val q = norm(name)
        if (q.isEmpty()) return null
        return rows.firstOrNull { norm(it.second) == q }
            ?: rows.filter { norm(it.second).startsWith(q) }.minByOrNull { it.second.length }
            ?: rows.filter { norm(it.second).contains(q) }.minByOrNull { it.second.length }
    }

    private fun whatsappCall(contact: String, video: Boolean): ActionResult {
        if (!hasContacts()) return ActionResult(false, CONTACTS_NEEDED)
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
        else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        val rows = ArrayList<Pair<Long, String>>()
        ctx.contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data._ID, ContactsContract.Data.DISPLAY_NAME),
            "${ContactsContract.Data.MIMETYPE}=?", arrayOf(mime), null
        )?.use { c ->
            while (c.moveToNext()) rows += c.getLong(0) to (c.getString(1) ?: "")
        }
        val hit = bestName(rows, contact)
            ?: return ActionResult(false, "I did not find \"$contact\" among your WhatsApp contacts.")
        val uri = ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, hit.first)
        for (pkg in waPackages) {
            try {
                launch(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).setPackage(pkg))
                return ActionResult(true, "Calling ${hit.second} on WhatsApp.")
            } catch (e: ActivityNotFoundException) {
                // try the next WhatsApp package
            }
        }
        return ActionResult(false, "WhatsApp is not installed on this phone.")
    }

    private fun numberFor(contact: String): String? {
        val typed = contact.filter { it.isDigit() || it == '+' }
        if (typed.count { it.isDigit() } >= 7 && typed.length >= contact.replace(" ", "").length - 2) return typed
        if (!hasContacts()) return null
        val rows = ArrayList<Pair<String, String>>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null
        )?.use { c ->
            while (c.moveToNext()) rows += (c.getString(0) ?: "") to (c.getString(1) ?: "")
        }
        val indexed = rows.mapIndexed { i, r -> i.toLong() to r.first }
        val hit = bestName(indexed, contact) ?: return null
        return rows[hit.first.toInt()].second
    }

    /** wa.me needs the number with country code and digits only. A 10 digit number is taken as Indian (+91). */
    private fun waDigits(number: String): String {
        var d = number.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.drop(2)
        if (d.length == 11 && d.startsWith("0")) d = d.drop(1)
        if (d.length == 10) d = "91$d"
        return d
    }

    private fun whatsappMessage(contact: String, body: String): ActionResult {
        val typedNumber = contact.filter { it.isDigit() }.length >= 7
        if (!typedNumber && !hasContacts()) return ActionResult(false, CONTACTS_NEEDED)
        val number = numberFor(contact)
            ?: return ActionResult(false, "I did not find a phone number for \"$contact\" in your contacts.")
        val url = Uri.parse("https://wa.me/${waDigits(number)}?text=${Uri.encode(body)}")
        for (pkg in waPackages) {
            try {
                launch(Intent(Intent.ACTION_VIEW, url).setPackage(pkg))
                return ActionResult(true, "WhatsApp chat opened with your message ready. Press send.")
            } catch (e: ActivityNotFoundException) {
                // try the next WhatsApp package
            }
        }
        return ActionResult(false, "WhatsApp is not installed on this phone.")
    }

    private fun norm(s: String) = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    private fun openSettings(panel: SettingsPanel): ActionResult {
        val intent = when (panel) {
            SettingsPanel.ROOT -> Intent(Settings.ACTION_SETTINGS)
            SettingsPanel.WIFI ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                else Intent(Settings.ACTION_WIFI_SETTINGS)
            SettingsPanel.BLUETOOTH -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            SettingsPanel.DISPLAY -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            SettingsPanel.SOUND -> Intent(Settings.ACTION_SOUND_SETTINGS)
            SettingsPanel.BATTERY -> Intent(Intent.ACTION_POWER_USAGE_SUMMARY)
            SettingsPanel.LOCATION -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            SettingsPanel.APPS -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            SettingsPanel.STORAGE -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            SettingsPanel.NFC -> Intent(Settings.ACTION_NFC_SETTINGS)
        }
        launch(intent)
        return ActionResult(true, "Opening ${panel.name.lowercase(Locale.ROOT)} settings.")
    }

    // ---- torch, volume, brightness ----

    private fun torch(on: Boolean?): ActionResult {
        val id = cameraManager.cameraIdList.firstOrNull { cid ->
            val c = cameraManager.getCameraCharacteristics(cid)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return ActionResult(false, "This phone does not report a flashlight.")
        val target = on ?: !torchIsOn
        cameraManager.setTorchMode(id, target)
        torchIsOn = target
        return ActionResult(true, if (target) "Torch is on." else "Torch is off.")
    }

    private fun volume(a: Action.Volume): ActionResult {
        val stream = AudioManager.STREAM_MUSIC
        val max = audioManager.getStreamMaxVolume(stream)
        val cur = audioManager.getStreamVolume(stream)
        val step = maxOf(1, (max * 0.15).roundToInt())
        val target = when (a.mode) {
            VolumeMode.UP -> cur + step
            VolumeMode.DOWN -> cur - step
            VolumeMode.SET -> (max * (a.percent ?: 50) / 100.0).roundToInt()
            VolumeMode.MUTE -> 0
        }.coerceIn(0, max)
        audioManager.setStreamVolume(stream, target, AudioManager.FLAG_SHOW_UI)
        val pct = if (max == 0) 0 else (target * 100.0 / max).roundToInt()
        return ActionResult(true, "Media volume is now $pct%.")
    }

    private fun brightness(a: Action.Brightness): ActionResult {
        if (!Settings.System.canWrite(ctx)) {
            launch(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
            )
            return ActionResult(
                false,
                "Android needs your permission to change brightness. I opened the page: allow JARVIS, " +
                    "then ask again."
            )
        }
        val resolver = ctx.contentResolver
        val current = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        val target = when (a.mode) {
            BrightnessMode.SET -> (255 * (a.percent ?: 50) / 100.0).roundToInt()
            BrightnessMode.UP -> current + 51
            BrightnessMode.DOWN -> current - 51
        }.coerceIn(10, 255)
        Settings.System.putInt(
            resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, target)
        return ActionResult(true, "Brightness is now ${(target * 100.0 / 255).roundToInt()}%.")
    }

    // ---- timers and alarms (through the system clock app) ----

    private fun timer(seconds: Int): ActionResult {
        launch(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS timer")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return ActionResult(true, "Timer set for ${formatDuration(seconds)}.")
    }

    private fun alarm(hour: Int, minute: Int): ActionResult {
        launch(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS alarm")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return ActionResult(true, "Alarm set for %02d:%02d (24-hour clock). Check your clock app to confirm.".format(hour, minute))
    }

    private fun formatDuration(s: Int): String {
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return listOfNotNull(
            if (h > 0) "$h hour${if (h > 1) "s" else ""}" else null,
            if (m > 0) "$m minute${if (m > 1) "s" else ""}" else null,
            if (sec > 0) "$sec second${if (sec > 1) "s" else ""}" else null
        ).joinToString(" ")
    }

    // ---- device info ----

    private fun deviceInfo(topic: InfoTopic): ActionResult {
        val parts = mutableListOf<String>()
        if (topic == InfoTopic.ALL) {
            parts += "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}"
        }
        if (topic == InfoTopic.ALL || topic == InfoTopic.BATTERY) parts += batteryText()
        if (topic == InfoTopic.ALL || topic == InfoTopic.STORAGE) parts += storageText()
        if (topic == InfoTopic.ALL || topic == InfoTopic.MEMORY) parts += memoryText()
        if (topic == InfoTopic.ALL || topic == InfoTopic.NETWORK) parts += networkText()
        return ActionResult(true, parts.joinToString(". ") + ".")
    }

    private fun batteryText(): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return "Battery level is unavailable"
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        if (level < 0 || scale <= 0) return "Battery level is unavailable"
        return "Battery is at ${(level * 100.0 / scale).roundToInt()}%${if (charging) " and charging" else ""}"
    }

    private fun storageText(): String {
        val st = StatFs(Environment.getDataDirectory().path)
        val free = st.availableBytes / 1_000_000_000.0
        val total = st.totalBytes / 1_000_000_000.0
        return "Storage: %.1f GB free of %.1f GB".format(Locale.US, free, total)
    }

    private fun memoryText(): String {
        val info = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(info)
        return "Memory: %.1f GB free of %.1f GB".format(Locale.US, info.availMem / 1e9, info.totalMem / 1e9)
    }

    private fun networkText(): String {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        return when {
            caps == null -> "No internet connection"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Connected through Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Connected through mobile data"
            else -> "Connected to a network"
        }
    }

    // ---- notifications (opt-in only) ----

    private fun readNotifications(): ActionResult {
        val system = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        if (!system) {
            launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return ActionResult(
                false,
                "Notification access is off. I opened the Android page: allow JARVIS there, " +
                    "also switch on notification reading in JARVIS Settings, then ask again."
            )
        }
        if (!settings.current.notificationReading) {
            return ActionResult(false, "Notification reading is switched off in JARVIS Settings. Turn it on first.")
        }
        val items = JarvisNotificationListener.snapshot().take(6)
        if (items.isEmpty()) return ActionResult(true, "No new notifications since notification reading was turned on.")
        val text = items.joinToString("\n") { n ->
            val body = listOf(n.title, n.text).filter { it.isNotBlank() }.joinToString(": ")
            "${n.app}: $body"
        }
        return ActionResult(true, "Latest notifications:\n$text")
    }

    companion object {
        const val CONTACTS_NEEDED =
            "I need permission to read your contacts. Open JARVIS Settings, find Phone control, " +
                "tap Allow contacts, then ask again."
        const val HELP =
            "I can open apps and settings, switch the torch on or off, change media volume and brightness, " +
                "close apps, play music from a named app (\"Spotify par Kesariya bajao\"), pause or skip songs, " +
                "start a WhatsApp call or put a WhatsApp message in the chat box, " +
                "set timers and alarms, tell you battery, storage, memory and network status, " +
                "open the dialer or a message draft, read notifications (if you enable it), and remember " +
                "things you ask me to. Try: \"torch on\", \"timer 5 minutes\", \"open YouTube\", " +
                "\"volume 40\", \"battery\". Anything else I answer as chat."
    }
}
