package com.jarvis.assistant.api

import com.jarvis.assistant.ai.AiProvider
import com.jarvis.assistant.ai.ChatEngine
import com.jarvis.assistant.ai.ChatRequest
import com.jarvis.assistant.ai.ChatTurn
import com.jarvis.assistant.ai.Prompts
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.lastOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * A small OpenAI-compatible web server inside the app, so other devices on the SAME Wi-Fi can use this phone's
 * models (the on-device one and the online one, e.g. Groq) with the Jarvis key, without ever seeing the real
 * Groq key. Endpoints: GET /v1/models and POST /v1/chat/completions (plain or streamed).
 *
 * Honest limits: it works only while this phone is on and reachable on the network; traffic on the local Wi-Fi
 * is plain HTTP (the Jarvis key is sent in the clear on that network), so use it only on a network you trust.
 * Model names: "jarvis" (online when possible, else offline), "jarvis-online", "jarvis-offline".
 */
class JarvisApiServer(
    private val engine: ChatEngine,
    private val key: () -> String?,
    private val port: Int = DEFAULT_PORT
) {
    @Volatile
    private var server: ServerSocket? = null
    private val pool = Executors.newFixedThreadPool(4) { r -> Thread(r, "jarvis-api").apply { isDaemon = true } }
    private val localLock = Any()

    val isRunning: Boolean get() = server?.isClosed == false

    @Synchronized
    fun start() {
        if (isRunning) return
        val s = ServerSocket(port)
        server = s
        Thread({
            while (!s.isClosed) {
                val sock = try { s.accept() } catch (e: Exception) { break }
                pool.execute { handle(sock) }
            }
        }, "jarvis-api-accept").apply { isDaemon = true }.start()
    }

    @Synchronized
    fun stop() {
        runCatching { server?.close() }
        server = null
    }

    private fun handle(sock: Socket) {
        sock.use { s ->
            s.soTimeout = 15_000
            try {
                val inp = BufferedInputStream(s.getInputStream())
                val out = s.getOutputStream()
                val req = readRequest(inp) ?: return
                route(req, out)
            } catch (e: Exception) {
                // a broken or timed-out client: nothing to do
            }
        }
    }

    private class Req(val method: String, val path: String, val headers: Map<String, String>, val body: String)

    private fun readLine(inp: BufferedInputStream): String? {
        val b = ByteArrayOutputStream()
        while (true) {
            val c = inp.read()
            if (c == -1) return if (b.size() == 0) null else b.toString("UTF-8")
            if (c == '\n'.code) return b.toString("UTF-8").trimEnd('\r')
            b.write(c)
            if (b.size() > 8192) return null
        }
    }

    private fun readRequest(inp: BufferedInputStream): Req? {
        val first = readLine(inp) ?: return null
        val parts = first.split(' ')
        if (parts.size < 2) return null
        val headers = HashMap<String, String>()
        while (true) {
            val line = readLine(inp) ?: return null
            if (line.isEmpty()) break
            val i = line.indexOf(':')
            if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }
        val len = headers["content-length"]?.toIntOrNull() ?: 0
        if (len < 0 || len > MAX_BODY) return null
        val body = ByteArray(len)
        var read = 0
        while (read < len) {
            val n = inp.read(body, read, len - read)
            if (n < 0) return null
            read += n
        }
        return Req(parts[0].uppercase(), parts[1].substringBefore('?'), headers, String(body, Charsets.UTF_8))
    }

    private fun authorized(req: Req): Boolean {
        val expected = key()?.takeIf { it.isNotBlank() } ?: return false
        val given = req.headers["authorization"]?.removePrefix("Bearer ")?.trim().orEmpty()
        return MessageDigest.isEqual(given.toByteArray(), expected.toByteArray())
    }

    private fun route(req: Req, out: OutputStream) {
        when {
            req.method == "OPTIONS" -> send(out, 204, "")
            req.path == "/" || req.path == "/health" ->
                send(out, 200, JSONObject().put("name", "JARVIS API").put("status", "ok").toString())
            !authorized(req) -> {
                Thread.sleep(400)
                send(out, 401, error("Invalid or missing Jarvis key.", "invalid_api_key"))
            }
            req.method == "GET" && req.path == "/v1/models" -> {
                val data = JSONArray()
                listOf("jarvis", "jarvis-online", "jarvis-offline").forEach {
                    data.put(JSONObject().put("id", it).put("object", "model").put("owned_by", "jarvis"))
                }
                send(out, 200, JSONObject().put("object", "list").put("data", data).toString())
            }
            req.method == "POST" && req.path == "/v1/chat/completions" -> chat(req, out)
            else -> send(out, 404, error("Not found.", "not_found"))
        }
    }

    private fun chat(req: Req, out: OutputStream) {
        val json = try { JSONObject(req.body) } catch (e: Exception) {
            return send(out, 400, error("Body must be JSON.", "invalid_request"))
        }
        val model = json.optString("model", "jarvis")
        val stream = json.optBoolean("stream", false)
        val request = toRequest(json) ?: return send(out, 400, error("No user message.", "invalid_request"))

        val provider: AiProvider? = when (model) {
            "jarvis-online" -> engine.onlineOrNull()
            "jarvis-offline" -> engine.localOrNull()
            else -> engine.onlineOrNull() ?: engine.localOrNull()
        }
        if (provider == null) {
            return send(out, 503, error("That model is not available right now on the phone (offline, no key, or no downloaded model).", "model_unavailable"))
        }
        val text: String = (try {
            if (provider === engine.local) synchronized(localLock) { runBlocking { provider.generate(request).lastOrNull() } }
            else runBlocking { provider.generate(request).lastOrNull() }
        } catch (e: Exception) {
            return send(out, 502, error("The model failed: ${e.message?.take(160) ?: e.javaClass.simpleName}", "upstream_error"))
        }) ?: ""

        val id = "chatcmpl-" + System.currentTimeMillis()
        if (!stream) {
            val msg = JSONObject().put("role", "assistant").put("content", text)
            val choice = JSONObject().put("index", 0).put("message", msg).put("finish_reason", "stop")
            val body = JSONObject().put("id", id).put("object", "chat.completion").put("model", model)
                .put("choices", JSONArray().put(choice))
                .put("usage", JSONObject().put("prompt_tokens", 0).put("completion_tokens", 0).put("total_tokens", 0))
            send(out, 200, body.toString())
        } else {
            val chunk = JSONObject().put("id", id).put("object", "chat.completion.chunk").put("model", model)
                .put("choices", JSONArray().put(
                    JSONObject().put("index", 0)
                        .put("delta", JSONObject().put("role", "assistant").put("content", text))
                        .put("finish_reason", JSONObject.NULL)
                ))
            val done = JSONObject().put("id", id).put("object", "chat.completion.chunk").put("model", model)
                .put("choices", JSONArray().put(
                    JSONObject().put("index", 0).put("delta", JSONObject()).put("finish_reason", "stop")
                ))
            val sse = "data: $chunk\n\ndata: $done\n\ndata: [DONE]\n\n"
            send(out, 200, sse, "text/event-stream")
        }
    }

    /** OpenAI-style messages -> JARVIS's ChatRequest. The last user message is the question. */
    private fun toRequest(json: JSONObject): ChatRequest? {
        val arr = json.optJSONArray("messages") ?: return null
        var system: String? = null
        val turns = ArrayList<ChatTurn>()
        for (i in 0 until arr.length()) {
            val m = arr.optJSONObject(i) ?: continue
            val text = contentText(m.opt("content"))
            when (m.optString("role")) {
                "system", "developer" -> if (system == null) system = text
                "user" -> turns += ChatTurn(true, text)
                "assistant" -> turns += ChatTurn(false, text)
            }
        }
        val last = turns.indexOfLast { it.isUser }
        if (last < 0) return null
        val history = turns.take(last).takeLast(12)
        val sys = system ?: Prompts.system(emptyList())
        return ChatRequest(sys, history, turns[last].text, "api:" + (sys + history.joinToString { it.text }).hashCode())
    }

    private fun contentText(c: Any?): String = when (c) {
        is String -> c
        is JSONArray -> (0 until c.length()).mapNotNull { c.optJSONObject(it)?.optString("text")?.takeIf { t -> t.isNotEmpty() } }
            .joinToString("\n")
        else -> ""
    }

    private fun error(message: String, type: String) =
        JSONObject().put("error", JSONObject().put("message", message).put("type", type)).toString()

    private fun send(out: OutputStream, code: Int, body: String, type: String = "application/json") {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val status = when (code) {
            200 -> "OK"; 204 -> "No Content"; 400 -> "Bad Request"; 401 -> "Unauthorized"
            404 -> "Not Found"; 502 -> "Bad Gateway"; 503 -> "Service Unavailable"; else -> "Error"
        }
        val head = "HTTP/1.1 $code $status\r\nContent-Type: $type; charset=utf-8\r\nContent-Length: ${bytes.size}\r\n" +
            "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: authorization, content-type\r\n" +
            "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.UTF_8))
        out.write(bytes)
        out.flush()
    }

    companion object {
        const val DEFAULT_PORT = 8787
        private const val MAX_BODY = 1_000_000
    }
}
