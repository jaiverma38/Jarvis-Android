package com.jarvis.assistant.ai

import android.content.Context
import android.os.StatFs
import android.os.SystemClock
import com.jarvis.assistant.data.SettingsStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

sealed interface DownloadState {
    data object Idle : DownloadState
    data class Running(val done: Long, val total: Long) : DownloadState
    data class Paused(val done: Long, val total: Long) : DownloadState
    data object Verifying : DownloadState
    data class Failed(val message: String) : DownloadState
}

data class ModelStatus(
    val spec: ModelSpec,
    val installedBytes: Long?,
    val sha256: String?,
    /** True when the SHA-256 matched the hash published by the server (Hugging Face X-Linked-Etag). */
    val serverVerified: Boolean,
    val download: DownloadState
)

class DownloadException(message: String) : IOException(message)

/**
 * Downloads models into app-private storage (filesDir/models) with progress, pause/resume
 * (HTTP Range), SHA-256 verification and deletion. Models never leave the app sandbox.
 */
class ModelManager(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val settings: SettingsStore
) {
    private val dir = File(ctx.filesDir, "models").apply { mkdirs() }
    private val meta = ctx.getSharedPreferences("model_meta", Context.MODE_PRIVATE)

    private val downloads = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    private val version = MutableStateFlow(0)
    private val custom = MutableStateFlow(loadCustom())
    private val jobs = ConcurrentHashMap<String, Job>()
    private val totals = ConcurrentHashMap<String, Long>()

    val statuses: Flow<List<ModelStatus>> = combine(downloads, version, custom) { d, _, c ->
        (ModelRegistry.builtIn + c).map { spec -> status(spec, d[spec.id]) }
    }

    fun allSpecs(): List<ModelSpec> = ModelRegistry.builtIn + custom.value

    fun specById(id: String): ModelSpec? = allSpecs().firstOrNull { it.id == id }

    fun selectedSpec(): ModelSpec = specById(settings.current.selectedModelId) ?: ModelRegistry.default

    fun modelFile(spec: ModelSpec) = File(dir, spec.fileName)

    private fun partFile(spec: ModelSpec) = File(dir, spec.fileName + ".part")

    /** Absolute path of a fully downloaded and verified model, or null. */
    fun installedPath(spec: ModelSpec): String? =
        modelFile(spec).takeIf { it.isFile && it.length() > 0 }?.absolutePath

    fun usedBytes(): Long = dir.listFiles()?.sumOf { it.length() } ?: 0L

    fun freeBytes(): Long = StatFs(ctx.filesDir.absolutePath).availableBytes

    private fun status(spec: ModelSpec, state: DownloadState?): ModelStatus {
        val installed = modelFile(spec).takeIf { it.isFile }?.length()
        val part = partFile(spec)
        val effective = state ?: if (installed == null && part.exists() && part.length() > 0) {
            DownloadState.Paused(part.length(), totals[spec.id] ?: spec.approxBytes)
        } else {
            DownloadState.Idle
        }
        return ModelStatus(
            spec = spec,
            installedBytes = installed,
            sha256 = meta.getString("sha_${spec.id}", null),
            serverVerified = meta.getBoolean("verified_${spec.id}", false),
            download = effective
        )
    }

    private fun setState(id: String, state: DownloadState) {
        downloads.value = downloads.value + (id to state)
    }

    fun start(spec: ModelSpec) {
        if (jobs[spec.id]?.isActive == true) return
        val job = scope.launch(Dispatchers.IO) {
            try {
                download(spec)
                downloads.value = downloads.value - spec.id
                version.value++
            } catch (e: CancellationException) {
                setState(spec.id, DownloadState.Paused(partFile(spec).length(), totals[spec.id] ?: spec.approxBytes))
                throw e
            } catch (e: Exception) {
                if (!isActive) {
                    // Pause closed the connection, which surfaces as an IOException.
                    setState(spec.id, DownloadState.Paused(partFile(spec).length(), totals[spec.id] ?: spec.approxBytes))
                } else {
                    setState(spec.id, DownloadState.Failed(describe(e)))
                }
            }
        }
        jobs[spec.id] = job
    }

    fun pause(id: String) {
        jobs[id]?.cancel()
    }

    /** Stops a download and deletes the partial file. */
    fun cancel(spec: ModelSpec) {
        jobs.remove(spec.id)?.cancel()
        partFile(spec).delete()
        downloads.value = downloads.value - spec.id
        version.value++
    }

    /** Deletes the installed model file. Unload it from memory first. */
    fun delete(spec: ModelSpec) {
        jobs.remove(spec.id)?.cancel()
        modelFile(spec).delete()
        partFile(spec).delete()
        meta.edit().remove("sha_${spec.id}").remove("verified_${spec.id}").apply()
        downloads.value = downloads.value - spec.id
        version.value++
    }

    // ---- custom models (user supplied HTTPS URL to a .litertlm file) ----

    fun addCustom(rawUrl: String): Result<ModelSpec> {
        val url = try {
            URL(rawUrl.trim())
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException("That is not a valid URL."))
        }
        if (url.protocol != "https") {
            return Result.failure(IllegalArgumentException("Only HTTPS links are allowed."))
        }
        val last = URLDecoder.decode(url.path.substringAfterLast('/'), "UTF-8")
        val safeName = last.replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (!safeName.endsWith(".litertlm") || safeName.length < 10) {
            return Result.failure(IllegalArgumentException("The link must point to a .litertlm file."))
        }
        val id = "custom-$safeName"
        if (specById(id) != null) {
            return Result.failure(IllegalArgumentException("That model is already in the list."))
        }
        val spec = ModelSpec(
            id = id,
            name = safeName,
            url = url.toString(),
            fileName = safeName,
            approxBytes = 0L,
            license = "Not checked by JARVIS. You are responsible for the license.",
            contextTokens = 0,
            noThinkSwitch = false,
            note = "Custom model. Memory use and speed are unknown until you run the benchmark.",
            custom = true
        )
        custom.value = custom.value + spec
        saveCustom()
        return Result.success(spec)
    }

    fun removeCustom(spec: ModelSpec) {
        delete(spec)
        custom.value = custom.value.filterNot { it.id == spec.id }
        saveCustom()
    }

    private fun loadCustom(): List<ModelSpec> {
        val raw = meta.getString("custom", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ModelSpec(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    url = o.getString("url"),
                    fileName = o.getString("fileName"),
                    approxBytes = 0L,
                    license = "Not checked by JARVIS. You are responsible for the license.",
                    contextTokens = 0,
                    noThinkSwitch = false,
                    note = "Custom model. Memory use and speed are unknown until you run the benchmark.",
                    custom = true
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveCustom() {
        val arr = JSONArray()
        custom.value.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name)
                    .put("url", it.url).put("fileName", it.fileName)
            )
        }
        meta.edit().putString("custom", arr.toString()).apply()
    }

    // ---- download internals ----

    private suspend fun download(spec: ModelSpec) {
        val part = partFile(spec)
        val existing = if (part.exists()) part.length() else 0L
        setState(spec.id, DownloadState.Running(existing, totals[spec.id] ?: spec.approxBytes))

        val (conn, linkedEtag) = openWithRedirects(spec.url, existing)
        val handle = currentCoroutineContext().job.invokeOnCompletion { conn.disconnect() }
        try {
            val code = conn.responseCode
            var done: Long
            var total: Long
            when (code) {
                200, 206 -> {
                    val append = code == 206
                    if (!append && part.exists()) part.delete()
                    val offset = if (append) existing else 0L
                    total = parseTotal(conn, offset)
                    totals[spec.id] = total
                    ensureSpace(total - offset)
                    done = offset
                    FileOutputStream(part, append).use { out ->
                        conn.inputStream.use { input ->
                            val buf = ByteArray(64 * 1024)
                            var lastUpdate = 0L
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                val now = SystemClock.elapsedRealtime()
                                if (now - lastUpdate > 300) {
                                    lastUpdate = now
                                    setState(spec.id, DownloadState.Running(done, total))
                                }
                            }
                            out.fd.sync()
                        }
                    }
                }
                416 -> {
                    // The partial file is already complete.
                    if (existing <= 0) throw DownloadException("Server rejected the download range.")
                    done = existing
                    total = existing
                }
                401, 403 -> throw DownloadException(
                    "This file needs a Hugging Face login or license acceptance, which is not supported in the app."
                )
                404 -> throw DownloadException("File not found at that link.")
                else -> throw DownloadException("Server answered with HTTP $code.")
            }
            if (total > 0 && done != total) throw DownloadException("Download was incomplete. Tap Resume.")

            setState(spec.id, DownloadState.Verifying)
            val actual = sha256(part)
            val expected = linkedEtag?.trim('"')?.takeIf { Regex("[0-9a-fA-F]{64}").matches(it) }
            if (expected != null && !expected.equals(actual, ignoreCase = true)) {
                part.delete()
                throw DownloadException("Integrity check failed (SHA-256 mismatch). The file was deleted. Download again.")
            }
            val finalFile = modelFile(spec)
            finalFile.delete()
            if (!part.renameTo(finalFile)) throw DownloadException("Could not save the model file.")
            meta.edit()
                .putString("sha_${spec.id}", actual)
                .putBoolean("verified_${spec.id}", expected != null)
                .apply()
        } finally {
            handle.dispose()
            conn.disconnect()
        }
    }

    /**
     * Follows redirects manually so the first response's X-Linked-Etag (the file's SHA-256 on
     * Hugging Face) can be read, and so no cookies or credentials are ever forwarded.
     */
    private fun openWithRedirects(startUrl: String, rangeStart: Long): Pair<HttpURLConnection, String?> {
        var current = URL(startUrl)
        var linkedEtag: String? = null
        for (hop in 0 until 6) {
            if (current.protocol != "https") throw DownloadException("Redirected to a non-HTTPS address. Blocked.")
            val c = current.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "JarvisAssistant/0.1")
            if (rangeStart > 0) c.setRequestProperty("Range", "bytes=$rangeStart-")
            val code = c.responseCode
            if (hop == 0) linkedEtag = c.getHeaderField("X-Linked-Etag")
            if (code in 300..399) {
                val location = c.getHeaderField("Location")
                c.disconnect()
                if (location.isNullOrBlank()) throw DownloadException("Bad redirect from server.")
                current = URL(current, location)
                continue
            }
            return c to linkedEtag
        }
        throw DownloadException("Too many redirects.")
    }

    private fun parseTotal(conn: HttpURLConnection, offset: Long): Long {
        val range = conn.getHeaderField("Content-Range")
        if (range != null) {
            val t = range.substringAfterLast('/').trim().toLongOrNull()
            if (t != null) return t
        }
        val len = conn.contentLengthLong
        return if (len > 0) len + offset else 0L
    }

    private fun ensureSpace(remaining: Long) {
        if (remaining <= 0) return
        val needed = remaining + 100_000_000L
        if (freeBytes() < needed) {
            throw DownloadException(
                "Not enough free storage. Need about ${needed / 1_000_000} MB, have ${freeBytes() / 1_000_000} MB."
            )
        }
    }

    private suspend fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(1024 * 1024)
            while (true) {
                currentCoroutineContext().ensureActive()
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun describe(e: Exception): String = when (e) {
        is DownloadException -> e.message ?: "Download failed."
        is java.net.UnknownHostException, is java.net.ConnectException -> "No internet connection."
        is java.net.SocketTimeoutException -> "Connection timed out. Tap Resume to continue."
        else -> "Download failed: ${e.javaClass.simpleName}. Tap Resume to retry."
    }
}
