package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.util.SpeechText
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Speech input and output through the Android system services (SpeechRecognizer, TextToSpeech).
 * Push-to-talk only: the microphone is open only after the user taps the orb, and a notification
 * with a Stop button is shown while it is open. There is NO always-listening or wake-word mode.
 *
 * Honest limit: on Android 12 there is no API to ask whether offline recognition is installed.
 * "Prefer offline" is a request; the Google speech service decides. If it needs internet, the
 * error message says so.
 *
 * All methods must be called on the main thread.
 */
class VoiceController(private val ctx: Context, private val settings: SettingsStore) {

    sealed interface Event {
        data class Partial(val text: String) : Event
        data class Final(val text: String) : Event
        data class Failure(val message: String) : Event
        data object Stopped : Event
    }

    private val _events = MutableSharedFlow<Event>(extraBufferCapacity = 32)
    val events: SharedFlow<Event> = _events.asSharedFlow()

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var ignoreErrors = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = ConcurrentHashMap<String, CompletableDeferred<Unit>>()

    fun isRecognitionAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun startListening() {
        if (!isRecognitionAvailable()) {
            _events.tryEmit(
                Event.Failure(
                    "No speech recognition service is installed. Install or enable the Google app " +
                        "(Settings > Apps > Default apps > Digital assistant app / Voice input)."
                )
            )
            return
        }
        destroyRecognizer()
        ignoreErrors = false
        val s = settings.current
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(listener)
        recognizer = r
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, s.voiceLang.tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, s.preferOfflineSpeech)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        r.startListening(intent)
    }

    /** Stops listening without producing a result. */
    fun stopListening() {
        ignoreErrors = true
        destroyRecognizer()
        _events.tryEmit(Event.Stopped)
    }

    private fun destroyRecognizer() {
        recognizer?.let {
            runCatching { it.cancel() }
            runCatching { it.destroy() }
        }
        recognizer = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) _events.tryEmit(Event.Partial(t))
        }

        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            destroyRecognizer()
            if (t.isNullOrBlank()) {
                _events.tryEmit(Event.Failure("I did not catch that. Tap the orb and try again."))
            } else {
                _events.tryEmit(Event.Final(t))
            }
        }

        override fun onError(error: Int) {
            if (ignoreErrors) return
            destroyRecognizer()
            _events.tryEmit(Event.Failure(describeError(error)))
        }
    }

    private fun describeError(code: Int): String {
        val lang = settings.current.voiceLang.label
        return when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                "I did not hear anything. Tap the orb and try again."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
            SpeechRecognizer.ERROR_SERVER, SpeechRecognizer.ERROR_SERVER_DISCONNECTED ->
                "Speech recognition could not work without internet. Either the offline language pack " +
                    "is not installed, or the speech service needs the network. Install an offline pack in " +
                    "the Google app's voice settings, or turn on internet."
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
                "The speech service does not have $lang available right now. Install its offline pack " +
                    "or choose another voice language in Settings."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "Microphone permission is missing. Grant it in Settings > Permissions."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                "The speech service is busy. Wait a moment and try again."
            SpeechRecognizer.ERROR_AUDIO ->
                "There was a microphone problem. Another app may be using the microphone."
            SpeechRecognizer.ERROR_TOO_MANY_REQUESTS ->
                "Too many speech requests. Wait a moment."
            else -> "Speech recognition failed (code $code)."
        }
    }

    // ---- text to speech ----

    private fun ensureTts(): TextToSpeech {
        tts?.let { return it }
        lateinit var created: TextToSpeech
        created = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                created.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        utteranceId?.let { pending.remove(it)?.complete(Unit) }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        utteranceId?.let { pending.remove(it)?.complete(Unit) }
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        utteranceId?.let { pending.remove(it)?.complete(Unit) }
                    }
                })
            }
        }
        tts = created
        return created
    }

    /** Speaks [text] and returns when speech finishes, fails or is stopped. */
    suspend fun speakAndWait(text: String) {
        val engine = ensureTts()
        val ready = withTimeoutOrNull(4000) {
            while (!ttsReady) delay(50)
            true
        }
        if (ready != true) return
        val clean = SpeechText.clean(text).take(2500)
        if (clean.isBlank()) return
        applyVoice(engine, clean)
        val id = UUID.randomUUID().toString()
        val done = CompletableDeferred<Unit>()
        pending[id] = done
        _speaking.value = true
        try {
            val result = engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
            if (result != TextToSpeech.SUCCESS) return
            done.await()
        } finally {
            pending.remove(id)
            if (!done.isCompleted) engine.stop()
            _speaking.value = false
        }
    }

    fun stopSpeaking() {
        tts?.stop()
        pending.values.forEach { it.complete(Unit) }
        pending.clear()
        _speaking.value = false
    }

    /** Language first (it resets the voice), then the voice the user picked, then speed and pitch. */
    private fun applyVoice(engine: TextToSpeech, text: String) {
        selectLanguage(engine, text)
        val s = settings.current
        engine.setSpeechRate(s.ttsRate)
        engine.setPitch(s.ttsPitch)
        if (s.ttsVoice.isNotBlank()) {
            val chosen = runCatching { engine.voices }.getOrNull()?.firstOrNull { it.name == s.ttsVoice }
            // Use the picked voice only for the language it speaks (a Hindi text needs a Hindi voice).
            if (chosen != null && (chosen.locale.language == "hi") == SpeechText.looksDevanagari(text)) {
                runCatching { engine.setVoice(chosen) }
            }
        }
    }

    data class VoiceOption(val name: String, val label: String)

    /** English and Hindi voices installed on the phone, best quality first. */
    suspend fun listVoices(): List<VoiceOption> {
        val engine = ensureTts()
        val ready = withTimeoutOrNull(4000) {
            while (!ttsReady) delay(50)
            true
        }
        if (ready != true) return emptyList()
        val all = runCatching { engine.voices }.getOrNull() ?: return emptyList()
        return all
            .filter { it.locale.language == "en" || it.locale.language == "hi" }
            .sortedWith(
                compareByDescending<android.speech.tts.Voice> { it.quality }
                    .thenBy { it.isNetworkConnectionRequired }
                    .thenBy { it.name }
            )
            .take(14)
            .map {
                val net = if (it.isNetworkConnectionRequired) ", needs internet" else ", offline"
                VoiceOption(it.name, "${it.locale.displayName}  (${it.name}$net)")
            }
    }

    /** Plays a short sample so the user can hear the current voice settings. */
    suspend fun speakSample() {
        speakAndWait("Hello, I am Jarvis, your personal assistant. Main aapki madad ke liye taiyaar hoon.")
    }

    private fun selectLanguage(engine: TextToSpeech, text: String) {
        val candidates = if (SpeechText.looksDevanagari(text)) {
            listOf(Locale("hi", "IN"))
        } else {
            listOf(Locale("en", "IN"), Locale.US)
        }
        for (l in candidates) {
            if (engine.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = l
                return
            }
        }
    }

    /** Plain-language status of what the phone's speech services can do, for the Settings screen. */
    suspend fun diagnostics(): String {
        val engine = ensureTts()
        val ready = withTimeoutOrNull(4000) {
            while (!ttsReady) delay(50)
            true
        }
        val sb = StringBuilder()
        sb.append(
            if (isRecognitionAvailable()) "Speech recognition service: found.\n"
            else "Speech recognition service: NOT found.\n"
        )
        if (ready == true) {
            fun avail(l: Locale) = engine.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE
            sb.append("Text-to-speech: ready. Hindi voice: ${if (avail(Locale("hi", "IN"))) "available" else "not available"}. ")
            sb.append("English (India): ${if (avail(Locale("en", "IN"))) "available" else "not available"}.\n")
        } else {
            sb.append("Text-to-speech: not ready (no TTS engine, or it is still starting).\n")
        }
        sb.append("Offline recognition cannot be checked on Android 12. Try the voice button with internet off to test it.")
        return sb.toString()
    }

    fun release() {
        destroyRecognizer()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }
}
