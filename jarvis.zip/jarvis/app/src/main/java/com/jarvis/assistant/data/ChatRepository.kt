package com.jarvis.assistant.data

import com.jarvis.assistant.ai.ChatTurn
import com.jarvis.assistant.security.KeystoreCrypto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class ConversationItem(val id: Long, val title: String, val updatedAt: Long)
data class StoredMessage(
    val id: Long,
    val isUser: Boolean,
    val text: String,
    val source: String,
    val createdAt: Long
)
data class FactItem(val id: Long, val text: String)

/** Local-only storage. Text is encrypted before it reaches the database. */
class ChatRepository(private val db: JarvisDatabase, private val crypto: KeystoreCrypto) {

    fun conversations(): Flow<List<ConversationItem>> =
        db.conversationDao().observeAll()
            .map { list -> list.map { ConversationItem(it.id, crypto.decrypt(it.titleCipher), it.updatedAt) } }
            .flowOn(Dispatchers.Default)

    suspend fun createConversation(title: String): Long = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        db.conversationDao().insert(
            ConversationEntity(
                titleCipher = crypto.encrypt(title.take(60).ifBlank { "Chat" }),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun addMessage(conversationId: Long, isUser: Boolean, text: String, source: String) =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            db.messageDao().insert(
                MessageEntity(
                    conversationId = conversationId,
                    isUser = isUser,
                    textCipher = crypto.encrypt(text),
                    source = source,
                    createdAt = now
                )
            )
            db.conversationDao().touch(conversationId, now)
        }

    suspend fun messages(conversationId: Long): List<StoredMessage> = withContext(Dispatchers.IO) {
        db.messageDao().forConversation(conversationId).map {
            StoredMessage(it.id, it.isUser, crypto.decrypt(it.textCipher), it.source, it.createdAt)
        }
    }

    /** Most recent turns, oldest first, bounded by turn count and total characters. */
    suspend fun recentTurns(conversationId: Long, maxTurns: Int = 10, maxChars: Int = 3000): List<ChatTurn> =
        withContext(Dispatchers.IO) {
            val newestFirst = db.messageDao().lastN(conversationId, maxTurns)
            var budget = maxChars
            val kept = ArrayList<ChatTurn>()
            for (m in newestFirst) {
                val text = crypto.decrypt(m.textCipher)
                if (text.length > budget) break
                budget -= text.length
                kept.add(ChatTurn(m.isUser, text))
            }
            kept.reversed()
        }

    suspend fun deleteConversation(id: Long) = withContext(Dispatchers.IO) {
        db.conversationDao().delete(id)
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        db.conversationDao().deleteAll()
    }

    // ---- Memory facts (only saved after the user confirms) ----

    fun facts(): Flow<List<FactItem>> =
        db.factDao().observeAll()
            .map { list -> list.map { FactItem(it.id, crypto.decrypt(it.textCipher)) } }
            .flowOn(Dispatchers.Default)

    suspend fun factTexts(): List<String> = withContext(Dispatchers.IO) {
        db.factDao().all().map { crypto.decrypt(it.textCipher) }
    }

    suspend fun addFact(text: String): Boolean = withContext(Dispatchers.IO) {
        if (db.factDao().count() >= MAX_FACTS) return@withContext false
        db.factDao().insert(
            FactEntity(textCipher = crypto.encrypt(text.take(300)), createdAt = System.currentTimeMillis())
        )
        true
    }

    suspend fun deleteFact(id: Long) = withContext(Dispatchers.IO) { db.factDao().delete(id) }

    suspend fun clearFacts() = withContext(Dispatchers.IO) { db.factDao().deleteAll() }

    // ---- Audit ----

    fun audit(limit: Int = 100) = db.auditDao().observeRecent(limit)

    suspend fun clearAudit() = withContext(Dispatchers.IO) { db.auditDao().deleteAll() }

    // ---- Retention and export ----

    /** Deletes conversations (and their messages) not touched for [days] days. 0 means keep forever. */
    suspend fun purge(days: Int) = withContext(Dispatchers.IO) {
        if (days <= 0) return@withContext
        val cutoff = System.currentTimeMillis() - days * DAY_MS
        db.conversationDao().deleteOlderThan(cutoff)
        db.auditDao().deleteOlderThan(System.currentTimeMillis() - maxOf(days, 30) * DAY_MS)
    }

    suspend fun exportJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("app", "JARVIS")
        root.put("exportedAt", System.currentTimeMillis())
        val convs = JSONArray()
        for (c in db.conversationDao().all()) {
            val msgs = JSONArray()
            for (m in db.messageDao().forConversation(c.id)) {
                msgs.put(
                    JSONObject()
                        .put("role", if (m.isUser) "user" else "assistant")
                        .put("text", crypto.decrypt(m.textCipher))
                        .put("source", m.source)
                        .put("time", m.createdAt)
                )
            }
            convs.put(
                JSONObject()
                    .put("title", crypto.decrypt(c.titleCipher))
                    .put("createdAt", c.createdAt)
                    .put("messages", msgs)
            )
        }
        root.put("conversations", convs)
        val facts = JSONArray()
        for (f in db.factDao().all()) facts.put(crypto.decrypt(f.textCipher))
        root.put("facts", facts)
        root.toString(2)
    }

    private companion object {
        const val DAY_MS = 24L * 60 * 60 * 1000
        const val MAX_FACTS = 30
    }
}
