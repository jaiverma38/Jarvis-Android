package com.jarvis.assistant.util

/**
 * The butler-style voice of the assistant: how it addresses the user and its short stock phrases.
 * Pure Kotlin. The model gets the same style through its system prompt; these phrases make the
 * instant answers and action confirmations sound the same.
 */
object Persona {
    /** How the user wants to be addressed: "sir", "boss" or "Jai". Set from Settings. */
    @Volatile
    var address: String = "sir"

    private val acks = listOf("Certainly", "Right away", "Of course", "As you wish", "Very good")
    private val wakeAcks = listOf("Yes, %s?", "At your service, %s.", "How may I help, %s?")

    fun ack(): String = "${acks.random()}, $address."

    fun apology(): String = "My apologies, $address."

    fun wakeAck(): String = wakeAcks.random().format(address)

    /** The same address written in Devanagari, for Hindi replies. */
    fun addressHindi(): String = when (address.lowercase()) {
        "sir" -> "सर"
        "boss" -> "बॉस"
        "jai" -> "जय"
        else -> address
    }

    fun timeGreeting(hour: Int): String = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Hello"
    }
}
