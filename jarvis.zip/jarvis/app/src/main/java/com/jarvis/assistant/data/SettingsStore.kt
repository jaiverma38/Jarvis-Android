package com.jarvis.assistant.data

import android.content.Context
import com.jarvis.assistant.ai.ModelRegistry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * OFFLINE: only the on-device model is ever used. The AI never touches the network.
 * ONLINE:  only the selected online provider is used.
 * AUTO:    online provider when internet and a key are available, otherwise on-device.
 * The answer bubble always shows which one answered.
 */
enum class AiMode { OFFLINE, ONLINE, AUTO }

enum class OnlineKind { GEMINI, OPENAI_COMPAT }

enum class VoiceLang(val tag: String, val label: String) {
    EN_IN("en-IN", "English (India), also for Hinglish"),
    HI_IN("hi-IN", "Hindi (हिन्दी)"),
    EN_US("en-US", "English (US)")
}

enum class WakeSensitivity(val label: String) {
    LOW("Low: fewer false wake-ups, may miss some"),
    MEDIUM("Medium (recommended)"),
    HIGH("High: wakes more easily, more false wake-ups")
}

data class AppSettings(
    val aiMode: AiMode = AiMode.OFFLINE,
    val onlineKind: OnlineKind = OnlineKind.GEMINI,
    val geminiModel: String = "gemini-flash-latest",
    val openAiBaseUrl: String = "https://integrate.api.nvidia.com/v1",
    val openAiModel: String = "meta/llama-3.1-8b-instruct",
    val selectedModelId: String = ModelRegistry.default.id,
    val useGpu: Boolean = false,
    val voiceLang: VoiceLang = VoiceLang.EN_IN,
    val preferOfflineSpeech: Boolean = true,
    val speakReplies: Boolean = true,
    val conversationMode: Boolean = false,
    val retentionDays: Int = 0,
    val notificationReading: Boolean = false,
    val wakeEnabled: Boolean = false,
    val wakeSensitivity: WakeSensitivity = WakeSensitivity.MEDIUM,
    /** Look up Wikipedia/DuckDuckGo (no key) to help the on-device model answer factual questions. */
    val webSearch: Boolean = true,
    /** Name of the chosen text-to-speech voice; empty means the phone's default voice. */
    val ttsVoice: String = "",
    val ttsRate: Float = 0.95f,
    val ttsPitch: Float = 0.85f,
    /** How JARVIS addresses the user: "sir", "boss" or "Jai". */
    val addressAs: String = "sir",
    /** Say a greeting when JARVIS is opened (at most once every few hours). */
    val greetOnOpen: Boolean = true,
    val lastGreetMs: Long = 0L,
    val lastBenchmark: String = ""
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()
    val current: AppSettings get() = _state.value

    @Synchronized
    fun update(block: (AppSettings) -> AppSettings) {
        val next = block(_state.value)
        _state.value = next
        save(next)
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            aiMode = enumOr(prefs.getString("aiMode", null), d.aiMode),
            onlineKind = enumOr(prefs.getString("onlineKind", null), d.onlineKind),
            geminiModel = prefs.getString("geminiModel", d.geminiModel) ?: d.geminiModel,
            openAiBaseUrl = prefs.getString("openAiBaseUrl", d.openAiBaseUrl) ?: d.openAiBaseUrl,
            openAiModel = prefs.getString("openAiModel", d.openAiModel) ?: d.openAiModel,
            selectedModelId = prefs.getString("selectedModelId", d.selectedModelId) ?: d.selectedModelId,
            useGpu = prefs.getBoolean("useGpu", d.useGpu),
            voiceLang = enumOr(prefs.getString("voiceLang", null), d.voiceLang),
            preferOfflineSpeech = prefs.getBoolean("preferOfflineSpeech", d.preferOfflineSpeech),
            speakReplies = prefs.getBoolean("speakReplies", d.speakReplies),
            conversationMode = prefs.getBoolean("conversationMode", d.conversationMode),
            retentionDays = prefs.getInt("retentionDays", d.retentionDays),
            notificationReading = prefs.getBoolean("notificationReading", d.notificationReading),
            wakeEnabled = prefs.getBoolean("wakeEnabled", d.wakeEnabled),
            wakeSensitivity = enumOr(prefs.getString("wakeSensitivity", null), d.wakeSensitivity),
            webSearch = prefs.getBoolean("webSearch", d.webSearch),
            ttsVoice = prefs.getString("ttsVoice", d.ttsVoice) ?: d.ttsVoice,
            ttsRate = prefs.getFloat("ttsRate", d.ttsRate),
            ttsPitch = prefs.getFloat("ttsPitch", d.ttsPitch),
            addressAs = prefs.getString("addressAs", d.addressAs) ?: d.addressAs,
            greetOnOpen = prefs.getBoolean("greetOnOpen", d.greetOnOpen),
            lastGreetMs = prefs.getLong("lastGreetMs", d.lastGreetMs),
            lastBenchmark = prefs.getString("lastBenchmark", d.lastBenchmark) ?: d.lastBenchmark
        )
    }

    private fun save(s: AppSettings) {
        prefs.edit()
            .putString("aiMode", s.aiMode.name)
            .putString("onlineKind", s.onlineKind.name)
            .putString("geminiModel", s.geminiModel)
            .putString("openAiBaseUrl", s.openAiBaseUrl)
            .putString("openAiModel", s.openAiModel)
            .putString("selectedModelId", s.selectedModelId)
            .putBoolean("useGpu", s.useGpu)
            .putString("voiceLang", s.voiceLang.name)
            .putBoolean("preferOfflineSpeech", s.preferOfflineSpeech)
            .putBoolean("speakReplies", s.speakReplies)
            .putBoolean("conversationMode", s.conversationMode)
            .putInt("retentionDays", s.retentionDays)
            .putBoolean("notificationReading", s.notificationReading)
            .putBoolean("wakeEnabled", s.wakeEnabled)
            .putString("wakeSensitivity", s.wakeSensitivity.name)
            .putBoolean("webSearch", s.webSearch)
            .putString("ttsVoice", s.ttsVoice)
            .putFloat("ttsRate", s.ttsRate)
            .putFloat("ttsPitch", s.ttsPitch)
            .putString("addressAs", s.addressAs)
            .putBoolean("greetOnOpen", s.greetOnOpen)
            .putLong("lastGreetMs", s.lastGreetMs)
            .putString("lastBenchmark", s.lastBenchmark)
            .apply()
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: fallback
}
