package com.jarvis.assistant.api

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.container
import com.jarvis.assistant.security.SecretNames

/** Keeps the Jarvis API server running in the background, with a permanent notification and a Stop button. */
class ApiService : Service() {
    private var server: JarvisApiServer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val c = container()
        if (intent?.action == ACTION_STOP) {
            c.settings.update { it.copy(apiServerEnabled = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification(), type)
            val s = JarvisApiServer(c.chat, { c.secrets.get(SecretNames.JARVIS_API) })
            s.start()
            server = s
        } catch (e: Exception) {
            c.settings.update { it.copy(apiServerEnabled = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 3, Intent(this, ApiService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = "Other devices on this Wi-Fi can use this phone's models with your Jarvis key."
        return NotificationCompat.Builder(this, JarvisApp.CHANNEL_WAKE)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle("JARVIS API is ON")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .addAction(0, "Turn off", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        server?.stop()
        server = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.jarvis.assistant.action.STOP_API"
        const val NOTIFICATION_ID = 1003
    }
}
