package com.jarvis.assistant.skills

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A user-made shortcut: saying [trigger] runs each of [steps] (ordinary JARVIS commands) one after another. */
data class Skill(val trigger: String, val steps: List<String>)

/** Stores skills on the phone only (private app storage). Steps are plain command text, never code. */
class SkillStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("jarvis_skills", Context.MODE_PRIVATE)

    @Synchronized
    fun all(): List<Skill> {
        val raw = prefs.getString("skills", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val steps = o.getJSONArray("steps")
                Skill(o.getString("trigger"), (0 until steps.length()).map { steps.getString(it) })
            }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun save(skill: Skill) {
        val list = all().filterNot { it.trigger == skill.trigger } + skill
        write(list.takeLast(MAX_SKILLS))
    }

    @Synchronized
    fun delete(trigger: String): Boolean {
        val before = all()
        val after = before.filterNot { it.trigger == trigger }
        if (after.size == before.size) return false
        write(after)
        return true
    }

    fun find(spoken: String): Skill? {
        val key = Extras.normalizeTrigger(spoken)
        return all().firstOrNull { it.trigger == key }
    }

    private fun write(list: List<Skill>) {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(JSONObject().put("trigger", s.trigger).put("steps", JSONArray(s.steps)))
        }
        prefs.edit().putString("skills", arr.toString()).apply()
    }

    companion object {
        const val MAX_SKILLS = 30
    }
}
