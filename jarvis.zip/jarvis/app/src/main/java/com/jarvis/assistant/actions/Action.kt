package com.jarvis.assistant.actions

/**
 * The complete list of things JARVIS can do on the phone. There is no generic "run command",
 * no shell and no code execution: the model's text can never become an action. Only a clear
 * user command parsed by [CommandParser] can produce one of these.
 */
sealed interface Action {
    data class OpenApp(val query: String) : Action
    data class OpenSettings(val panel: SettingsPanel) : Action
    data class Torch(val on: Boolean?) : Action
    data class Volume(val mode: VolumeMode, val percent: Int?) : Action
    data class Brightness(val mode: BrightnessMode, val percent: Int?) : Action
    data class Timer(val seconds: Int) : Action
    data class Alarm(val hour: Int, val minute: Int) : Action
    data class DeviceInfo(val topic: InfoTopic) : Action
    data class Dial(val number: String) : Action
    data class ComposeSms(val number: String, val body: String) : Action
    data class CloseApp(val query: String) : Action
    data class PlayMusic(val song: String, val app: String?) : Action
    data class MediaControl(val command: MediaCommand) : Action
    data class WhatsAppCall(val contact: String, val video: Boolean) : Action
    data class WhatsAppMessage(val contact: String, val body: String) : Action
    data object ReadNotifications : Action
    data class Remember(val text: String) : Action
    data object Help : Action
}

enum class MediaCommand { PLAY, PAUSE, NEXT, PREVIOUS }
enum class SettingsPanel { ROOT, WIFI, BLUETOOTH, DISPLAY, SOUND, BATTERY, LOCATION, APPS, STORAGE, NFC }
enum class VolumeMode { UP, DOWN, SET, MUTE }
enum class BrightnessMode { UP, DOWN, SET }
enum class InfoTopic { ALL, BATTERY, STORAGE, MEMORY, NETWORK }

enum class Risk {
    /** Runs immediately. Easily reversible and harmless. */
    LOW,

    /** Needs an explicit Confirm tap on screen first. */
    CONFIRM
}

fun Action.risk(): Risk = when (this) {
    is Action.Brightness,
    is Action.Dial,
    is Action.ComposeSms,
    is Action.WhatsAppCall,
    is Action.WhatsAppMessage,
    is Action.Remember,
    Action.ReadNotifications -> Risk.CONFIRM
    else -> Risk.LOW
}
