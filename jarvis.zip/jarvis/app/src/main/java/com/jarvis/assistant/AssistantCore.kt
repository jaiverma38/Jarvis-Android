package com.jarvis.assistant

import com.jarvis.assistant.actions.Action
import com.jarvis.assistant.actions.Risk
import com.jarvis.assistant.actions.risk
import com.jarvis.assistant.ai.ChatRequest
import com.jarvis.assistant.ai.Prompts
import com.jarvis.assistant.ai.Route
import com.jarvis.assistant.data.ConversationItem
import com.jarvis.assistant.data.StoredMessage
import com.jarvis.assistant.util.Errors
import com.jarvis.assistant.util.Persona
import com.jarvis.assistant.util.ThinkFilter
import kotlinx.coroutines.withTimeoutOrNull
import com.jarvis.assistant.voice.VoiceController
import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

data class UiMessage(val id: Long, val isUser: Boolean, val text: String, val source: String)

data class ChatUiState(
    val messages: List<UiMessage> = emptyList(),
    val phase: Phase = Phase.IDLE,
    val partial: String = "",
    val banner: String? = null,
    val pendingAction: Action? = null,
    val pendingDescription: String = "",
    val benchmarkRunning: Boolean = false,
    val loadingModel: Boolean = false,
    val voiceInfo: String = ""
)

/**
 * The assistant's brain: chat, voice commands and phone actions. It lives as long as the app process (not the
 * screen), so a "Hey Jarvis" command still works when the app is in the background.
 */
class AssistantCore(private val c: AppContainer) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)


    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    /** Emitted in conversation mode: the screen should open the microphone again. */
    private val _listenAgain = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val listenAgain: SharedFlow<Unit> = _listenAgain.asSharedFlow()

    private var conversationId: Long? = null
    private var nextId = 1L
    private var job: Job? = null

    /** True when this conversation turn was started by "Hey Jarvis": always answer aloud. */
    private var forceSpeak = false

    init {
        // Load the on-device model in the background at start, so the first answer is not slow.
        scope.launch {
            delay(1500)
            if (c.settings.current.aiMode != com.jarvis.assistant.data.AiMode.ONLINE && c.local.isModelInstalled()) {
                runCatching { c.local.preload() }
            }
        }
        // Whenever the assistant is idle again, start listening for "Hey Jarvis" again (if switched on).
        scope.launch {
            state.map { it.phase }.distinctUntilChanged().collect { if (it == Phase.IDLE) c.wake.resume() }
        }
        scope.launch {
            c.voice.events.collect { ev ->
                when (ev) {
                    is VoiceController.Event.Partial -> _state.update { it.copy(partial = ev.text) }
                    is VoiceController.Event.Final -> {
                        c.stopListeningService()
                        _state.update { it.copy(partial = "", phase = Phase.IDLE) }
                        send(ev.text, spoken = true)
                    }
                    is VoiceController.Event.Failure -> {
                        forceSpeak = false
                        c.stopListeningService()
                        _state.update { it.copy(partial = "", phase = Phase.IDLE, banner = ev.message) }
                    }
                    VoiceController.Event.Stopped -> {
                        c.stopListeningService()
                        _state.update { it.copy(partial = "", phase = Phase.IDLE) }
                    }
                }
            }
        }
    }

    // ---- voice ----

    fun toggleVoice() {
        when (_state.value.phase) {
            Phase.LISTENING -> c.voice.stopListening()
            Phase.SPEAKING -> {
                c.voice.stopSpeaking()
                _state.update { it.copy(phase = Phase.IDLE) }
            }
            Phase.THINKING -> stopGenerating()
            Phase.IDLE -> startVoice()
        }
    }

    /** The screen must hold the RECORD_AUDIO permission before calling this. */
    fun startVoice() {
        c.voice.stopSpeaking()
        // Release the microphone from the wake word listener first.
        c.wake.pauseForCommand()
        _state.update { it.copy(phase = Phase.LISTENING, partial = "", banner = null) }
        c.startListeningService()
        c.voice.startListening()
    }

    /** Called when "Hey Jarvis" was heard. The wake listener has already released the microphone. */
    fun startFromWake() {
        if (_state.value.phase != Phase.IDLE) {
            c.wake.resume()
            return
        }
        forceSpeak = true
        c.voice.stopSpeaking()
        _state.update { it.copy(phase = Phase.LISTENING, partial = "", banner = null) }
        Persona.address = c.settings.current.addressAs
        scope.launch {
            // Say "Yes, sir?" and then listen. If speech is not ready within 2.5 s, fall back to the beep.
            val spoke = withTimeoutOrNull(2500) { c.voice.speakAndWait(Persona.wakeAck()); true }
            if (spoke == null) beep()
            delay(200)
            if (_state.value.phase == Phase.LISTENING) c.voice.startListening()
        }
    }

    /** A spoken or written greeting when the app is opened, at most once every four hours. */
    fun greetOnOpen() {
        val s = c.settings.current
        val now = System.currentTimeMillis()
        if (!s.greetOnOpen || now - s.lastGreetMs < 4 * 3_600_000L) return
        if (_state.value.phase != Phase.IDLE) return
        c.settings.update { it.copy(lastGreetMs = now) }
        Persona.address = s.addressAs
        val hour = java.time.LocalTime.now().hour
        val text = "${Persona.timeGreeting(hour)}, ${Persona.address}. Welcome back. All systems are online."
        scope.launch { reply(text, "JARVIS", spoken = true) }
    }

    /** A short tone so you know JARVIS heard the wake phrase and is now listening. */
    private fun beep() {
        runCatching {
            val g = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            g.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            scope.launch {
                delay(500)
                g.release()
            }
        }
    }

    fun checkVoice() {
        scope.launch {
            val text = c.voice.diagnostics()
            _state.update { it.copy(voiceInfo = text) }
        }
    }

    // ---- sending ----

    fun send(raw: String, spoken: Boolean = false) {
        val text = raw.trim().take(2000)
        if (text.isEmpty() || _state.value.phase == Phase.THINKING) return
        c.voice.stopSpeaking()
        Persona.address = c.settings.current.addressAs
        Persona.hindiDevanagari = c.settings.current.hindiInDevanagari
        job = scope.launch {
            appendUi(UiMessage(nextId++, true, text, ""))
            val convId = ensureConversation(text)
            val history = c.repo.recentTurns(convId).let {
                if (it.isNotEmpty() && it.last().isUser && it.last().text == text) it.dropLast(1) else it
            }
            c.repo.addMessage(convId, true, text, "")

            val action = CommandParser(text)
            val identity = com.jarvis.assistant.util.SmallTalk.answer(text)
            if (action != null) {
                handleAction(action, spoken)
            } else if (identity != null) {
                _state.update { it.copy(phase = Phase.THINKING) }
                reply(identity, "JARVIS", spoken)
            } else {
                // Only the last few turns go to the model: a shorter prompt makes the first word arrive sooner.
                chat(convId, text, history.takeLast(6), spoken)
            }
        }
    }

    private fun CommandParser(text: String): Action? = com.jarvis.assistant.actions.CommandParser.parse(text)

    private suspend fun handleAction(action: Action, spoken: Boolean) {
        if (action.risk() == Risk.CONFIRM) {
            _state.update {
                it.copy(pendingAction = action, pendingDescription = c.actions.describe(action), phase = Phase.IDLE)
            }
            if (!c.uiVisible) {
                // No screen to show the Confirm dialog on: say so and keep the request waiting in the app.
                reply("That needs your confirmation. Open JARVIS to confirm it.", "Phone", spoken)
            }
            return
        }
        runAction(action, spoken)
    }

    private suspend fun runAction(action: Action, spoken: Boolean) {
        _state.update { it.copy(phase = Phase.THINKING) }
        val result = c.actions.execute(action)
        // Butler-style wrapper: a short acknowledgement before the result, an apology before a failure.
        val plain = action is Action.DeviceInfo || action == Action.Help ||
            action == Action.ReadNotifications || action is Action.Remember
        val message = when {
            !result.ok -> Persona.apology() + " " + result.message
            plain -> result.message
            else -> Persona.ack() + " " + result.message
        }
        reply(message, "Phone", spoken)
    }

    fun confirmPending() {
        val a = _state.value.pendingAction ?: return
        _state.update { it.copy(pendingAction = null, pendingDescription = "") }
        job = scope.launch { runAction(a, spoken = false) }
    }

    fun cancelPending() {
        if (_state.value.pendingAction == null) return
        _state.update { it.copy(pendingAction = null, pendingDescription = "") }
        scope.launch { reply("Cancelled. Nothing was changed.", "Phone", false) }
    }

    private suspend fun chat(convId: Long, text: String, history: List<com.jarvis.assistant.ai.ChatTurn>, spoken: Boolean) {
        _state.update { it.copy(phase = Phase.THINKING, banner = null) }
        when (val route = c.chat.route()) {
            is Route.Blocked -> reply(route.reason, "System", false)
            is Route.Use -> {
                val provider = route.provider
                val facts = c.repo.factTexts()
                val answerId = nextId++
                // Keyless web lookup only helps the on-device model; cloud models already know the facts.
                val useWeb = provider.id == "local" && c.settings.current.webSearch &&
                    com.jarvis.assistant.ai.WebSearch.wantsSearch(text)
                val online = c.network.isOnline()
                appendUi(UiMessage(answerId, false, if (useWeb && online) "Searching the web…" else "…", provider.label))
                val web = if (useWeb && online) com.jarvis.assistant.ai.WebSearch.search(text) else null
                if (useWeb && online) replaceUi(answerId, "…")
                val request = ChatRequest(
                    systemPrompt = Prompts.system(facts, Persona.address),
                    history = history,
                    userText = (web?.promptFor(text)
                        ?: if (useWeb) com.jarvis.assistant.ai.WebContext.failedPrompt(text, online) else text) +
                        "\n\n" + com.jarvis.assistant.util.ReplyStyle.hint(
                            text, com.jarvis.assistant.util.LangDetect.of(text), Persona.hindiDevanagari
                        ),
                    // A web turn carries long search text, so its conversation is rebuilt from clean history next time.
                    sessionKey = "$convId:${facts.hashCode()}" + if (useWeb) ":w$answerId" else ""
                )
                var last = ""
                try {
                    provider.generate(request).collect { partial ->
                        last = partial
                        val visible = ThinkFilter.strip(partial)
                        if (visible.isNotEmpty()) replaceUi(answerId, visible)
                    }
                    val finalText = ThinkFilter.strip(last).ifBlank { "I do not have an answer for that." }
                    val shown = if (web != null) finalText + "\n\nSource: " + web.sourceLine() else finalText
                    replaceUi(answerId, shown)
                    c.repo.addMessage(convId, false, shown, provider.label)
                    speakIfWanted(finalText, spoken)
                } catch (e: CancellationException) {
                    val partialText = ThinkFilter.strip(last)
                    if (partialText.isBlank()) removeUi(answerId) else {
                        replaceUi(answerId, "$partialText (stopped)")
                        c.repo.addMessage(convId, false, "$partialText (stopped)", provider.label)
                    }
                    _state.update { it.copy(phase = Phase.IDLE) }
                    throw e
                } catch (e: Throwable) {
                    val msg = Errors.friendly(e)
                    replaceUi(answerId, msg)
                    _state.update { it.copy(phase = Phase.IDLE) }
                }
            }
        }
        if (_state.value.phase == Phase.THINKING) _state.update { it.copy(phase = Phase.IDLE) }
    }

    private suspend fun reply(text: String, source: String, spoken: Boolean) {
        appendUi(UiMessage(nextId++, false, text, source))
        conversationId?.let { c.repo.addMessage(it, false, text, source) }
        speakIfWanted(text, spoken)
        if (_state.value.phase == Phase.THINKING) _state.update { it.copy(phase = Phase.IDLE) }
    }

    private suspend fun speakIfWanted(text: String, spoken: Boolean) {
        val wanted = spoken && (c.settings.current.speakReplies || forceSpeak)
        if (!wanted) {
            forceSpeak = false
            _state.update { it.copy(phase = Phase.IDLE) }
            return
        }
        _state.update { it.copy(phase = Phase.SPEAKING) }
        c.voice.speakAndWait(text)
        forceSpeak = false
        _state.update { if (it.phase == Phase.SPEAKING) it.copy(phase = Phase.IDLE) else it }
        if (c.settings.current.conversationMode) _listenAgain.tryEmit(Unit)
    }

    fun stopGenerating() {
        job?.cancel()
        c.voice.stopSpeaking()
        _state.update { it.copy(phase = Phase.IDLE) }
    }

    // ---- conversations ----

    private suspend fun ensureConversation(firstText: String): Long {
        conversationId?.let { return it }
        val id = c.repo.createConversation(firstText)
        conversationId = id
        return id
    }

    fun newChat() {
        stopGenerating()
        conversationId = null
        _state.update { it.copy(messages = emptyList(), partial = "", banner = null) }
        scope.launch { c.local.resetSession() }
    }

    fun openConversation(item: ConversationItem) {
        stopGenerating()
        scope.launch {
            val stored: List<StoredMessage> = c.repo.messages(item.id)
            conversationId = item.id
            _state.update {
                it.copy(
                    messages = stored.map { m -> UiMessage(nextId++, m.isUser, m.text, m.source) },
                    banner = null
                )
            }
            c.local.resetSession()
        }
    }

    fun deleteConversation(item: ConversationItem) {
        scope.launch {
            c.repo.deleteConversation(item.id)
            if (conversationId == item.id) newChat()
        }
    }

    fun clearAllHistory() {
        scope.launch {
            c.repo.clearHistory()
            newChat()
        }
    }

    fun dismissBanner() = _state.update { it.copy(banner = null) }

    // ---- models ----

    fun loadModel() {
        if (_state.value.loadingModel) return
        scope.launch {
            _state.update { it.copy(loadingModel = true) }
            try {
                c.local.preload()
            } catch (e: Throwable) {
                _state.update { it.copy(banner = "Could not load the model: " + Errors.friendly(e)) }
            } finally {
                _state.update { it.copy(loadingModel = false) }
            }
        }
    }

    fun unloadModel() {
        scope.launch { c.local.unload() }
    }

    fun runBenchmark() {
        if (_state.value.benchmarkRunning) return
        scope.launch {
            _state.update { it.copy(benchmarkRunning = true, banner = null) }
            try {
                val r = c.local.benchmark()
                c.settings.update { it.copy(lastBenchmark = r.summary()) }
            } catch (e: Throwable) {
                _state.update { it.copy(banner = "Benchmark failed: " + Errors.friendly(e)) }
            } finally {
                _state.update { it.copy(benchmarkRunning = false) }
            }
        }
    }

    fun deleteModel(spec: com.jarvis.assistant.ai.ModelSpec) {
        scope.launch {
            if (c.models.selectedSpec().id == spec.id) c.local.unload()
            if (spec.custom) c.models.removeCustom(spec) else c.models.delete(spec)
        }
    }

    // ---- ui list helpers ----

    private fun appendUi(m: UiMessage) = _state.update { it.copy(messages = it.messages + m) }

    private fun replaceUi(id: Long, text: String) = _state.update { s ->
        s.copy(messages = s.messages.map { if (it.id == id) it.copy(text = text) else it })
    }

    private fun removeUi(id: Long) = _state.update { s -> s.copy(messages = s.messages.filterNot { it.id == id }) }
}
