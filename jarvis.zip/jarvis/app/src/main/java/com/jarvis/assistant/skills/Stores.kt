package com.jarvis.assistant.skills

import android.content.Context
import com.jarvis.assistant.actions.Action
import org.json.JSONObject

/**
 * Nicknames for contacts: "didi" -> "Priya Sharma". When you say "didi ko call karo", JARVIS looks up
 * "Priya Sharma" in your contacts. Stored on the phone only. You can add, list and delete them by voice or text.
 */
class AliasStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("jarvis_aliases", Context.MODE_PRIVATE)

    @Synchronized
    fun all(): Map<String, String> {
        val raw = prefs.getString("map", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getString(it) }
        }.getOrDefault(emptyMap())
    }

    @Synchronized
    fun put(nickname: String, realName: String) {
        val m = all().toMutableMap()
        m[key(nickname)] = realName.trim()
        write(m)
    }

    @Synchronized
    fun remove(nickname: String): Boolean {
        val m = all().toMutableMap()
        if (m.remove(key(nickname)) == null) return false
        write(m)
        return true
    }

    fun resolve(contact: String): String = all()[key(contact)] ?: contact

    /** Swaps a nickname for the real contact name inside WhatsApp, dial and SMS actions. */
    fun apply(a: Action): Action = when (a) {
        is Action.WhatsAppCall -> a.copy(contact = resolve(a.contact))
        is Action.WhatsAppMessage -> a.copy(contact = resolve(a.contact))
        else -> a
    }

    private fun write(m: Map<String, String>) {
        prefs.edit().putString("map", JSONObject(m).toString()).apply()
    }

    companion object {
        private val hindiWords = mapOf(
            "दीदी" to "didi", "भैया" to "bhaiya", "भइया" to "bhaiya", "भाई" to "bhai", "मम्मी" to "mummy",
            "पापा" to "papa", "भाभी" to "bhabhi", "माँ" to "maa", "मां" to "maa", "चाचा" to "chacha",
            "मामा" to "mama", "बुआ" to "bua", "नानी" to "nani", "दादी" to "dadi", "दादा" to "dada", "जीजू" to "jiju"
        )

        fun key(raw: String): String {
            val n = Extras.normalizeTrigger(raw)
            return n.split(' ').joinToString(" ") { hindiWords[it] ?: it }
        }
    }
}

/** The public Telegram channels you follow, and the newest post JARVIS has already told you about. */
class TelegramStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("jarvis_telegram", Context.MODE_PRIVATE)

    @Synchronized
    fun all(): Map<String, Int> {
        val raw = prefs.getString("channels", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getInt(it) }
        }.getOrDefault(emptyMap())
    }

    @Synchronized
    fun add(name: String) {
        val m = all().toMutableMap()
        if (name !in m) m[name] = 0
        write(m)
    }

    @Synchronized
    fun remove(name: String): Boolean {
        val m = all().toMutableMap()
        if (m.keys.removeAll { it.equals(name, ignoreCase = true) }.not()) return false
        write(m)
        return true
    }

    @Synchronized
    fun setLastSeen(name: String, id: Int) {
        val m = all().toMutableMap()
        if (name in m) m[name] = id
        write(m)
    }

    private fun write(m: Map<String, Int>) {
        prefs.edit().putString("channels", JSONObject(m as Map<*, *>).toString()).apply()
    }
}
