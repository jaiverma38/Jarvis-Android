package com.jarvis.assistant.ai

import android.content.Context
import android.os.Debug
import android.os.SystemClock
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.LogSeverity
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.SamplerConfig
import com.jarvis.assistant.data.SettingsStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

sealed interface LoadState {
    data object Unloaded : LoadState
    data class Loading(val modelName: String) : LoadState
    data class Ready(val modelName: String, val loadMs: Long, val backend: String) : LoadState
    data class Error(val message: String) : LoadState
}

data class BenchmarkResult(
    val modelName: String,
    val backend: String,
    val loadMs: Long,
    val firstTokenMs: Long,
    val totalMs: Long,
    val outputChars: Int,
    val charsPerSecond: Double,
    val appPssMb: Int
) {
    fun summary(): String =
        "$modelName on $backend. Load ${loadMs} ms, first output ${firstTokenMs} ms, " +
            "about ${"%.1f".format(charsPerSecond)} characters per second " +
            "(${outputChars} chars in ${totalMs} ms), app memory ${appPssMb} MB. " +
            "Characters, not tokens: this is an approximation."
}

/**
 * Runs a .litertlm model fully on the device through Google's LiteRT-LM Kotlin API.
 * Never touches the network. The conversation object is kept between turns so the model
 * keeps its context; it is rebuilt from stored history when the chat changes.
 */
class LiteRtProvider(
    private val ctx: Context,
    private val models: ModelManager,
    private val settings: SettingsStore
) : AiProvider {

    override val id = "local"
    override val label = "On-device"

    private val _loadState = MutableStateFlow<LoadState>(LoadState.Unloaded)
    val loadState: StateFlow<LoadState> = _loadState.asStateFlow()

    private val engineLock = Mutex()
    private var engine: Engine? = null
    private var loadedKey: String? = null

    private var conversation: Conversation? = null
    private var conversationKey: String? = null

    fun isModelInstalled(): Boolean = models.installedPath(models.selectedSpec()) != null

    private suspend fun ensureEngine(): Engine = engineLock.withLock {
        val spec = models.selectedSpec()
        val path = models.installedPath(spec)
            ?: throw IllegalStateException("The selected model is not downloaded. Open the Models tab.")
        val backendName = if (settings.current.useGpu) "GPU" else "CPU"
        val key = "${spec.id}|$backendName"
        engine?.let { if (loadedKey == key) return@withLock it }

        closeConversationLocked()
        engine?.let { runCatching { it.close() } }
        engine = null
        loadedKey = null

        _loadState.value = LoadState.Loading(spec.name)
        try {
            val loaded = withContext(Dispatchers.Default) {
                val t0 = SystemClock.elapsedRealtime()
                runCatching { Engine.setNativeMinLogSeverity(LogSeverity.ERROR) }
                val config = EngineConfig(
                    modelPath = path,
                    backend = if (settings.current.useGpu) Backend.GPU() else Backend.CPU(),
                    cacheDir = ctx.cacheDir.path
                )
                val e = Engine(config)
                e.initialize()
                e to (SystemClock.elapsedRealtime() - t0)
            }
            engine = loaded.first
            loadedKey = key
            _loadState.value = LoadState.Ready(spec.name, loaded.second, backendName)
            loaded.first
        } catch (t: Throwable) {
            _loadState.value = LoadState.Error(
                (t.message ?: t.javaClass.simpleName).take(200) +
                    if (settings.current.useGpu) " (try the CPU backend)" else ""
            )
            throw t
        }
    }

    private fun closeConversationLocked() {
        conversation?.let { runCatching { it.close() } }
        conversation = null
        conversationKey = null
    }

    /** Loads the selected model into RAM now instead of on the first message. */
    suspend fun preload() {
        ensureEngine()
    }

    /** Forget the running conversation. The next message rebuilds context from history. */
    suspend fun resetSession() = engineLock.withLock { closeConversationLocked() }

    /** Frees the model from RAM. */
    suspend fun unload() = engineLock.withLock {
        closeConversationLocked()
        engine?.let { runCatching { it.close() } }
        engine = null
        loadedKey = null
        _loadState.value = LoadState.Unloaded
    }

    private fun systemInstructionFor(request: ChatRequest) = Contents.of(request.systemPrompt)

    private suspend fun conversationFor(eng: Engine, request: ChatRequest): Conversation =
        engineLock.withLock {
            val key = request.sessionKey + "|" + (loadedKey ?: "")
            val existing = conversation
            if (existing != null && conversationKey == key) return@withLock existing
            closeConversationLocked()
            val config = ConversationConfig(
                systemInstruction = systemInstructionFor(request),
                initialMessages = request.history.map {
                    if (it.isUser) Message.user(it.text) else Message.model(it.text)
                },
                samplerConfig = SamplerConfig(topK = 20, topP = 0.9, temperature = 0.7)
            )
            val created = eng.createConversation(config)
            conversation = created
            conversationKey = key
            created
        }

    override fun generate(request: ChatRequest): Flow<String> = flow {
        val eng = ensureEngine()
        val conv = conversationFor(eng, request)
        val spec = models.selectedSpec()
        val userText = if (spec.noThinkSwitch) request.userText + " /no_think" else request.userText
        val acc = StringBuilder()
        try {
            conv.sendMessageAsync(Contents.of(userText)).collect { chunk ->
                acc.append(chunk.text ?: "")
                emit(acc.toString())
            }
        } catch (e: CancellationException) {
            // The model may still be mid-generation; drop the conversation so state stays consistent.
            withContext(kotlinx.coroutines.NonCancellable) { resetSession() }
            throw e
        }
    }.flowOn(Dispatchers.Default)

    /** Measures load time, time to first output and speed on this phone with a fixed prompt. */
    suspend fun benchmark(): BenchmarkResult {
        val spec = models.selectedSpec()
        unload()
        val backendName = if (settings.current.useGpu) "GPU" else "CPU"
        val t0 = SystemClock.elapsedRealtime()
        val eng = ensureEngine()
        val loadMs = SystemClock.elapsedRealtime() - t0

        var firstMs = -1L
        val acc = StringBuilder()
        val start = SystemClock.elapsedRealtime()
        withContext(Dispatchers.Default) {
            eng.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of("You are a concise assistant."),
                    samplerConfig = SamplerConfig(topK = 20, topP = 0.9, temperature = 0.7)
                )
            ).use { conv ->
                val prompt = "Explain in two short sentences what a battery does." +
                    if (spec.noThinkSwitch) " /no_think" else ""
                conv.sendMessageAsync(Contents.of(prompt)).collect { chunk ->
                    if (firstMs < 0) firstMs = SystemClock.elapsedRealtime() - start
                    acc.append(chunk.text ?: "")
                }
            }
        }
        val total = SystemClock.elapsedRealtime() - start
        val text = ThinkAware.visibleLength(acc.toString())
        val genMs = (total - maxOf(firstMs, 0L)).coerceAtLeast(1L)
        val mem = Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }
        return BenchmarkResult(
            modelName = spec.name,
            backend = backendName,
            loadMs = loadMs,
            firstTokenMs = maxOf(firstMs, 0L),
            totalMs = total,
            outputChars = text,
            charsPerSecond = text * 1000.0 / genMs,
            appPssMb = mem.totalPss / 1024
        )
    }
}

private object ThinkAware {
    fun visibleLength(raw: String): Int = com.jarvis.assistant.util.ThinkFilter.strip(raw).length
}
