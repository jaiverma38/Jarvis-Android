package com.jarvis.assistant.automation

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

/**
 * Shared flag between the action router and [WhatsAppAutomationService]. When the user asked JARVIS to send a
 * WhatsApp message or place a call, the router "arms" a task; the accessibility service then presses WhatsApp's
 * own Send (or Call) button once, within a short time window, and disarms. Nothing is read or stored.
 */
object WaAutomation {
    enum class Task { SEND, CALL, PLAY }

    private const val WINDOW_MS = 20_000L

    @Volatile
    var task: Task? = null
        private set

    @Volatile
    private var deadline = 0L

    @Volatile
    var video = false
        private set

    /** For [Task.PLAY]: the song words to look for in the results, the music app's package, and when we armed. */
    @Volatile
    var playTokens: List<String> = emptyList()
        private set

    @Volatile
    var playPkg: String? = null
        private set

    @Volatile
    var armedAt = 0L
        private set

    /** True when the app has no search link: JARVIS must open the app's own search box, type, then tap a result. */
    @Volatile
    var driveSearch = false
        private set

    @Volatile
    var typed = false

    @Volatile
    var queryText = ""
        private set

    /** Restarts the "wait for results" clock after the song has been typed into the app's search box. */
    fun restartClock() {
        armedAt = System.currentTimeMillis()
    }

    fun armPlay(song: String, pkg: String?, drive: Boolean = false) {
        queryText = song
        driveSearch = drive
        typed = false
        playTokens = song.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 }.take(3)
        playPkg = pkg
        arm(Task.PLAY)
    }

    fun arm(t: Task, wantVideo: Boolean = false) {
        task = t
        video = wantVideo
        armedAt = System.currentTimeMillis()
        deadline = armedAt + if (t == Task.PLAY) 30_000L else WINDOW_MS
        WhatsAppAutomationService.instance?.startPolling()
    }

    fun disarm() {
        task = null
    }

    fun active(): Task? {
        val t = task ?: return null
        if (System.currentTimeMillis() > deadline) {
            task = null
            return null
        }
        return t
    }

    /** True when the user has switched JARVIS on in Android's Accessibility settings. */
    fun serviceEnabled(ctx: Context): Boolean {
        val want = ComponentName(ctx, WhatsAppAutomationService::class.java).flattenToString()
        val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return list.split(':').any { it.equals(want, ignoreCase = true) }
    }
}
