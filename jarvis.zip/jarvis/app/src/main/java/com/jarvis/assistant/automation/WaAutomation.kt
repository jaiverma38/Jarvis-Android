package com.jarvis.assistant.automation

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

/**
 * Shared flag between the action router and [WhatsAppAutomationService]. When the user asked JARVIS to send a
 * WhatsApp message or place a call, the router "arms" a task; the accessibility service then presses WhatsApp's
 * own Send (or Call) button once, within a short time window, and disarms. Nothing is read or stored.
 */
object WaAutomation {
    enum class Task { SEND, CALL, PLAY, SOCIAL }

    private const val WINDOW_MS = 20_000L

    @Volatile
    var task: Task? = null
        private set

    @Volatile
    private var deadline = 0L

    @Volatile
    var video = false
        private set

    /** For [Task.PLAY]: the song words to look for in the results, the music app's package, and when we armed. */
    @Volatile
    var playTokens: List<String> = emptyList()
        private set

    @Volatile
    var playPkg: String? = null
        private set

    @Volatile
    var armedAt = 0L
        private set

    /** True when the app has no search link: JARVIS must open the app's own search box, type, then tap a result. */
    @Volatile
    var driveSearch = false
        private set

    @Volatile
    var typed = false

    @Volatile
    var queryText = ""
        private set

    /** Restarts the "wait for results" clock after the song has been typed into the app's search box. */
    fun restartClock() {
        armedAt = System.currentTimeMillis()
    }

    fun armPlay(song: String, pkg: String?, drive: Boolean = false) {
        queryText = song
        driveSearch = drive
        typed = false
        playTokens = song.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 }.take(3)
        playPkg = pkg
        arm(Task.PLAY)
    }

    // ---- YouTube / Instagram: search, play the first result, write a comment ----

    @Volatile var socialApp: com.jarvis.assistant.actions.SocialApp? = null
        private set
    @Volatile var socialOp: com.jarvis.assistant.actions.SocialOp? = null
        private set
    @Volatile var socialQuery = ""
        private set
    @Volatile var commentText = ""
        private set
    @Volatile var socialTokens: List<String> = emptyList()
        private set

    /** 0 = type the query (Instagram), 1 = open the first result, 2 = open a reel (Instagram), 10 = open comments, 11 = type, 12 = send. */
    @Volatile var stage = 0
    @Volatile var stageAt = 0L
    @Volatile var stageTries = 0

    fun armSocial(app: com.jarvis.assistant.actions.SocialApp, op: com.jarvis.assistant.actions.SocialOp, query: String, text: String) {
        socialApp = app
        socialOp = op
        socialQuery = query
        commentText = text
        socialTokens = query.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 }.take(3)
        stage = when {
            query.isEmpty() -> if (op == com.jarvis.assistant.actions.SocialOp.COMMENT) 10 else 99
            app == com.jarvis.assistant.actions.SocialApp.INSTAGRAM -> 0
            else -> 1
        }
        stageAt = System.currentTimeMillis()
        stageTries = 0
        arm(Task.SOCIAL)
    }

    /** What the helper saw the last time it worked on YouTube/Instagram. Kept in memory only; shown in Settings. */
    @Volatile var report = "No automation has run yet."

    fun nextStage(n: Int) {
        stage = n
        stageAt = System.currentTimeMillis()
        stageTries = 0
    }

    fun arm(t: Task, wantVideo: Boolean = false) {
        task = t
        video = wantVideo
        armedAt = System.currentTimeMillis()
        deadline = armedAt + when {
            t == Task.PLAY -> 30_000L
            t == Task.SOCIAL -> if (socialOp == com.jarvis.assistant.actions.SocialOp.COMMENT) 75_000L else 45_000L
            else -> WINDOW_MS
        }
        WhatsAppAutomationService.instance?.startPolling()
    }

    fun disarm() {
        task = null
    }

    fun active(): Task? {
        val t = task ?: return null
        if (System.currentTimeMillis() > deadline) {
            task = null
            return null
        }
        return t
    }

    /** True when the user has switched JARVIS on in Android's Accessibility settings. */
    fun serviceEnabled(ctx: Context): Boolean {
        val want = ComponentName(ctx, WhatsAppAutomationService::class.java).flattenToString()
        val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return list.split(':').any { it.equals(want, ignoreCase = true) }
    }
}
