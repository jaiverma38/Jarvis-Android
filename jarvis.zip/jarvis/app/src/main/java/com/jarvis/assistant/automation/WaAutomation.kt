package com.jarvis.assistant.automation

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

/**
 * Shared flag between the action router and [WhatsAppAutomationService]. When the user asked JARVIS to send a
 * WhatsApp message or place a call, the router "arms" a task; the accessibility service then presses WhatsApp's
 * own Send (or Call) button once, within a short time window, and disarms. Nothing is read or stored.
 */
object WaAutomation {
    enum class Task { SEND, CALL }

    private const val WINDOW_MS = 20_000L

    @Volatile
    var task: Task? = null
        private set

    @Volatile
    private var deadline = 0L

    fun arm(t: Task) {
        task = t
        deadline = System.currentTimeMillis() + WINDOW_MS
        WhatsAppAutomationService.instance?.startPolling()
    }

    fun disarm() {
        task = null
    }

    fun active(): Task? {
        val t = task ?: return null
        if (System.currentTimeMillis() > deadline) {
            task = null
            return null
        }
        return t
    }

    /** True when the user has switched JARVIS on in Android's Accessibility settings. */
    fun serviceEnabled(ctx: Context): Boolean {
        val want = ComponentName(ctx, WhatsAppAutomationService::class.java).flattenToString()
        val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return list.split(':').any { it.equals(want, ignoreCase = true) }
    }
}
