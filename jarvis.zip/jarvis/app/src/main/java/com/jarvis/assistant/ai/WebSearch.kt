package com.jarvis.assistant.ai

import com.jarvis.assistant.util.SpeechText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.URLEncoder

data class WebSnippet(val title: String, val text: String, val source: String)

data class WebContext(val snippets: List<WebSnippet>) {
    /** The user's question with the search results in front of it, for the on-device model. */
    fun promptFor(question: String): String {
        val sb = StringBuilder()
        sb.append("Web search results are below. Answer the question using them, briefly, in the language of the ")
        sb.append("question. If the results do not contain the answer, say you could not find it.\n\n")
        var used = 0
        snippets.forEachIndexed { i, s ->
            val line = "[${i + 1}] ${s.title} (${s.source}): ${s.text}\n"
            if (used + line.length <= MAX_CHARS) {
                sb.append(line)
                used += line.length
            }
        }
        sb.append("\nQuestion: ").append(question)
        return sb.toString()
    }

    fun sourceLine(): String = snippets.map { it.source + ": " + it.title }.distinct().take(3).joinToString("; ")

    private companion object {
        const val MAX_CHARS = 2200
    }
}

/**
 * Keyless web lookup: Wikipedia (English or Hindi) and DuckDuckGo's Instant Answer API. No account, no API key.
 * Only the question text is sent. This gives encyclopedic facts, NOT live news, prices or weather.
 */
object WebSearch {
    private val ic = RegexOption.IGNORE_CASE

    private val questionStart = Regex(
        "^(what|who|whom|whose|when|where|why|how|which|tell me|explain|define|describe|" +
            "kya|kaun|kab|kahan|kahaan|kyun|kyon|kaise|kitna|kitne|kitni|kaunsa|kaunsi|batao|bataiye|samjhao)\\b|" +
            "^(क्या|कौन|कब|कहाँ|कहां|क्यों|कैसे|कितना|कितने|कितनी|बताओ|बताइए|समझाओ)", ic
    )

    private val leadingFiller = Regex(
        "^(what is|what are|what was|what were|who is|who was|who are|tell me about|tell me|explain|define|describe|" +
            "kya hai|kaun hai|kaun tha|batao|bataiye|samjhao|क्या है|कौन है|कौन था|बताओ|बताइए)\\s+", ic
    )
    private val trailingFiller = Regex(
        "\\s+(kya hai|kaun hai|kaun tha|kya hota hai|kya hoti hai|के बारे में बताओ|के बारे में बताइए|क्या है|कौन है|" +
            "ke baare mein batao|ke bare me batao|batao|bataiye)$", ic
    )

    /** True for factual-looking questions. Phone commands and small talk are handled before this. */
    fun wantsSearch(text: String): Boolean {
        val t = text.trim()
        if (t.length < 6 || t.length > 200) return false
        return t.endsWith("?") || t.endsWith("？") || questionStart.containsMatchIn(t)
    }

    private fun clean(raw: String): String {
        var q = raw.trim().trimEnd('?', '.', '!', '।').trim()
        q = leadingFiller.replace(q, "")
        q = trailingFiller.replace(q, "")
        return q.trim()
    }

    suspend fun search(question: String): WebContext? {
        val q = clean(question)
        if (q.isBlank()) return null
        val host = if (SpeechText.looksDevanagari(question)) "hi.wikipedia.org" else "en.wikipedia.org"
        return withTimeoutOrNull(9_000) {
            coroutineScope {
                val wiki = async(Dispatchers.IO) { runCatching { wikipedia(host, q) }.getOrDefault(emptyList()) }
                val duck = async(Dispatchers.IO) { runCatching { duckDuckGo(q) }.getOrNull() }
                val list = buildList {
                    duck.await()?.let { add(it) }
                    addAll(wiki.await())
                }
                if (list.isEmpty()) null else WebContext(list.take(4))
            }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun wikipedia(host: String, q: String): List<WebSnippet> {
        val url = "https://$host/w/api.php?action=query&format=json&generator=search&gsrsearch=${enc(q)}" +
            "&gsrlimit=3&prop=extracts&exintro=1&explaintext=1&exsentences=4&exlimit=3&redirects=1"
        val pages = JSONObject(Http.getText(url)).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val found = ArrayList<Triple<Int, String, String>>()
        val keys = pages.keys()
        while (keys.hasNext()) {
            val p = pages.optJSONObject(keys.next()) ?: continue
            val extract = p.optString("extract").trim()
            if (extract.isNotEmpty()) found += Triple(p.optInt("index", 99), p.optString("title"), extract)
        }
        return found.sortedBy { it.first }.map { (_, title, text) ->
            WebSnippet(title, text.take(600), "Wikipedia")
        }
    }

    private fun duckDuckGo(q: String): WebSnippet? {
        val url = "https://api.duckduckgo.com/?q=${enc(q)}&format=json&no_html=1&skip_disambig=1&t=jarvis"
        val o = JSONObject(Http.getText(url))
        val answer = o.optString("Answer").trim()
        val abstract = o.optString("AbstractText").trim()
        val text = answer.ifEmpty { abstract }
        if (text.isEmpty()) return null
        val src = o.optString("AbstractSource").ifBlank { "DuckDuckGo" }
        return WebSnippet(o.optString("Heading").ifBlank { q }, text.take(600), "DuckDuckGo/$src")
    }
}
