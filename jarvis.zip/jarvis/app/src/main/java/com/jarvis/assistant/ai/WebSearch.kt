package com.jarvis.assistant.ai

import com.jarvis.assistant.util.SpeechText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.URLEncoder

data class WebSnippet(val title: String, val text: String, val source: String)

data class WebContext(val snippets: List<WebSnippet>) {
    /** The user's question with the search results in front of it, for the on-device model. */
    fun promptFor(question: String): String {
        val sb = StringBuilder()
        sb.append("You have just searched the internet for this question and the results are below. ")
        sb.append("Answer the question using the relevant results, briefly, in the language of the question. ")
        sb.append("Ignore results that are not relevant. If they do not contain the answer, say you could not ")
        sb.append("find it. Never say you cannot access the internet.\n\n")
        var used = 0
        snippets.forEachIndexed { i, s ->
            val line = "[${i + 1}] ${s.title} (${s.source}): ${s.text}\n"
            if (used + line.length <= MAX_CHARS) {
                sb.append(line)
                used += line.length
            }
        }
        sb.append("\nQuestion: ").append(question)
        return sb.toString()
    }

    fun sourceLine(): String =
        snippets.map { if (it.source == "Wikipedia") "Wikipedia: ${it.title}" else it.source }
            .distinct().take(4).joinToString("; ")

    companion object {
        private const val MAX_CHARS = 2400

        /** Used when a search was attempted but nothing came back, so the model never claims it has no internet. */
        fun failedPrompt(question: String, online: Boolean): String =
            (if (online) "The app searched the internet for this question but found nothing useful. "
            else "The phone has no internet connection right now, so no web search was possible. ") +
                "Answer from your own knowledge if you are sure, otherwise say briefly that you could not find it " +
                "right now. Do not say you are unable to use the internet in general.\n\nQuestion: $question"
    }
}

/**
 * Keyless web lookup: Google News RSS (current events), DuckDuckGo (Instant Answer + HTML results) and
 * Wikipedia (English or Hindi). No account and no API key. Only the question text is sent.
 */
object WebSearch {
    private val ic = RegexOption.IGNORE_CASE

    private val questionStart = Regex(
        "^(what|who|whom|whose|when|where|why|how|which|tell me|explain|define|describe|" +
            "kya|kaun|kab|kahan|kahaan|kyun|kyon|kaise|kitna|kitne|kitni|kaunsa|kaunsi|batao|bataiye|samjhao)\\b|" +
            "^(क्या|कौन|कब|कहाँ|कहां|क्यों|कैसे|कितना|कितने|कितनी|बताओ|बताइए|समझाओ)", ic
    )

    /** The user plainly asks to look something up. */
    private val explicit = Regex(
        "\\b(search|google|look up|lookup|find out|internet|online|web|browse|dhundo|dhoondo|khojo|khoj|" +
            "dhundh|pata karo|pata lagao)\\b|सर्च|गूगल|इंटरनेट|ढूंढो|ढूँढो|खोजो|पता करो|पता लगाओ", ic
    )

    /** Current-events style questions: a news feed is more useful than an encyclopedia. */
    private val newsy = Regex(
        "\\b(news|latest|today|todays|tonight|yesterday|current|currently|breaking|score|live|result|results|" +
            "price|rate|election|aaj|abhi|taaza|taza|khabar|khabrein|samachar|kal)\\b|" +
            "न्यूज़|न्यूज|ताज़ा|ताजा|आज|अभी|खबर|ख़बर|समाचार|स्कोर|रिज़ल्ट|रिजल्ट", ic
    )

    private val leadingFiller = Regex(
        "^((please |pls )?(search|google|look up|lookup|find|dhundo|dhoondo|khojo|pata karo|pata lagao)" +
            "( for| on google| on internet| on the internet| on the web| online| internet par| internet pe| " +
            "google par| google pe| net par| net pe)?\\s+(me |mere liye |for me )?|" +
            "what is|what are|what was|what were|who is|who was|who are|tell me about|tell me|explain|define|" +
            "describe|kya hai|kaun hai|kaun tha|batao|bataiye|samjhao|क्या है|कौन है|कौन था|बताओ|बताइए)\\s*", ic
    )
    private val trailingFiller = Regex(
        "\\s+(search karo|search kar do|google karo|dhundo|khojo|kya hai|kaun hai|kaun tha|kya hota hai|kya hoti hai|" +
            "ke baare mein batao|ke bare me batao|ke baare me batao|batao|bataiye|सर्च करो|ढूंढो|के बारे में बताओ|" +
            "के बारे में बताइए|क्या है|कौन है)$", ic
    )

    /** Factual-looking questions, or an explicit "search ..." request. Commands and small talk never get here. */
    fun wantsSearch(text: String): Boolean {
        val t = text.trim()
        if (t.length < 6 || t.length > 200) return false
        return t.endsWith("?") || t.endsWith("？") || questionStart.containsMatchIn(t) ||
            explicit.containsMatchIn(t) || newsy.containsMatchIn(t)
    }

    fun clean(raw: String): String {
        var q = raw.trim().trimEnd('?', '.', '!', '।').trim()
        q = leadingFiller.replace(q, "")
        q = trailingFiller.replace(q, "")
        return q.trim().ifBlank { raw.trim() }
    }

    suspend fun search(question: String): WebContext? {
        val q = clean(question)
        if (q.isBlank()) return null
        val hindi = SpeechText.looksDevanagari(question)
        val wikiHost = if (hindi) "hi.wikipedia.org" else "en.wikipedia.org"
        val wantsNews = newsy.containsMatchIn(question)
        return withTimeoutOrNull(10_000) {
            coroutineScope {
                val news = async(Dispatchers.IO) {
                    if (wantsNews) runCatching { googleNews(q, hindi) }.getOrDefault(emptyList()) else emptyList()
                }
                val instant = async(Dispatchers.IO) { runCatching { duckInstant(q) }.getOrNull() }
                val html = async(Dispatchers.IO) { runCatching { duckHtml(q) }.getOrDefault(emptyList()) }
                val wiki = async(Dispatchers.IO) { runCatching { wikipedia(wikiHost, q) }.getOrDefault(emptyList()) }
                val list = buildList {
                    addAll(news.await())
                    instant.await()?.let { add(it) }
                    addAll(html.await())
                    addAll(wiki.await())
                }
                if (list.isEmpty()) null else WebContext(list.take(6))
            }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun wikipedia(host: String, q: String): List<WebSnippet> {
        val url = "https://$host/w/api.php?action=query&format=json&generator=search&gsrsearch=${enc(q)}" +
            "&gsrlimit=2&prop=extracts&exintro=1&explaintext=1&exsentences=4&exlimit=2&redirects=1"
        val pages = JSONObject(Http.getText(url)).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val found = ArrayList<Triple<Int, String, String>>()
        val keys = pages.keys()
        while (keys.hasNext()) {
            val p = pages.optJSONObject(keys.next()) ?: continue
            val extract = p.optString("extract").trim()
            if (extract.isNotEmpty()) found += Triple(p.optInt("index", 99), p.optString("title"), extract)
        }
        return found.sortedBy { it.first }.map { (_, title, text) -> WebSnippet(title, text.take(500), "Wikipedia") }
    }

    private fun duckInstant(q: String): WebSnippet? {
        val url = "https://api.duckduckgo.com/?q=${enc(q)}&format=json&no_html=1&skip_disambig=1&t=jarvis"
        val o = JSONObject(Http.getText(url))
        val answer = o.optString("Answer").trim()
        val abstract = o.optString("AbstractText").trim()
        val text = answer.ifEmpty { abstract }
        if (text.isEmpty()) return null
        val src = o.optString("AbstractSource").ifBlank { "DuckDuckGo" }
        return WebSnippet(o.optString("Heading").ifBlank { q }, text.take(500), "DuckDuckGo/$src")
    }

    private val resultTitle = Regex("<a[^>]*class=\"result__a\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)
    private val resultSnippet = Regex("<a[^>]*class=\"result__snippet\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)

    /** DuckDuckGo's plain HTML results page. Best effort: if the page layout changes, this returns nothing. */
    private fun duckHtml(q: String): List<WebSnippet> {
        val html = Http.getText("https://html.duckduckgo.com/html/?q=${enc(q)}", 7_000, "text/html")
        val titles = resultTitle.findAll(html).map { plain(it.groupValues[1]) }.toList()
        val snippets = resultSnippet.findAll(html).map { plain(it.groupValues[1]) }.toList()
        return snippets.indices.take(4).mapNotNull { i ->
            val text = snippets[i]
            if (text.isBlank()) null else WebSnippet(titles.getOrElse(i) { q }, text.take(400), "DuckDuckGo")
        }
    }

    private val rssItem = Regex("<item>(.*?)</item>", RegexOption.DOT_MATCHES_ALL)
    private val rssTitle = Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL)
    private val rssDate = Regex("<pubDate>(.*?)</pubDate>", RegexOption.DOT_MATCHES_ALL)

    /** Google News public RSS feed: recent headlines for the query, with their publish dates. */
    private fun googleNews(q: String, hindi: Boolean): List<WebSnippet> {
        val loc = if (hindi) "hl=hi&gl=IN&ceid=IN:hi" else "hl=en-IN&gl=IN&ceid=IN:en"
        val xml = Http.getText("https://news.google.com/rss/search?q=${enc(q)}&$loc", 7_000, "*/*")
        return rssItem.findAll(xml).take(5).mapNotNull { m ->
            val item = m.groupValues[1]
            val title = rssTitle.find(item)?.groupValues?.get(1)?.let { plain(it) } ?: return@mapNotNull null
            val date = rssDate.find(item)?.groupValues?.get(1)?.trim()?.take(22).orEmpty()
            WebSnippet("Headline", if (date.isEmpty()) title else "$title ($date)", "Google News")
        }.toList()
    }

    /** Strips tags and common HTML entities. */
    private fun plain(s: String): String =
        s.replace(Regex("<!\\[CDATA\\[|\\]\\]>"), "")
            .replace(Regex("<[^>]+>"), "")
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&#x27;", "'")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ").trim()
}
