package com.jarvis.assistant.util

import java.util.Locale

/** Understands a spoken or typed yes / no in English, Hinglish and Hindi. Returns null for anything else. */
object YesNo {
    private val ic = RegexOption.IGNORE_CASE
    private val tail = "(?:\\s+(?:jarvis|sir|boss|jai|please|ji))*"
    private val yes = Regex(
        "^(?:yes|yeah|yep|yup|sure|ok|okay|confirm|confirmed|go ahead|do it|proceed|affirmative|haan|han|haa|ha|" +
            "haanji|han ji|hanji|haan ji|kar do|kardo|karo|bhej do|bhejo|laga do|lagao|theek hai|thik hai|bilkul|" +
            "जी हाँ|जी हां|हाँ|हां|हा|ठीक है|कर दो|करो|भेज दो|भेजो|लगा दो|बिल्कुल)$tail$", ic
    )
    private val no = Regex(
        "^(?:no|nope|nah|cancel|stop|don'?t|do not|never mind|nevermind|negative|nahi|nahin|nai|na|mat karo|" +
            "mat bhejo|rehne do|rahne do|ruko|ruk jao|band karo|नहीं|नही|ना|मत करो|मत भेजो|रहने दो|रुको|कैंसिल)$tail$", ic
    )

    fun parse(raw: String): Boolean? {
        val t = raw.trim().lowercase(Locale.ROOT).replace(Regex("[!?.,।'\"]"), "").replace(Regex("\\s+"), " ")
        if (t.isEmpty() || t.length > 30) return null
        return when {
            yes.matches(t) -> true
            no.matches(t) -> false
            else -> null
        }
    }
}
