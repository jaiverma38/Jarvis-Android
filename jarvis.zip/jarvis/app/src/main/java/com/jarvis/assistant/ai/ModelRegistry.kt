package com.jarvis.assistant.ai

/**
 * File names, sizes, licenses and context lengths below come from the Hugging Face model card of
 * litert-community/Qwen3-0.6B (checked November 2026). Real download size and the SHA-256 are read from
 * the server at download time. Speed on the Helio G95 is NOT assumed: use the benchmark in the Models screen.
 */
data class ModelSpec(
    val id: String,
    val name: String,
    val url: String,
    val fileName: String,
    val approxBytes: Long,
    val license: String,
    val contextTokens: Int,
    /** Qwen3 understands the "/no_think" switch that disables long reasoning output. */
    val noThinkSwitch: Boolean,
    val note: String,
    val custom: Boolean = false
)

object ModelRegistry {
    private const val BASE = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/"

    private const val GEMMA4 = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/"

    val builtIn: List<ModelSpec> = listOf(
        ModelSpec(
            id = "gemma4-e2b",
            name = "Gemma 4 E2B (smarter, large)",
            url = GEMMA4 + "gemma-4-E2B-it.litertlm?download=true",
            fileName = "gemma-4-E2B-it.litertlm",
            approxBytes = 2_590_000_000L,
            license = "Apache-2.0",
            contextTokens = 4096,
            noThinkSwitch = false,
            note = "About 2.6 GB download and 2 to 3 GB of RAM while loaded. Knows much more than Qwen 0.6B " +
                "and handles Hindi and English far better. Google's speed numbers are for a flagship phone; " +
                "on a Helio G95 expect it to be much slower, so run the benchmark before relying on it."
        ),
        ModelSpec(
            id = "qwen3-0.6b-int4",
            name = "Qwen3 0.6B (INT4, smallest)",
            url = BASE + "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm?download=true",
            fileName = "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm",
            approxBytes = 344_000_000L,
            license = "Apache-2.0",
            contextTokens = 4096,
            noThinkSwitch = true,
            note = "About 330 MB. Listed as the recommended build on the model card. " +
                "Quality of a 0.6B model is limited, especially in Hindi."
        ),
        ModelSpec(
            id = "qwen3-0.6b-int8",
            name = "Qwen3 0.6B (INT8)",
            url = BASE + "Qwen3-0.6B.litertlm?download=true",
            fileName = "Qwen3-0.6B.litertlm",
            approxBytes = 586_000_000L,
            license = "Apache-2.0",
            contextTokens = 4096,
            noThinkSwitch = true,
            note = "About 590 MB. Slightly higher precision than INT4, uses more memory."
        )
    )

    /** The small Qwen stays the default: it is the one that downloads fast and runs on any phone. */
    val default: ModelSpec = builtIn.first { it.id == "qwen3-0.6b-int4" }

    fun findBuiltIn(id: String): ModelSpec? = builtIn.firstOrNull { it.id == id }
}
