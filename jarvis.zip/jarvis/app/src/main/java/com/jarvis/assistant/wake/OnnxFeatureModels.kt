package com.jarvis.assistant.wake

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import java.io.FileNotFoundException
import java.nio.FloatBuffer

/**
 * The three small ONNX models of openWakeWord (melspectrogram, speech embedding, "hey jarvis" classifier),
 * run on the CPU with one thread to keep battery use low. The model files are put into the APK's
 * assets/wake folder by the GitHub Actions workflow (see NOTICE.md for their license).
 */
class OnnxFeatureModels private constructor(
    private val env: OrtEnvironment,
    private val melSession: OrtSession,
    private val embSession: OrtSession,
    private val clsSession: OrtSession
) : AutoCloseable {

    private val melIn = melSession.inputNames.first()
    private val embIn = embSession.inputNames.first()
    private val clsIn = clsSession.inputNames.first()

    /** Raw int16-valued samples -> flat [frames x 32], scaled like openWakeWord (x / 10 + 2). */
    fun mel(samples: FloatArray): FloatArray {
        OnnxTensor.createTensor(env, FloatBuffer.wrap(samples), longArrayOf(1, samples.size.toLong())).use { input ->
            melSession.run(mapOf(melIn to input)).use { result ->
                val out = floats(result.get(0) as OnnxTensor)
                for (i in out.indices) out[i] = out[i] / 10f + 2f
                return out
            }
        }
    }

    /** Flat [76 x 32] -> 96 numbers. */
    fun embed(window: FloatArray): FloatArray {
        val shape = longArrayOf(1, WakeWordPipeline.MEL_WINDOW.toLong(), WakeWordPipeline.MEL_BINS.toLong(), 1)
        OnnxTensor.createTensor(env, FloatBuffer.wrap(window), shape).use { input ->
            embSession.run(mapOf(embIn to input)).use { result ->
                return floats(result.get(0) as OnnxTensor)
            }
        }
    }

    /** Flat [16 x 96] -> probability that "hey jarvis" was just said. */
    fun classify(features: FloatArray): Float {
        val shape = longArrayOf(1, WakeWordPipeline.EMB_FRAMES.toLong(), WakeWordPipeline.EMB_SIZE.toLong())
        OnnxTensor.createTensor(env, FloatBuffer.wrap(features), shape).use { input ->
            clsSession.run(mapOf(clsIn to input)).use { result ->
                val out = floats(result.get(0) as OnnxTensor)
                return if (out.isEmpty()) 0f else out[0]
            }
        }
    }

    private fun floats(t: OnnxTensor): FloatArray {
        val buf = t.floatBuffer
        val arr = FloatArray(buf.remaining())
        buf.get(arr)
        return arr
    }

    override fun close() {
        runCatching { melSession.close() }
        runCatching { embSession.close() }
        runCatching { clsSession.close() }
    }

    companion object {
        const val MEL_ASSET = "wake/melspectrogram.onnx"
        const val EMB_ASSET = "wake/embedding_model.onnx"
        const val CLS_ASSET = "wake/hey_jarvis_v0.1.onnx"

        fun load(ctx: Context): OnnxFeatureModels {
            val env = OrtEnvironment.getEnvironment()
            fun session(asset: String): OrtSession {
                val bytes = try {
                    ctx.assets.open(asset).use { it.readBytes() }
                } catch (e: FileNotFoundException) {
                    throw IllegalStateException(
                        "Wake word model files are missing from this APK ($asset). " +
                            "Build with the GitHub workflow in this project: it downloads them first."
                    )
                }
                val opts = OrtSession.SessionOptions().apply {
                    setIntraOpNumThreads(1)
                    setInterOpNumThreads(1)
                }
                return env.createSession(bytes, opts)
            }
            val mel = session(MEL_ASSET)
            val emb = try {
                session(EMB_ASSET)
            } catch (e: Throwable) {
                mel.close(); throw e
            }
            val cls = try {
                session(CLS_ASSET)
            } catch (e: Throwable) {
                mel.close(); emb.close(); throw e
            }
            return OnnxFeatureModels(env, mel, emb, cls)
        }
    }
}
