package com.jarvis.assistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object J {
    val Bg = Color(0xFF020814)
    val Panel = Color(0xFF07182E)
    val PanelHi = Color(0xFF0B2745)
    val Cyan = Color(0xFF29D9FF)
    val Blue = Color(0xFF2F7BFF)
    val Text = Color(0xFFE6F6FF)
    val Dim = Color(0xFF8FB4CC)
    val Warn = Color(0xFFFFC24D)
    val Bad = Color(0xFFFF6B6B)
    val Good = Color(0xFF5CF2B0)
}

private val scheme = darkColorScheme(
    primary = J.Cyan,
    onPrimary = Color(0xFF00212B),
    secondary = J.Blue,
    background = J.Bg,
    onBackground = J.Text,
    surface = J.Panel,
    onSurface = J.Text,
    surfaceVariant = J.PanelHi,
    onSurfaceVariant = J.Dim,
    error = J.Bad,
    outline = Color(0xFF1C4A73)
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}

/** A blue "holographic" panel: dark glass with a thin cyan edge. Text stays high contrast. */
@Composable
fun HoloCard(modifier: Modifier = Modifier, title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(J.PanelHi, J.Panel)), shape)
            .border(1.dp, J.Cyan.copy(alpha = 0.35f), shape)
            .padding(14.dp)
    ) {
        if (title != null) {
            Text(title, color = J.Cyan, style = MaterialTheme.typography.titleSmall)
            Box(Modifier.padding(top = 8.dp))
        }
        content()
    }
}

@Composable
fun GridBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val step = 48.dp.toPx()
        val c = J.Cyan.copy(alpha = 0.05f)
        var x = 0f
        while (x < size.width) {
            drawLine(c, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(c, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            y += step
        }
        drawCircle(
            brush = Brush.radialGradient(listOf(J.Blue.copy(alpha = 0.18f), Color.Transparent)),
            radius = size.width * 0.8f,
            center = Offset(size.width / 2, 0f)
        )
    }
}
