package com.jarvis.assistant.util

/**
 * Answers "what did I tell you?" questions from the saved memory facts with fixed rules, so the answer
 * does not depend on a small model noticing the fact. Everything stays on the phone.
 */
object Recall {
    private val stop = setOf(
        // English
        "the", "a", "an", "is", "are", "was", "of", "my", "me", "i", "you", "your", "what", "who", "when", "where",
        "which", "how", "do", "does", "did", "to", "in", "on", "at", "and", "or", "tell", "about", "know", "name",
        // Hinglish / Hindi
        "mera", "meri", "mere", "mujhe", "main", "mai", "tum", "tumhe", "aap", "aapko", "kya", "kaun", "kab", "kaha",
        "kahan", "kitna", "kitni", "kaise", "hai", "hain", "ho", "tha", "thi", "the", "ka", "ki", "ke", "ko", "se",
        "me", "mein", "par", "pe", "ne", "bata", "batao", "bataiye", "bolo", "yaad", "hai", "na", "to", "ye", "yeh",
        "wo", "woh", "jarvis", "please", "zara", "mera", "kon", "koun",
        "मेरा", "मेरी", "मेरे", "क्या", "कौन", "कब", "कहाँ", "है", "हैं", "था", "थी", "का", "की", "के", "को", "से", "में", "पर",
        "बताओ", "बताइए", "याद", "मुझे", "तुम", "आप"
    )

    private val questionWords = Regex(
        "\\b(kya|kaun|kon|kab|kaha|kahan|kitna|kitni|kaise|what|who|when|where|which|how|batao|bata do|bataiye|" +
            "yaad hai|remember|tell me)\\b|\\?|क्या|कौन|कब|कहाँ|बताओ|याद",
        RegexOption.IGNORE_CASE
    )

    private val listRequest = Regex(
        "what (do|did) you (remember|know) about me|what have i told you|what (all )?do you remember|" +
            "tumhe? (mere|meri) (baare|bare) (me|mein)|mere (baare|bare) (me|mein) (kya|kitna)|" +
            "kya (kya )?yaad (hai|rakha)|mujhe kya kya yaad|tumhe kya kya yaad|तुम्हें क्या क्या याद|मेरे बारे में क्या",
        RegexOption.IGNORE_CASE
    )

    private fun tokens(t: String): Set<String> =
        t.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 && it !in stop }
            .map { it.removeSuffix("s") }.toSet()

    fun wantsList(q: String) = listRequest.containsMatchIn(q)

    fun isAsking(q: String) = questionWords.containsMatchIn(q)

    /** Facts sharing at least one meaningful word with the question, best first. */
    fun relevant(q: String, facts: List<String>, n: Int = 3): List<String> {
        val qt = tokens(q)
        if (qt.isEmpty()) return emptyList()
        return facts.map { it to (tokens(it) intersect qt).size }.filter { it.second > 0 }
            .sortedByDescending { it.second }.take(n).map { it.first }
    }

    /** The one fact that clearly answers the question, or null when it is not clear enough to answer without a model. */
    fun direct(q: String, facts: List<String>): String? {
        if (!isAsking(q)) return null
        val qt = tokens(q)
        if (qt.isEmpty()) return null
        val best = facts.map { it to (tokens(it) intersect qt).size }.maxByOrNull { it.second } ?: return null
        val strong = best.second >= 2 || (best.second >= 1 && qt.size == 1)
        return if (strong) best.first else null
    }
}
