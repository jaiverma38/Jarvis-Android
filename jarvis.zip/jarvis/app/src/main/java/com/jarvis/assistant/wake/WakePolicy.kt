package com.jarvis.assistant.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.data.WakeWhen
import java.util.Calendar

/**
 * Decides WHEN the "Hey Jarvis" microphone should be open, to save battery: not while the phone is covered
 * (pocket, bag, face down: proximity sensor), optionally not at night, and optionally only while the screen is
 * on or the phone is charging. Calls [onAllowed] with the decision. Uses only screen, charging, clock and
 * proximity information. Nothing is stored.
 */
class WakePolicy(
    private val ctx: Context,
    private val settings: SettingsStore,
    private val onAllowed: (Boolean, String) -> Unit
) : SensorEventListener {
    private val handler = Handler(Looper.getMainLooper())
    private val sensors = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val proximity = sensors?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    private var near = false
    private var sensorOn = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = evaluate()
    }
    private val tick = object : Runnable {
        override fun run() {
            evaluate()
            handler.postDelayed(this, 60_000)
        }
    }

    fun start() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        handler.post(tick)
    }

    fun stop() {
        runCatching { ctx.unregisterReceiver(receiver) }
        handler.removeCallbacksAndMessages(null)
        setSensor(false)
    }

    private fun setSensor(on: Boolean) {
        if (on == sensorOn || proximity == null) return
        sensorOn = on
        if (on) sensors?.registerListener(this, proximity, SensorManager.SENSOR_DELAY_NORMAL)
        else {
            sensors?.unregisterListener(this)
            near = false
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val p = proximity ?: return
        val nowNear = e.values[0] < minOf(5f, p.maximumRange)
        if (nowNear != near) {
            near = nowNear
            evaluate()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    fun evaluate() {
        val s = settings.current
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val screenOn = pm.isInteractive
        val charging = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)?.let { it != 0 } ?: false
        setSensor(s.wakePocket && !screenOn)

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = if (s.wakeNightStart > s.wakeNightEnd) hour >= s.wakeNightStart || hour < s.wakeNightEnd
        else hour in s.wakeNightStart until s.wakeNightEnd

        when {
            screenOn -> onAllowed(true, "")
            s.wakeWhen == WakeWhen.SCREEN_ON_OR_CHARGING && !charging ->
                onAllowed(false, "screen is off and the phone is not charging")
            s.wakePocket && near -> onAllowed(false, "the phone is covered (pocket, bag or face down)")
            s.wakeNight && night -> onAllowed(false, "night pause")
            else -> onAllowed(true, "")
        }
    }
}
