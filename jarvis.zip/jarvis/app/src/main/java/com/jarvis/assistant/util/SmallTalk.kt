package com.jarvis.assistant.util

import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Instant answers for everyday small talk (hello, how are you, thanks, time, date) in English, Hinglish and
 * Hindi. A 0.6B model handles these badly and slowly, so fixed rules answer them. Anything else returns null
 * and goes to the AI model. Pure Kotlin, no network.
 */
object SmallTalk {
    private enum class Lang { EN, HINGLISH, HI }

    private val wakePrefix = Regex("^(hey |ok |okay )?(jarvis|जार्विस|जारविस)\\s*", RegexOption.IGNORE_CASE)
    private val ic = RegexOption.IGNORE_CASE

    private val greeting = Regex(
        "^(hi+|hello+|hey+|hola|yo|namaste|namaskar|नमस्ते|नमस्कार|हैलो|हेलो|हाय|" +
            "good (morning|afternoon|evening)|suprabhat|shubh sandhya|सुप्रभात|शुभ प्रभात|शुभ संध्या)( there| jarvis| sir)?$", ic
    )
    private val goodNight = Regex("^(good night|shubh ratri|शुभ रात्रि|gn)$", ic)
    private val howAreYou = Regex(
        "(how are you|how r u|how do you do|how's it going|hows it going|what's up|whats up|\\bsup\\b|" +
            "kaise ho|kese ho|kaise hain|kaisi ho|kya haal|kya hal|" +
            "कैसे हो|कैसे हैं|क्या हाल|कैसी हो)", ic
    )
    private val thanks = Regex(
        "^(thanks|thank you|thank u|thanks a lot|thx|shukriya|shukria|dhanyavad|dhanyawad|" +
            "धन्यवाद|शुक्रिया|थैंक यू)( jarvis)?$", ic
    )
    private val whoMadeYou = Regex(
        "(who (made|created|built|owns|developed) you|who is your (owner|creator|master|boss|developer|maker)|" +
            "who('s| is) your (owner|creator|master|boss)|your (owner|creator|master)|" +
            "tumhe kisne banaya|tumko kisne banaya|aapko kisne banaya|tumhara malik|tumhara owner|aapka malik|" +
            "aapka owner|tera malik|tumhara creator|tumhara maalik|aapka maalik|" +
            "तुम्हें किसने बनाया|आपको किसने बनाया|तुम्हारा मालिक|आपका मालिक|तेरा मालिक|तुम्हारा ओनर|आपका ओनर)", ic
    )

    private val askTime = Regex(
        "(what(s|'s| is) the time|what time is it|current time|time kya hua|time kya hai|kitne baje|" +
            "abhi kya time|samay kya|टाइम क्या|कितने बजे|समय क्या)", ic
    )
    private val askDate = Regex(
        "(what(s|'s| is) (the )?(date|day)( today)?|today('s|s)? date|what day is it|aaj kya date|aaj ki date|" +
            "aaj kaun sa din|aaj kya din|आज की तारीख|आज कौन सा दिन|आज क्या तारीख|तारीख क्या)", ic
    )

    fun answer(text: String, now: ZonedDateTime = ZonedDateTime.now()): String? {
        Identity.answer(text)?.let { return it }
        val t = normalize(text)
        if (t.isEmpty() || t.length > 45) return null
        val lang = langOf(text)
        val a = Persona.address
        val h = Persona.addressHindi()

        return when {
            thanks.matches(t) -> pick(lang, "My pleasure, $a.", "Aapki seva mein, $a.", "आपकी सेवा में, $h।")
            goodNight.matches(t) -> pick(lang, "Good night, $a. Rest well.", "Shubh ratri, $a. Aaram se soiye.", "शुभ रात्रि, $h। आराम से सोइए।")
            greeting.matches(t) -> greet(lang, now, a, h)
            (t.length <= 30 && howAreYou.containsMatchIn(t)) -> pick(
                lang,
                "All systems are running smoothly, $a. And how are you?",
                "Sab kuch bilkul theek chal raha hai, $a. Aap kaise hain?",
                "सब कुछ बिल्कुल ठीक चल रहा है, $h। आप कैसे हैं?"
            )
            whoMadeYou.containsMatchIn(t) -> pick(
                lang,
                "My owner is Jai Verma.",
                "Mere owner Jai Verma hain.",
                "मेरे मालिक जय वर्मा हैं।"
            )
            askTime.containsMatchIn(t) -> {
                val clock = now.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
                pick(lang, "The time is $clock, $a.", "Abhi $clock hue hain, $a.", "अभी $clock हुए हैं, $h।")
            }
            askDate.containsMatchIn(t) -> {
                val d = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH))
                pick(lang, "Today is $d, $a.", "Aaj $d hai, $a.", "आज $d है, $h।")
            }
            else -> null
        }
    }

    /** Greets by the time of day on the phone's clock, whatever greeting the user said. */
    private fun greet(lang: Lang, now: ZonedDateTime, a: String, h: String): String {
        val kind = when (now.hour) {
            in 5..11 -> 0
            in 12..16 -> 1
            in 17..21 -> 2
            else -> 3
        }
        val en = listOf("Good morning", "Good afternoon", "Good evening", "Hello")[kind]
        val hinglish = listOf("Suprabhat", "Namaste", "Shubh sandhya", "Namaste")[kind]
        val hindi = listOf("सुप्रभात", "नमस्कार", "शुभ संध्या", "नमस्ते")[kind]
        return pick(
            lang,
            "$en, $a. How may I be of service?",
            "$hinglish, $a. Bataiye, main aapki kya seva karoon?",
            "$hindi $h। बताइए, मैं आपकी क्या सेवा करूँ?"
        )
    }

    private fun normalize(raw: String): String {
        val s = raw.trim().lowercase(Locale.ROOT)
            .replace(Regex("[!?.,।'\"]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        return wakePrefix.replace(s, "").trim().let { if (it.isEmpty()) s else it }
    }

    private fun langOf(raw: String): Lang = when {
        SpeechText.looksDevanagari(raw) -> Lang.HI
        Regex("\\b(kaise|kese|kaisa|kaisi|kya|haal|hal|aap|tum|tumhe|aapko|kisne|banaya|baje|aaj|abhi|shukriya|" +
            "dhanyavad|namaste|namaskar|suprabhat|shubh|hai|hain|ho)\\b", ic).containsMatchIn(raw) -> Lang.HINGLISH
        else -> Lang.EN
    }

    private fun pick(lang: Lang, en: String, hinglish: String, hindi: String) = when (lang) {
        Lang.EN -> en
        Lang.HINGLISH -> hinglish
        Lang.HI -> hindi
    }
}
