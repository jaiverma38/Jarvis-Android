package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.jarvis.assistant.ui.ChatScreen
import com.jarvis.assistant.ui.HistoryScreen
import com.jarvis.assistant.ui.J
import com.jarvis.assistant.ui.JarvisTheme
import com.jarvis.assistant.ui.ModelsScreen
import com.jarvis.assistant.ui.PrivacyScreen
import com.jarvis.assistant.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels { MainViewModel.factory(container()) }

    override fun onStart() {
        super.onStart()
        val c = container()
        c.uiVisible = true
        // Android 12 only lets a microphone service start while the app is visible, so restart it here.
        val hasMic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (c.settings.current.wakeEnabled && !c.wake.isWanted && hasMic) c.startWakeService()
    }

    override fun onStop() {
        container().uiVisible = false
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = container()
        setContent {
            JarvisTheme { Root(c) }
        }
    }

    @Composable
    private fun Root(c: AppContainer) {
        val ctx = LocalContext.current
        var tab by rememberSaveable { mutableIntStateOf(0) }

        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Voice works either way. Without this permission the microphone notification is hidden on Android 13+.
        }
        val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                vm.startVoice()
            }
        }

        fun onVoiceTap() {
            val has = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            if (has) vm.toggleVoice() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        // Conversation mode: reopen the microphone only while the app is visible.
        val owner = LocalLifecycleOwner.current
        LaunchedEffect(owner) {
            owner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                vm.listenAgain.collect {
                    val has = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                        PackageManager.PERMISSION_GRANTED
                    if (has && vm.state.value.phase == Phase.IDLE) vm.startVoice()
                }
            }
        }

        val tabs = listOf("Chat" to "◉", "History" to "☰", "Models" to "▣", "Privacy" to "⛨", "Settings" to "⚙")

        Scaffold(
            containerColor = J.Bg,
            bottomBar = {
                NavigationBar(containerColor = J.Panel) {
                    tabs.forEachIndexed { i, (label, glyph) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(glyph) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = J.Cyan,
                                selectedTextColor = J.Cyan,
                                unselectedIconColor = J.Dim,
                                unselectedTextColor = J.Dim,
                                indicatorColor = J.PanelHi
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> ChatScreen(vm, c, ::onVoiceTap)
                    1 -> HistoryScreen(vm, c) { tab = 0 }
                    2 -> ModelsScreen(vm, c)
                    3 -> PrivacyScreen(vm, c)
                    else -> SettingsScreen(vm, c)
                }
            }
        }
    }
}
