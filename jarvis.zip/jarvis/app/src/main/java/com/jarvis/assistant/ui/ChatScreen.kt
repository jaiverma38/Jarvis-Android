package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.MainViewModel
import com.jarvis.assistant.Phase
import com.jarvis.assistant.UiMessage
import com.jarvis.assistant.ai.LoadState
import com.jarvis.assistant.data.AiMode

@Composable
fun ChatScreen(vm: MainViewModel, c: AppContainer, onVoiceTap: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val settings by c.settings.state.collectAsStateWithLifecycle()
    val online by c.network.online.collectAsStateWithLifecycle()
    val load by c.local.loadState.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(state.messages.size, state.messages.lastOrNull()?.text) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }

    Box(Modifier.fillMaxSize()) {
        GridBackdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            StatusRow(settings.aiMode, online, load, c.local.isModelInstalled())

            state.banner?.let { msg ->
                HoloCard(Modifier.padding(vertical = 6.dp)) {
                    Text(msg, color = J.Warn, style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = vm::dismissBanner) { Text("Dismiss") }
                }
            }

            if (state.messages.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("JARVIS", color = J.Cyan, style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "Tap the orb and speak, or type below.\nSay \"help\" to see phone commands.",
                            color = J.Dim,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.messages, key = { it.id }) { Bubble(it) }
                }
            }

            if (state.partial.isNotBlank()) {
                Text(
                    "“${state.partial}”",
                    color = J.Good,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            Column(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Orb(state.phase, 104.dp, onVoiceTap)
                OrbLabel(state.phase)
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.take(2000) },
                    modifier = Modifier.weight(1f).semantics { contentDescription = "Message to JARVIS" },
                    placeholder = { Text("Type a message or command") },
                    maxLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (input.isNotBlank()) {
                            vm.send(input)
                            input = ""
                        }
                    })
                )
                Button(
                    onClick = {
                        if (state.phase == Phase.THINKING) {
                            vm.stopGenerating()
                        } else if (input.isNotBlank()) {
                            vm.send(input)
                            input = ""
                        }
                    }
                ) { Text(if (state.phase == Phase.THINKING) "Stop" else "Send") }
            }
        }
    }

    if (state.pendingAction != null) {
        AlertDialog(
            onDismissRequest = vm::cancelPending,
            title = { Text("Confirm action") },
            text = { Text(state.pendingDescription) },
            confirmButton = { Button(onClick = vm::confirmPending) { Text("Confirm") } },
            dismissButton = { TextButton(onClick = vm::cancelPending) { Text("Cancel") } }
        )
    }
}

@Composable
private fun StatusRow(mode: AiMode, online: Boolean, load: LoadState, installed: Boolean) {
    val modeText = when (mode) {
        AiMode.OFFLINE -> "Mode: Offline only"
        AiMode.ONLINE -> "Mode: Online only"
        AiMode.AUTO -> "Mode: Auto"
    }
    val net = if (online) "Internet: connected" else "Internet: none"
    val model = when (load) {
        LoadState.Unloaded -> if (installed) "Model: installed, not loaded" else "Model: not downloaded"
        is LoadState.Loading -> "Model: loading…"
        is LoadState.Ready -> "Model: ready (${load.backend})"
        is LoadState.Error -> "Model: error"
    }
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
        Text(
            "$modeText  •  $net",
            color = J.Dim,
            style = MaterialTheme.typography.labelMedium
        )
        Text(model, color = if (load is LoadState.Error) J.Bad else J.Dim, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun Bubble(m: UiMessage) {
    val shape = RoundedCornerShape(14.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.isUser) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier
                .widthIn(max = 320.dp)
                .background(if (m.isUser) J.Blue.copy(alpha = 0.35f) else J.PanelHi, shape)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            if (!m.isUser && m.source.isNotBlank()) {
                Text("JARVIS · ${m.source}", color = J.Cyan, style = MaterialTheme.typography.labelSmall)
            }
            Text(m.text, color = J.Text, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
