package com.jarvis.assistant.util

/**
 * Fixed answer for "what is your name / who are you". A 0.6B model often forgets its name,
 * so this one question is answered by a rule instead of the model. Pure Kotlin.
 */
object Identity {
    private val ask = Regex(
        "(what('s| is) your name|what are you called|who are you|tell me your name|your name\\b|" +
            "tumhara naam|tumhaara naam|aapka naam|apka naam|tera naam|tu kaun|tum kaun|aap kaun|" +
            "tumhe kya kehte|naam kya|तुम्हारा नाम|आपका नाम|तेरा नाम|तुम कौन|आप कौन|तू कौन|नाम क्या)",
        RegexOption.IGNORE_CASE
    )
    private val hinglishHint = Regex("\\b(tumhara|tumhaara|aapka|apka|tera|kaun|naam|kya|kehte)\\b", RegexOption.IGNORE_CASE)

    fun answer(text: String): String? {
        val t = text.trim()
        if (t.length > 60 || !ask.containsMatchIn(t)) return null
        return when {
            SpeechText.looksDevanagari(t) -> "मैं जार्विस हूँ, ${Persona.addressHindi()}। जस्ट ए रादर वेरी इंटेलिजेंट सिस्टम, आपकी सेवा में।"
            hinglishHint.containsMatchIn(t) -> "Main Jarvis hoon, ${Persona.address}. Just A Rather Very Intelligent System, aapki seva mein."
            else -> "I am Jarvis, ${Persona.address}. Just A Rather Very Intelligent System, at your service."
        }
    }
}
