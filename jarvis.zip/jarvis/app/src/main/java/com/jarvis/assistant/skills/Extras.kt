package com.jarvis.assistant.skills

import java.util.Locale

/** What the user asked for among the "extra" features. Pure Kotlin: parsing only, easy to test. */
sealed interface Extra {
    data class AddSkill(val trigger: String, val steps: List<String>) : Extra
    data class DeleteSkill(val trigger: String) : Extra
    data object ListSkills : Extra
    data object Briefing : Extra
    data class Research(val topic: String) : Extra
    data object SaveLast : Extra
    data class AddAlias(val nickname: String, val name: String) : Extra
    data class DeleteAlias(val nickname: String) : Extra
    data object ListAliases : Extra
    data class TgAdd(val channel: String) : Extra
    data class TgRemove(val channel: String) : Extra
    data object TgList : Extra
    data object TgCheck : Extra
}

object Extras {
    private val ic = RegexOption.IGNORE_CASE
    private val wakePrefix = Regex("^(hey |ok |okay )?(jarvis|जार्विस)[,\\s]*", ic)

    fun normalizeTrigger(raw: String): String =
        wakePrefix.replace(raw.trim().lowercase(Locale.ROOT), "")
            .replace(Regex("[!?.,।'\"]"), "").replace(Regex("\\s+"), " ").trim()

    private val add = Regex(
        "^(?:skill (?:add|banao|bana do|create|save)|new skill|add skill|naya skill|skill)\\s*:?\\s*(.{1,40}?)\\s*" +
            "(?:=|->|=>|:)\\s*(.{1,300})$", ic
    )
    private val del = Regex("^(?:skill (?:delete|remove|hatao)|delete skill|remove skill|skill hatao)\\s*:?\\s*(.{1,40})$", ic)
    private val list = Regex("^(?:my skills|skills|skill list|list skills|show skills|mere skills|skills dikhao)$", ic)
    private val brief = Regex(
        "^(?:briefing|my briefing|daily briefing|morning briefing|news briefing|today'?s briefing|brief me|" +
            "subah ki jaankari|aaj ki khabar|aaj ki khabrein|mera briefing|ब्रीफिंग|सुबह की जानकारी|आज की खबर|आज की ख़बरें)$", ic
    )
    private val research = listOf(
        Regex("^(?:do |deep |please )*research(?: on| about| karo| kro)?\\s+(.{3,150})$", ic),
        Regex("^(.{3,150}?)\\s+(?:par|pe|ke baare mein|ke bare me)\\s+research\\s*(?:karo|kro|kar do)?$", ic),
        Regex("^(?:khoj|shodh)\\s+(.{3,150})$", ic)
    )
    private val saveLast = Regex(
        "^(?:save this|save that|remember this|remember that|yaad rakho ye|ye yaad rakho|isko yaad rakho|" +
            "isse yaad rakho|ise yaad rakho|यह याद रखो|ये याद रखो)$", ic
    )

    private const val RELATION =
        "(?:didi|dii|bhaiya|bhaiyya|bhai|mummy|mom|maa|papa|dad|chacha|chachi|mama|mami|bua|nani|nana|dada|dadi|" +
            "bhabhi|jiju|boss|dost|friend|sir|madam|दीदी|भैया|भाई|मम्मी|पापा|भाभी|चाचा|मामा|बुआ|नानी|दादी|दादा|जीजू)"
    private val aliasAdd = listOf(
        Regex("^(?:alias|nickname|contact alias)\\s+(?:add\\s+|set\\s+)?(.{1,30}?)\\s*(?:=|->|=>|:|\\bis\\b|\\bhai\\b|ka naam)\\s*(.{1,40})$", ic),
        Regex("^($RELATION)\\s+(?:ka naam|ka name|ko)\\s+(.{1,40}?)\\s+(?:hai|save karo|yaad rakho|samjho|rakho)$", ic)
    )
    private val aliasDel = Regex("^(?:alias (?:delete|remove|hatao)|delete alias|remove alias|alias hatao)\\s*:?\\s*(.{1,30})$", ic)
    private val aliasList = Regex("^(?:aliases|my aliases|alias list|list aliases|nicknames|mere aliases)$", ic)
    private val tgAdd = Regex(
        "^(?:telegram\\s+(?:channel\\s+)?(?:add|jodo)|add\\s+(?:telegram\\s+)?channel|telegram channel jodo)\\s*:?\\s*(.{2,100})$", ic
    )
    private val tgDel = Regex(
        "^(?:telegram\\s+(?:channel\\s+)?(?:remove|delete|hatao)|(?:remove|delete)\\s+(?:telegram\\s+)?channel)\\s*:?\\s*(.{2,100})$", ic
    )
    private val tgList = Regex("^(?:telegram channels|my channels|my telegram channels|telegram list|channels list|mere channels)$", ic)
    private val tgWord = Regex("(telegram|टेलीग्राम)", ic)
    private val tgCheck = Regex("(check|update|naya|nayi|new|news|khabar|dekho|batao|kuch|anything|any)", ic)

    /** Steps are separated by ";" or the words "then" / "phir" / "fir". */
    fun splitSteps(raw: String): List<String> =
        raw.split(Regex("\\s*;\\s*|\\s+(?:then|phir|fir|aur phir)\\s+", ic)).map { it.trim() }.filter { it.isNotEmpty() }.take(8)

    fun parse(raw: String): Extra? {
        val t = raw.trim().replace(Regex("\\s+"), " ").trimEnd('.', '!', '?', '।')
        if (t.isEmpty() || t.length > 400) return null
        val s = wakePrefix.replace(t, "").trim()
        add.find(s)?.let {
            val trig = normalizeTrigger(it.groupValues[1])
            val steps = splitSteps(it.groupValues[2])
            if (trig.isNotEmpty() && steps.isNotEmpty()) return Extra.AddSkill(trig, steps)
        }
        del.find(s)?.let { return Extra.DeleteSkill(normalizeTrigger(it.groupValues[1])) }
        aliasDel.find(s)?.let { return Extra.DeleteAlias(it.groupValues[1].trim()) }
        for (re in aliasAdd) re.find(s)?.let {
            val nick = it.groupValues[1].trim()
            val name = it.groupValues[2].trim()
            if (nick.isNotEmpty() && name.isNotEmpty()) return Extra.AddAlias(nick, name)
        }
        if (aliasList.matches(s)) return Extra.ListAliases
        tgAdd.find(s)?.let { return Extra.TgAdd(it.groupValues[1].trim()) }
        tgDel.find(s)?.let { return Extra.TgRemove(it.groupValues[1].trim()) }
        if (tgList.matches(s)) return Extra.TgList
        if (s.length <= 80 && tgWord.containsMatchIn(s) && tgCheck.containsMatchIn(s)) return Extra.TgCheck
        if (list.matches(s)) return Extra.ListSkills
        if (brief.matches(s)) return Extra.Briefing
        if (saveLast.matches(s)) return Extra.SaveLast
        for (re in research) re.find(s)?.let { return Extra.Research(it.groupValues[1].trim()) }
        return null
    }
}
