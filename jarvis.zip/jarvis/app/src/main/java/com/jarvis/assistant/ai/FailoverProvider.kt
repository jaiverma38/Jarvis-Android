package com.jarvis.assistant.ai

import com.jarvis.assistant.data.SettingsStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.IOException

/**
 * "Auto-switch": tries the Gemini models in the order the user listed, then the OpenAI-compatible
 * provider (for example Groq). When a model says "limit reached" (429), is overloaded (5xx) or does not
 * exist (404), it is skipped for a while and the next one answers. Only the models and providers the user
 * configured are ever used. The answer bubble shows which model replied.
 */
class FailoverProvider(
    private val settings: SettingsStore,
    private val gemini: GeminiProvider,
    private val openAi: OpenAiCompatProvider
) : AiProvider {
    override val id = "auto-online"

    @Volatile
    private var lastUsed: String = ""
    override val label: String get() = if (lastUsed.isBlank()) "Auto" else "Auto · $lastUsed"

    private class Cool(var until: Long = 0L, var strikes: Int = 0)

    private val cool = HashMap<String, Cool>()

    fun isConfigured(): Boolean = gemini.hasKey() || openAi.isConfigured()

    /** Models to try, in order. Each entry is "gemini:<model>" or "openai". */
    private fun chain(): List<String> {
        val out = ArrayList<String>()
        if (gemini.hasKey()) {
            parseModels(settings.current.geminiModels).forEach { out.add("gemini:$it") }
        }
        if (openAi.isConfigured()) out.add("openai")
        return out
    }

    fun names(): List<String> = chain().map { it.removePrefix("gemini:") }

    /** A short status for Settings: which models are resting right now and for how long. */
    @Synchronized
    fun status(): String {
        val now = System.currentTimeMillis()
        val resting = cool.filter { it.value.until > now }
        val used = if (lastUsed.isBlank()) "none yet" else lastUsed
        if (resting.isEmpty()) return "Last answered by: $used. No model is resting."
        return "Last answered by: $used. Resting: " + resting.entries.joinToString("; ") {
            val mins = ((it.value.until - now) / 60_000).toInt() + 1
            "${it.key.removePrefix("gemini:")} (~$mins min)"
        }
    }

    @Synchronized
    private fun isResting(key: String) = (cool[key]?.until ?: 0L) > System.currentTimeMillis()

    @Synchronized
    private fun penalize(key: String, code: Int) {
        val c = cool.getOrPut(key) { Cool() }
        val ms = when (code) {
            429 -> { c.strikes++; when (c.strikes) { 1 -> 65_000L; 2 -> 10 * 60_000L; else -> 60 * 60_000L } }
            400, 404 -> 24 * 60 * 60_000L
            401, 403 -> 10 * 60_000L
            else -> 30_000L
        }
        c.until = System.currentTimeMillis() + ms
    }

    @Synchronized
    private fun success(key: String) {
        cool[key]?.apply { strikes = 0; until = 0L }
    }

    override fun generate(request: ChatRequest): Flow<String> = flow {
        val all = chain()
        if (all.isEmpty()) throw IllegalStateException("Auto-switch needs a Gemini key or a Groq/OpenAI-compatible key. Open Settings.")
        // Models that are resting go last, so something always gets tried.
        val ready = all.filter { !isResting(it) }
        val order = ready + all.filter { isResting(it) }
        var lastError = "No model answered."
        var tried = 0
        for (key in order) {
            // Do not hammer resting models: only retry them if nothing else is left.
            if (isResting(key) && tried > 0 && ready.isNotEmpty()) continue
            tried++
            var text: String? = null
            try {
                text = if (key == "openai") openAi.call(request) else gemini.call(key.removePrefix("gemini:"), request)
            } catch (e: ApiException) {
                penalize(key, e.code)
                lastError = e.friendly()
                // A rejected key affects every Gemini model: stop trying the rest of them.
                if ((e.code == 401 || e.code == 403) && key.startsWith("gemini:")) {
                    order.filter { it.startsWith("gemini:") }.forEach { penalize(it, e.code) }
                }
            } catch (e: IOException) {
                penalize(key, 503)
                lastError = "Network problem."
            }
            if (text == null) continue
            if (text.isBlank()) { lastError = "Empty answer."; continue }
            success(key)
            lastUsed = if (key == "openai") settings.current.openAiModel.substringAfterLast('/') else key.removePrefix("gemini:")
            emit(text)
            return@flow
        }
        throw IllegalStateException("All online models are busy or unavailable right now. Last problem: $lastError")
    }

    companion object {
        /** Default order: best quality first, then the models with the biggest free daily quota. */
        val DEFAULT_MODELS = listOf(
            "gemini-3.8-flash", "gemini-3.6-flash", "gemini-3-flash", "gemini-2.5-flash",
            "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-2.5-flash-lite"
        ).joinToString("\n")

        fun parseModels(text: String): List<String> =
            text.split('\n', ',', ' ').map { it.trim().removePrefix("models/") }
                .filter { it.matches(Regex("[A-Za-z0-9._-]{1,80}")) }.distinct()

        /**
         * Builds a sensible order from the ids Google reports for this key: text chat models only
         * (no image, speech, live, embedding, robotics, agent or "computer use" models), newest and
         * strongest first, small "lite" models next, open Gemma models last.
         */
        fun rank(ids: List<String>): List<String> {
            val skip = Regex("tts|image|live|embed|transcribe|robotics|computer|research|audio|veo|imagen|lyria|genie|omni|antigravity|aqa|learnlm|banana|decision|translate")
            val ok = ids.filter { !skip.containsMatchIn(it.lowercase()) }
            fun ver(id: String): Double =
                Regex("(\\d+(?:\\.\\d+)?)").find(id.removePrefix("gemini-").removePrefix("gemma-"))?.value?.toDoubleOrNull() ?: 0.0
            fun tier(id: String): Int = when {
                id.startsWith("gemma") -> 3
                id.contains("lite") -> 2
                id.contains("flash") -> 0
                id.contains("pro") -> 1
                else -> 4
            }
            return ok.filter { !it.contains("preview") || ok.none { o -> o == it.replace("-preview", "") } }
                .sortedWith(compareBy<String>({ tier(it) }, { -ver(it) }, { it }))
        }
    }
}
