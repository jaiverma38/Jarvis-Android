package com.jarvis.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.MainViewModel
import com.jarvis.assistant.data.AiMode
import com.jarvis.assistant.data.OnlineKind
import com.jarvis.assistant.data.VoiceLang
import com.jarvis.assistant.data.WakeSensitivity
import com.jarvis.assistant.wake.WakeState
import com.jarvis.assistant.security.SecretNames
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: MainViewModel, c: AppContainer) {
    val s by c.settings.state.collectAsStateWithLifecycle()
    val ui by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val tick = rememberResumeTick()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", color = J.Cyan, style = MaterialTheme.typography.titleLarge)

        HoloCard(title = "AI mode") {
            RadioRow(s.aiMode == AiMode.OFFLINE, "Offline only: on-device model, no cloud AI (web search below is a separate switch)") {
                c.settings.update { it.copy(aiMode = AiMode.OFFLINE) }
            }
            RadioRow(s.aiMode == AiMode.ONLINE, "Online only: your chosen cloud AI, needs internet and a key") {
                c.settings.update { it.copy(aiMode = AiMode.ONLINE) }
            }
            RadioRow(s.aiMode == AiMode.AUTO, "Auto: cloud AI when internet and key exist, otherwise on-device") {
                c.settings.update { it.copy(aiMode = AiMode.AUTO) }
            }
            Text(
                "Every answer is labelled with what produced it. Offline mode never falls back to the internet. " +
                    "Phone commands (torch, timer, volume…) always run on the phone and need no AI.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
            )
        }

        PhoneControlCard(c)
        AutomationReportCard()

        ApiCard(c, s)

        HoloCard(title = "Web search (no key needed)") {
            SwitchRow("Look up facts on Wikipedia and DuckDuckGo when I ask a question", s.webSearch) { v ->
                c.settings.update { it.copy(webSearch = v) }
            }
            Text(
                "Works only with the on-device model and when the phone is online. Your question text is sent to " +
                    "Wikipedia and DuckDuckGo to find a page; the on-device model then writes the answer from it, " +
                    "and the source is shown under the answer. It finds encyclopedia facts, not live news, prices " +
                    "or weather. Switch it off to keep every question on the phone.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
            )
        }

        HoloCard(title = "Online AI provider") {
            RadioRow(s.onlineKind == OnlineKind.AUTO, "Auto-switch: many Gemini models + Groq (recommended)") {
                c.settings.update { it.copy(onlineKind = OnlineKind.AUTO) }
            }
            RadioRow(s.onlineKind == OnlineKind.GEMINI, "Google Gemini (one model)") {
                c.settings.update { it.copy(onlineKind = OnlineKind.GEMINI) }
            }
            RadioRow(s.onlineKind == OnlineKind.OPENAI_COMPAT, "OpenAI-compatible API (for example NVIDIA)") {
                c.settings.update { it.copy(onlineKind = OnlineKind.OPENAI_COMPAT) }
            }

            if (s.onlineKind == OnlineKind.AUTO) {
                AutoSwitchSection(c, s)
            } else if (s.onlineKind == OnlineKind.GEMINI) {
                TextSetting("Gemini model name", s.geminiModel) { v -> c.settings.update { it.copy(geminiModel = v) } }
                KeyField("Gemini API key", c, SecretNames.GEMINI)
            } else {
                OutlinedButton(onClick = {
                    c.settings.update {
                        it.copy(
                            openAiBaseUrl = "https://api.groq.com/openai/v1",
                            openAiModel = "openai/gpt-oss-120b",
                            aiMode = com.jarvis.assistant.data.AiMode.AUTO
                        )
                    }
                }) { Text("Fill in Groq (free key at console.groq.com)") }
                TextSetting("Base URL (https)", s.openAiBaseUrl) { v -> c.settings.update { it.copy(openAiBaseUrl = v) } }
                TextSetting("Model name", s.openAiModel) { v -> c.settings.update { it.copy(openAiModel = v) } }
                KeyField("API key", c, SecretNames.OPENAI_COMPAT)
            }
            Text(
                "Your key is encrypted with the Android Keystore and never shown again. Honest limit: a key " +
                    "that is built into an APK can always be extracted, so JARVIS ships with none; you enter your own. " +
                    "Model names change over time: if you get a 404, check the provider's current model list.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
            )
        }

        HoloCard(title = "Voice") {
            VoiceLang.entries.forEach { lang ->
                RadioRow(s.voiceLang == lang, lang.label) { c.settings.update { it.copy(voiceLang = lang) } }
            }
            SwitchRow("Prefer offline speech recognition", s.preferOfflineSpeech) { v ->
                c.settings.update { it.copy(preferOfflineSpeech = v) }
            }
            SwitchRow("Speak replies after a voice command", s.speakReplies) { v ->
                c.settings.update { it.copy(speakReplies = v) }
            }
            SwitchRow("Conversation mode: listen again after JARVIS speaks", s.conversationMode) { v ->
                c.settings.update { it.copy(conversationMode = v) }
            }
            Text(
                "By default the microphone opens only after you tap the orb, with a visible notification and " +
                    "a Stop button. The optional \u201CHey Jarvis\u201D wake word is configured below. " +
                    "JARVIS does not identify who is speaking.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = vm::checkVoice, modifier = Modifier.padding(top = 6.dp)) {
                Text("Check speech services")
            }
            VoicePicker(c)
            if (ui.voiceInfo.isNotBlank()) Text(ui.voiceInfo, color = J.Text, style = MaterialTheme.typography.bodySmall)
        }

        WakeCard(c)

        HoloCard(title = "Permissions") {
            val micOk = granted(ctx, Manifest.permission.RECORD_AUDIO, tick)
            val notifOk = Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS, tick)
            val writeOk = Settings.System.canWrite(ctx).also { tick.hashCode() }
            val listenerOk = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

            val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
            val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

            PermRow("Microphone", "Only used while you have tapped the orb.", micOk) {
                if (!micOk) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            PermRow("Notifications", "Shows the microphone-on notification with a Stop button.", notifOk) {
                if (!notifOk && Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            PermRow("Change brightness", "Needed only for brightness commands. Opens an Android page.", writeOk) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            PermRow("Notification access", "Needed only to read notifications aloud. Opt-in; opens an Android page.", listenerOk) {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            SwitchRow("Let JARVIS read notifications (kept in memory only)", s.notificationReading) { v ->
                c.settings.update { it.copy(notificationReading = v) }
                if (!v) com.jarvis.assistant.notifications.JarvisNotificationListener.clear()
            }
        }
    }
}

private fun granted(ctx: android.content.Context, perm: String, @Suppress("UNUSED_PARAMETER") tick: Int) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = J.Text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermRow(name: String, why: String, ok: Boolean, onFix: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()) {
            Text("$name: ${if (ok) "allowed" else "not allowed"}", color = if (ok) J.Good else J.Warn,
                modifier = Modifier.weight(1f))
            OutlinedButton(onClick = onFix) { Text(if (ok) "Manage" else "Allow") }
        }
        Text(why, color = J.Dim, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun TextSetting(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(200)) },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
    )
}

@Composable
private fun KeyField(label: String, c: AppContainer, secretName: String) {
    var text by remember { mutableStateOf("") }
    var saved by remember(secretName) { mutableStateOf(c.secrets.has(secretName)) }
    Column(Modifier.padding(top = 6.dp)) {
        Text(
            if (saved) "$label: saved (hidden)" else "$label: not set",
            color = if (saved) J.Good else J.Warn
        )
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(300) },
            label = { Text("Paste new key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
            Button(
                onClick = {
                    c.secrets.put(secretName, text)
                    text = ""
                    saved = true
                },
                enabled = text.isNotBlank()
            ) { Text("Save key") }
            OutlinedButton(
                onClick = {
                    c.secrets.remove(secretName)
                    saved = false
                },
                enabled = saved
            ) { Text("Remove key") }
        }
    }
}

@Composable
private fun WakeCard(c: AppContainer) {
    val s by c.settings.state.collectAsStateWithLifecycle()
    val st by c.wake.status.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    fun turnOn() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        c.settings.update { it.copy(wakeEnabled = true) }
        c.startWakeService()
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) turnOn()
    }

    HoloCard(title = "Wake word: \u201CHey Jarvis\u201D") {
        SwitchRow("Listen for \u201CHey Jarvis\u201D in the background", s.wakeEnabled) { on ->
            if (on) {
                val has = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (has) turnOn() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                c.settings.update { it.copy(wakeEnabled = false) }
                c.stopWakeService()
            }
        }
        val statusText = when (st.state) {
            WakeState.LISTENING -> "Status: listening for \u201CHey Jarvis\u201D now."
            WakeState.PAUSED -> "Status: paused (${st.detail})."
            WakeState.STARTING -> "Status: starting\u2026"
            WakeState.ERROR -> "Stopped: ${st.detail}"
            WakeState.OFF -> "Status: off."
        }
        Text(
            statusText,
            color = if (st.state == WakeState.ERROR) J.Bad else if (st.state == WakeState.LISTENING) J.Good else J.Text,
            style = MaterialTheme.typography.bodyMedium
        )
        if (st.state == WakeState.LISTENING) {
            val score by c.wake.lastScore.collectAsStateWithLifecycle()
            val need = com.jarvis.assistant.wake.WakeWordController.thresholdFor(s.wakeSensitivity)
            Text(
                "Live score: ${"%.2f".format(score)} (it must reach ${"%.2f".format(need)}). Say \u201CHey Jarvis\u201D " +
                    "and watch it. If it stays low, choose a higher sensitivity; if it triggers on its own, choose lower.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall
            )
        }
        Text("Sensitivity", color = J.Cyan, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
        WakeSensitivity.entries.forEach { sens ->
            RadioRow(s.wakeSensitivity == sens, sens.label) { c.settings.update { it.copy(wakeSensitivity = sens) } }
        }
        Text("Save battery", color = J.Cyan, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
        com.jarvis.assistant.data.WakeWhen.entries.forEach { w ->
            RadioRow(s.wakeWhen == w, w.label) { c.settings.update { it.copy(wakeWhen = w) } }
        }
        SwitchRow("Pause when the phone is in a pocket, bag or face down", s.wakePocket) { v ->
            c.settings.update { it.copy(wakePocket = v) }
        }
        SwitchRow("Pause at night (${s.wakeNightStart}:00 to ${s.wakeNightEnd}:00)", s.wakeNight) { v ->
            c.settings.update { it.copy(wakeNight = v) }
        }
        Text(
            "While paused the microphone is fully closed, so it uses almost no battery, and it reopens by itself. " +
                "Pocket detection uses the proximity sensor. For a zero-battery way to talk any time, add the " +
                "\u201CTalk to JARVIS\u201D tile: swipe down twice, tap the pencil or + icon, and drag the tile in.",
            color = J.Dim, style = MaterialTheme.typography.bodySmall
        )
        Text(
            "How it works: a small model on this phone's CPU checks the microphone sound for the phrase " +
                "\u201CHey Jarvis\u201D. Sound is held only in a tiny memory buffer that is constantly overwritten. " +
                "It is never saved, never sent anywhere, and the microphone is released the moment the phrase is " +
                "heard so JARVIS can listen to your command. Differences from Google Assistant: phones do this on a " +
                "special low-power chip that other apps cannot use, so JARVIS uses the normal processor and costs " +
                "more battery; Android shows its green microphone dot and a permanent notification while it " +
                "listens; and after a restart you must open JARVIS once to start it again (an Android 12 rule). " +
                "It only reacts to the phrase, not to who says it. Loud music or calls can hide or block it.",
            color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
private fun VoicePicker(c: AppContainer) {
    val s by c.settings.state.collectAsStateWithLifecycle()
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var voices by remember { mutableStateOf<List<com.jarvis.assistant.voice.VoiceController.VoiceOption>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        voices = c.voice.listVoices()
        loaded = true
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 8.dp)) {
        Text("Speaking voice", color = J.Cyan, style = MaterialTheme.typography.titleSmall)
        RadioRow(s.ttsVoice.isBlank(), "Automatic: British voice if installed (JARVIS style)") { c.settings.update { it.copy(ttsVoice = "") } }
        voices.forEach { v ->
            RadioRow(s.ttsVoice == v.name, v.label) { c.settings.update { it.copy(ttsVoice = v.name) } }
        }
        if (loaded && voices.isEmpty()) {
            Text("No voices found.", color = J.Dim, style = MaterialTheme.typography.bodySmall)
        }
        Text("Speed ${"%.2f".format(s.ttsRate)}", color = J.Text, style = MaterialTheme.typography.bodySmall)
        androidx.compose.material3.Slider(
            value = s.ttsRate, valueRange = 0.6f..1.6f,
            onValueChange = { v -> c.settings.update { it.copy(ttsRate = v) } }
        )
        Text("Pitch ${"%.2f".format(s.ttsPitch)} (lower is deeper)", color = J.Text, style = MaterialTheme.typography.bodySmall)
        androidx.compose.material3.Slider(
            value = s.ttsPitch, valueRange = 0.6f..1.4f,
            onValueChange = { v -> c.settings.update { it.copy(ttsPitch = v) } }
        )
        SwitchRow("Start listening as soon as JARVIS opens (for \u201CHey Google, open Jarvis\u201D)", s.listenOnOpen) { v ->
            c.settings.update { it.copy(listenOnOpen = v) }
        }
        SwitchRow("Greet me when I open JARVIS (spoken if voice replies are on)", s.greetOnOpen) { v ->
            c.settings.update { it.copy(greetOnOpen = v) }
        }
        SwitchRow("Hindi replies in Devanagari (हिंदी) so the Hindi voice reads them properly", s.hindiInDevanagari) { v ->
            c.settings.update { it.copy(hindiInDevanagari = v) }
        }
        Text("Address me as", color = J.Cyan, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
        listOf("sir", "boss", "Jai").forEach { name ->
            RadioRow(s.addressAs == name, name) { c.settings.update { it.copy(addressAs = name) } }
        }
        OutlinedButton(onClick = { scope.launch { c.voice.speakSample() } }) { Text("Play sample") }
        Text(
            "Most natural free voice (works offline, no key): 1) Install SherpaTTS (search \"SherpaTTS\" on F-Droid, " +
                "package org.woheller69.ttsengine, about 86 MB). 2) Open it, go to Manage Languages and download an " +
                "English (UK) male voice and a Hindi voice. 3) Open the button below and set SherpaTTS as the " +
                "preferred engine. 4) Come back, tap Reload voices, pick the voice, tap Play sample. " +
                "Without it, the phone's own Google voices are used (install the UK English voice for a British sound).",
            color = J.Dim, style = MaterialTheme.typography.bodySmall
        )
        val ctxLocal = androidx.compose.ui.platform.LocalContext.current
        OutlinedButton(onClick = {
            try {
                ctxLocal.startActivity(android.content.Intent("com.android.settings.TTS_SETTINGS"))
            } catch (e: Exception) {
                ctxLocal.startActivity(android.content.Intent(android.provider.Settings.ACTION_SETTINGS))
            }
        }) { Text("Open Android text-to-speech settings") }
        OutlinedButton(onClick = {
            scope.launch {
                c.voice.reloadTts()
                loaded = false
                voices = c.voice.listVoices()
                loaded = true
            }
        }) { Text("Reload voices") }
    }
}


/** The phone's local-network IPv4 address (Wi-Fi), or null. */
private fun localIp(): String? = runCatching {
    java.net.NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
        .firstOrNull { !it.isLoopbackAddress && it is java.net.Inet4Address && it.isSiteLocalAddress }?.hostAddress
}.getOrNull()

@Composable
private fun AutoSwitchSection(c: AppContainer, s: com.jarvis.assistant.data.AppSettings) {
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(c.failover.status()) }
    KeyField("Google AI Studio key (Gemini)", c, SecretNames.GEMINI)
    OutlinedTextField(
        value = s.geminiModels,
        onValueChange = { v -> c.settings.update { it.copy(geminiModels = v.take(2000)) } },
        label = { Text("Gemini models, one per line, tried from the top") },
        minLines = 4,
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
        OutlinedButton(enabled = !busy, onClick = {
            busy = true
            msg = "Asking Google which models your key can use…"
            scope.launch {
                msg = try {
                    val ids = c.gemini.listModels()
                    val ranked = com.jarvis.assistant.ai.FailoverProvider.rank(ids)
                    if (ranked.isEmpty()) "Google returned no chat models for this key." else {
                        c.settings.update { it.copy(geminiModels = ranked.joinToString("\n")) }
                        "Done: ${ranked.size} models filled in. Move your favourites to the top."
                    }
                } catch (e: Exception) {
                    e.message ?: "Could not fetch the model list."
                }
                busy = false
            }
        }) { Text("Auto-fill models from my key") }
        OutlinedButton(onClick = {
            c.settings.update { it.copy(geminiModels = com.jarvis.assistant.ai.FailoverProvider.DEFAULT_MODELS) }
        }) { Text("Reset list") }
    }
    if (msg.isNotBlank()) Text(msg, color = J.Dim, style = MaterialTheme.typography.bodySmall)
    OutlinedButton(onClick = {
        c.settings.update {
            it.copy(
                openAiBaseUrl = "https://api.groq.com/openai/v1",
                openAiModel = "openai/gpt-oss-120b",
                aiMode = com.jarvis.assistant.data.AiMode.AUTO
            )
        }
    }, modifier = Modifier.padding(top = 6.dp)) { Text("Also add Groq as the last fallback (free key at console.groq.com)") }
    TextSetting("Fallback base URL (https)", s.openAiBaseUrl) { v -> c.settings.update { it.copy(openAiBaseUrl = v) } }
    TextSetting("Fallback model name", s.openAiModel) { v -> c.settings.update { it.copy(openAiModel = v) } }
    KeyField("Fallback API key (Groq)", c, SecretNames.OPENAI_COMPAT)
    OutlinedButton(onClick = { status = c.failover.status() }, modifier = Modifier.padding(top = 6.dp)) {
        Text("Show which model is resting")
    }
    Text(status, color = J.Text, style = MaterialTheme.typography.bodySmall)
    Text(
        "How it works: Jarvis tries the first model. If Google says the limit is reached (429), the model is " +
            "overloaded, or the name does not exist, that model rests (1 min, then 10 min, then 1 hour; a wrong " +
            "name for a day) and the next one answers. Groq is used last. The answer bubble shows which model " +
            "replied. Model names that your key does not have are simply skipped, so a wrong guess is harmless. " +
            "The free daily limits are small for the big Flash models (about 20 a day) and bigger for the Lite " +
            "and Gemma ones, so the list order decides quality versus quota.",
        color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
    )
}

/** Wi-Fi address and, if Tailscale is on, the Tailscale address (100.64.0.0/10). */
private fun tailscaleIp(): String? = runCatching {
    java.net.NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
        .filterIsInstance<java.net.Inet4Address>()
        .firstOrNull { val b = it.address; (b[0].toInt() and 0xFF) == 100 && (b[1].toInt() and 0xC0) == 64 }
        ?.hostAddress
}.getOrNull()

@Composable
private fun ApiCard(c: AppContainer, s: com.jarvis.assistant.data.AppSettings) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(c.jarvisApiKey()) }
    HoloCard(title = "Jarvis API: use this phone's models from other devices") {
        SwitchRow("Turn on the Jarvis API (Wi-Fi, or anywhere with Tailscale)", s.apiServerEnabled) { v ->
            c.settings.update { it.copy(apiServerEnabled = v) }
            if (v) c.startApiService() else c.stopApiService()
        }
        val ip = localIp()
        val ts = tailscaleIp()
        Text(
            "Address on the same Wi-Fi: http://${ip ?: "(connect to Wi-Fi)"}:${com.jarvis.assistant.api.JarvisApiServer.DEFAULT_PORT}/v1\n" +
                (if (ts != null) "Address from anywhere (Tailscale): http://$ts:${com.jarvis.assistant.api.JarvisApiServer.DEFAULT_PORT}/v1\n"
                else "Tailscale is not active on this phone (see the note below for use from anywhere).\n") +
                "Jarvis key: $key\n" +
                "Model names: jarvis (online if possible, else offline), jarvis-online (Gemini models + Groq with auto-switch), jarvis-offline.",
            color = J.Text, style = MaterialTheme.typography.bodySmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Jarvis key", key))
            }) { Text("Copy key") }
            OutlinedButton(onClick = { key = c.jarvisApiKey(regenerate = true) }) { Text("New key") }
        }
        Text(
            "On the other device, set Online AI to OpenAI-compatible, paste the address as Base URL, the Jarvis key " +
                "as API key, and a model name above. Your real Groq key stays on this phone. Honest limits: it works " +
                "only while this phone is on and on the same Wi-Fi, and on that Wi-Fi the key travels as plain HTTP, " +
                "so use it only on a network you trust. From anywhere, including the offline model: install the free " +
                "Tailscale app on this phone and on the other device, sign in to the same account, and use the " +
                "Tailscale address above (Tailscale encrypts it, so plain HTTP is fine there). For the online models " +
                "only, without Tailscale, deploy jarvis-gateway-worker.js on Cloudflare.",
            color = J.Dim, style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun AutomationReportCard() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(com.jarvis.assistant.automation.WaAutomation.report) }
    HoloCard(title = "YouTube/Instagram helper: last report") {
        Text(
            "If search, play or comment does not work, run it once, then press Refresh and Copy and send me this " +
                "text. It lists the step JARVIS was on and the button names it could see. It stays on this phone " +
                "until you copy it yourself.",
            color = J.Dim, style = MaterialTheme.typography.bodySmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { text = com.jarvis.assistant.automation.WaAutomation.report }) { Text("Refresh") }
            OutlinedButton(onClick = {
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Jarvis report", text))
            }) { Text("Copy") }
        }
        Text(text.take(3000), color = J.Text, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun PhoneControlCard(c: AppContainer) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var contacts by remember {
        mutableStateOf(
            androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_CONTACTS) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val overlay = android.provider.Settings.canDrawOverlays(ctx)
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted -> contacts = granted }
    HoloCard(title = "Phone control: apps, music, WhatsApp") {
        Text(
            "Contacts: ${if (contacts) "allowed" else "not allowed"}. Needed to call or message a WhatsApp contact " +
                "by name. Contacts are only read when you ask, and never leave the phone.",
            color = J.Text, style = MaterialTheme.typography.bodySmall
        )
        OutlinedButton(onClick = { launcher.launch(android.Manifest.permission.READ_CONTACTS) }) {
            Text("Allow contacts")
        }
        val waState by c.settings.state.collectAsStateWithLifecycle()
        val a11y = com.jarvis.assistant.automation.WaAutomation.serviceEnabled(ctx)
        SwitchRow("Send WhatsApp messages and calls directly, without asking each time", waState.waAutoSend) { v ->
            c.settings.update { it.copy(waAutoSend = v) }
        }
        Text(
            "Automatic sending, calling and starting songs needs JARVIS switched on in Android Accessibility settings: " +
                "${if (a11y) "ON" else "OFF"}. It only presses WhatsApp's own Send or Call button, only for about " +
                "20 seconds after you ask (songs: 30), and reads nothing. (Reopen this tab to refresh the status.)",
            color = J.Text, style = MaterialTheme.typography.bodySmall
        )
        OutlinedButton(onClick = {
            ctx.startActivity(
                android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("Open Accessibility settings") }
        Text(
            "Open apps from the background: ${if (overlay) "allowed" else "not allowed"}. Android stops an app from " +
                "opening other apps unless it is on screen. Allow this once so \"Hey Jarvis, open YouTube\" works " +
                "while JARVIS is in the background. (Reopen this tab to refresh the status.)",
            color = J.Text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)
        )
        OutlinedButton(onClick = {
            ctx.startActivity(
                android.content.Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + ctx.packageName)
                )
            )
        }) { Text("Allow opening apps from the background") }
        Text(
            "WhatsApp calls start straight away after you confirm. WhatsApp messages open the chat with your text " +
                "ready; you press send. Closing an app sends it home and stops its background processes.",
            color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)
        )
    }
}
