package com.jarvis.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.MainViewModel
import com.jarvis.assistant.data.AiMode
import com.jarvis.assistant.data.OnlineKind
import com.jarvis.assistant.data.VoiceLang
import com.jarvis.assistant.data.WakeSensitivity
import com.jarvis.assistant.wake.WakeState
import com.jarvis.assistant.security.SecretNames
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: MainViewModel, c: AppContainer) {
    val s by c.settings.state.collectAsStateWithLifecycle()
    val ui by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val tick = rememberResumeTick()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", color = J.Cyan, style = MaterialTheme.typography.titleLarge)

        HoloCard(title = "AI mode") {
            RadioRow(s.aiMode == AiMode.OFFLINE, "Offline only: on-device model, no cloud AI (web search below is a separate switch)") {
                c.settings.update { it.copy(aiMode = AiMode.OFFLINE) }
            }
            RadioRow(s.aiMode == AiMode.ONLINE, "Online only: your chosen cloud AI, needs internet and a key") {
                c.settings.update { it.copy(aiMode = AiMode.ONLINE) }
            }
            RadioRow(s.aiMode == AiMode.AUTO, "Auto: cloud AI when internet and key exist, otherwise on-device") {
                c.settings.update { it.copy(aiMode = AiMode.AUTO) }
            }
            Text(
                "Every answer is labelled with what produced it. Offline mode never falls back to the internet. " +
                    "Phone commands (torch, timer, volume…) always run on the phone and need no AI.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
            )
        }

        PhoneControlCard(c)

        HoloCard(title = "Web search (no key needed)") {
            SwitchRow("Look up facts on Wikipedia and DuckDuckGo when I ask a question", s.webSearch) { v ->
                c.settings.update { it.copy(webSearch = v) }
            }
            Text(
                "Works only with the on-device model and when the phone is online. Your question text is sent to " +
                    "Wikipedia and DuckDuckGo to find a page; the on-device model then writes the answer from it, " +
                    "and the source is shown under the answer. It finds encyclopedia facts, not live news, prices " +
                    "or weather. Switch it off to keep every question on the phone.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
            )
        }

        HoloCard(title = "Online AI provider") {
            RadioRow(s.onlineKind == OnlineKind.GEMINI, "Google Gemini") {
                c.settings.update { it.copy(onlineKind = OnlineKind.GEMINI) }
            }
            RadioRow(s.onlineKind == OnlineKind.OPENAI_COMPAT, "OpenAI-compatible API (for example NVIDIA)") {
                c.settings.update { it.copy(onlineKind = OnlineKind.OPENAI_COMPAT) }
            }

            if (s.onlineKind == OnlineKind.GEMINI) {
                TextSetting("Gemini model name", s.geminiModel) { v -> c.settings.update { it.copy(geminiModel = v) } }
                KeyField("Gemini API key", c, SecretNames.GEMINI)
            } else {
                TextSetting("Base URL (https)", s.openAiBaseUrl) { v -> c.settings.update { it.copy(openAiBaseUrl = v) } }
                TextSetting("Model name", s.openAiModel) { v -> c.settings.update { it.copy(openAiModel = v) } }
                KeyField("API key", c, SecretNames.OPENAI_COMPAT)
            }
            Text(
                "Your key is encrypted with the Android Keystore and never shown again. Honest limit: a key " +
                    "that is built into an APK can always be extracted, so JARVIS ships with none; you enter your own. " +
                    "Model names change over time: if you get a 404, check the provider's current model list.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
            )
        }

        HoloCard(title = "Voice") {
            VoiceLang.entries.forEach { lang ->
                RadioRow(s.voiceLang == lang, lang.label) { c.settings.update { it.copy(voiceLang = lang) } }
            }
            SwitchRow("Prefer offline speech recognition", s.preferOfflineSpeech) { v ->
                c.settings.update { it.copy(preferOfflineSpeech = v) }
            }
            SwitchRow("Speak replies after a voice command", s.speakReplies) { v ->
                c.settings.update { it.copy(speakReplies = v) }
            }
            SwitchRow("Conversation mode: listen again after JARVIS speaks", s.conversationMode) { v ->
                c.settings.update { it.copy(conversationMode = v) }
            }
            Text(
                "By default the microphone opens only after you tap the orb, with a visible notification and " +
                    "a Stop button. The optional \u201CHey Jarvis\u201D wake word is configured below. " +
                    "JARVIS does not identify who is speaking.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = vm::checkVoice, modifier = Modifier.padding(top = 6.dp)) {
                Text("Check speech services")
            }
            VoicePicker(c)
            if (ui.voiceInfo.isNotBlank()) Text(ui.voiceInfo, color = J.Text, style = MaterialTheme.typography.bodySmall)
        }

        WakeCard(c)

        HoloCard(title = "Permissions") {
            val micOk = granted(ctx, Manifest.permission.RECORD_AUDIO, tick)
            val notifOk = Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS, tick)
            val writeOk = Settings.System.canWrite(ctx).also { tick.hashCode() }
            val listenerOk = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

            val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
            val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

            PermRow("Microphone", "Only used while you have tapped the orb.", micOk) {
                if (!micOk) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            PermRow("Notifications", "Shows the microphone-on notification with a Stop button.", notifOk) {
                if (!notifOk && Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            PermRow("Change brightness", "Needed only for brightness commands. Opens an Android page.", writeOk) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            PermRow("Notification access", "Needed only to read notifications aloud. Opt-in; opens an Android page.", listenerOk) {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            SwitchRow("Let JARVIS read notifications (kept in memory only)", s.notificationReading) { v ->
                c.settings.update { it.copy(notificationReading = v) }
                if (!v) com.jarvis.assistant.notifications.JarvisNotificationListener.clear()
            }
        }
    }
}

private fun granted(ctx: android.content.Context, perm: String, @Suppress("UNUSED_PARAMETER") tick: Int) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = J.Text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermRow(name: String, why: String, ok: Boolean, onFix: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()) {
            Text("$name: ${if (ok) "allowed" else "not allowed"}", color = if (ok) J.Good else J.Warn,
                modifier = Modifier.weight(1f))
            OutlinedButton(onClick = onFix) { Text(if (ok) "Manage" else "Allow") }
        }
        Text(why, color = J.Dim, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun TextSetting(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(200)) },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
    )
}

@Composable
private fun KeyField(label: String, c: AppContainer, secretName: String) {
    var text by remember { mutableStateOf("") }
    var saved by remember(secretName) { mutableStateOf(c.secrets.has(secretName)) }
    Column(Modifier.padding(top = 6.dp)) {
        Text(
            if (saved) "$label: saved (hidden)" else "$label: not set",
            color = if (saved) J.Good else J.Warn
        )
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(300) },
            label = { Text("Paste new key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
            Button(
                onClick = {
                    c.secrets.put(secretName, text)
                    text = ""
                    saved = true
                },
                enabled = text.isNotBlank()
            ) { Text("Save key") }
            OutlinedButton(
                onClick = {
                    c.secrets.remove(secretName)
                    saved = false
                },
                enabled = saved
            ) { Text("Remove key") }
        }
    }
}

@Composable
private fun WakeCard(c: AppContainer) {
    val s by c.settings.state.collectAsStateWithLifecycle()
    val st by c.wake.status.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    fun turnOn() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        c.settings.update { it.copy(wakeEnabled = true) }
        c.startWakeService()
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) turnOn()
    }

    HoloCard(title = "Wake word: \u201CHey Jarvis\u201D") {
        SwitchRow("Listen for \u201CHey Jarvis\u201D in the background", s.wakeEnabled) { on ->
            if (on) {
                val has = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (has) turnOn() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                c.settings.update { it.copy(wakeEnabled = false) }
                c.stopWakeService()
            }
        }
        val statusText = when (st.state) {
            WakeState.LISTENING -> "Status: listening for \u201CHey Jarvis\u201D now."
            WakeState.PAUSED -> "Status: paused (${st.detail})."
            WakeState.STARTING -> "Status: starting\u2026"
            WakeState.ERROR -> "Stopped: ${st.detail}"
            WakeState.OFF -> "Status: off."
        }
        Text(
            statusText,
            color = if (st.state == WakeState.ERROR) J.Bad else if (st.state == WakeState.LISTENING) J.Good else J.Text,
            style = MaterialTheme.typography.bodyMedium
        )
        if (st.state == WakeState.LISTENING) {
            val score by c.wake.lastScore.collectAsStateWithLifecycle()
            val need = com.jarvis.assistant.wake.WakeWordController.thresholdFor(s.wakeSensitivity)
            Text(
                "Live score: ${"%.2f".format(score)} (it must reach ${"%.2f".format(need)}). Say \u201CHey Jarvis\u201D " +
                    "and watch it. If it stays low, choose a higher sensitivity; if it triggers on its own, choose lower.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall
            )
        }
        Text("Sensitivity", color = J.Cyan, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
        WakeSensitivity.entries.forEach { sens ->
            RadioRow(s.wakeSensitivity == sens, sens.label) { c.settings.update { it.copy(wakeSensitivity = sens) } }
        }
        Text(
            "How it works: a small model on this phone's CPU checks the microphone sound for the phrase " +
                "\u201CHey Jarvis\u201D. Sound is held only in a tiny memory buffer that is constantly overwritten. " +
                "It is never saved, never sent anywhere, and the microphone is released the moment the phrase is " +
                "heard so JARVIS can listen to your command. Differences from Google Assistant: phones do this on a " +
                "special low-power chip that other apps cannot use, so JARVIS uses the normal processor and costs " +
                "more battery; Android shows its green microphone dot and a permanent notification while it " +
                "listens; and after a restart you must open JARVIS once to start it again (an Android 12 rule). " +
                "It only reacts to the phrase, not to who says it. Loud music or calls can hide or block it.",
            color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
private fun VoicePicker(c: AppContainer) {
    val s by c.settings.state.collectAsStateWithLifecycle()
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var voices by remember { mutableStateOf<List<com.jarvis.assistant.voice.VoiceController.VoiceOption>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        voices = c.voice.listVoices()
        loaded = true
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 8.dp)) {
        Text("Speaking voice", color = J.Cyan, style = MaterialTheme.typography.titleSmall)
        RadioRow(s.ttsVoice.isBlank(), "Automatic: British voice if installed (JARVIS style)") { c.settings.update { it.copy(ttsVoice = "") } }
        voices.forEach { v ->
            RadioRow(s.ttsVoice == v.name, v.label) { c.settings.update { it.copy(ttsVoice = v.name) } }
        }
        if (loaded && voices.isEmpty()) {
            Text("No voices found.", color = J.Dim, style = MaterialTheme.typography.bodySmall)
        }
        Text("Speed ${"%.2f".format(s.ttsRate)}", color = J.Text, style = MaterialTheme.typography.bodySmall)
        androidx.compose.material3.Slider(
            value = s.ttsRate, valueRange = 0.6f..1.6f,
            onValueChange = { v -> c.settings.update { it.copy(ttsRate = v) } }
        )
        Text("Pitch ${"%.2f".format(s.ttsPitch)} (lower is deeper)", color = J.Text, style = MaterialTheme.typography.bodySmall)
        androidx.compose.material3.Slider(
            value = s.ttsPitch, valueRange = 0.6f..1.4f,
            onValueChange = { v -> c.settings.update { it.copy(ttsPitch = v) } }
        )
        SwitchRow("Greet me when I open JARVIS (spoken if voice replies are on)", s.greetOnOpen) { v ->
            c.settings.update { it.copy(greetOnOpen = v) }
        }
        SwitchRow("Hindi replies in Devanagari (हिंदी) so the Hindi voice reads them properly", s.hindiInDevanagari) { v ->
            c.settings.update { it.copy(hindiInDevanagari = v) }
        }
        Text("Address me as", color = J.Cyan, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
        listOf("sir", "boss", "Jai").forEach { name ->
            RadioRow(s.addressAs == name, name) { c.settings.update { it.copy(addressAs = name) } }
        }
        OutlinedButton(onClick = { scope.launch { c.voice.speakSample() } }) { Text("Play sample") }
        Text(
            "Most natural free voice (works offline, no key): 1) Install SherpaTTS (search \"SherpaTTS\" on F-Droid, " +
                "package org.woheller69.ttsengine, about 86 MB). 2) Open it, go to Manage Languages and download an " +
                "English (UK) male voice and a Hindi voice. 3) Open the button below and set SherpaTTS as the " +
                "preferred engine. 4) Come back, tap Reload voices, pick the voice, tap Play sample. " +
                "Without it, the phone's own Google voices are used (install the UK English voice for a British sound).",
            color = J.Dim, style = MaterialTheme.typography.bodySmall
        )
        val ctxLocal = androidx.compose.ui.platform.LocalContext.current
        OutlinedButton(onClick = {
            try {
                ctxLocal.startActivity(android.content.Intent("com.android.settings.TTS_SETTINGS"))
            } catch (e: Exception) {
                ctxLocal.startActivity(android.content.Intent(android.provider.Settings.ACTION_SETTINGS))
            }
        }) { Text("Open Android text-to-speech settings") }
        OutlinedButton(onClick = {
            scope.launch {
                c.voice.reloadTts()
                loaded = false
                voices = c.voice.listVoices()
                loaded = true
            }
        }) { Text("Reload voices") }
    }
}


@Composable
private fun PhoneControlCard(c: AppContainer) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var contacts by remember {
        mutableStateOf(
            androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_CONTACTS) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val overlay = android.provider.Settings.canDrawOverlays(ctx)
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted -> contacts = granted }
    HoloCard(title = "Phone control: apps, music, WhatsApp") {
        Text(
            "Contacts: ${if (contacts) "allowed" else "not allowed"}. Needed to call or message a WhatsApp contact " +
                "by name. Contacts are only read when you ask, and never leave the phone.",
            color = J.Text, style = MaterialTheme.typography.bodySmall
        )
        OutlinedButton(onClick = { launcher.launch(android.Manifest.permission.READ_CONTACTS) }) {
            Text("Allow contacts")
        }
        val waState by c.settings.state.collectAsStateWithLifecycle()
        val a11y = com.jarvis.assistant.automation.WaAutomation.serviceEnabled(ctx)
        SwitchRow("Send WhatsApp messages and calls directly, without asking each time", waState.waAutoSend) { v ->
            c.settings.update { it.copy(waAutoSend = v) }
        }
        Text(
            "Automatic sending, calling and starting songs needs JARVIS switched on in Android Accessibility settings: " +
                "${if (a11y) "ON" else "OFF"}. It only presses WhatsApp's own Send or Call button, only for about " +
                "20 seconds after you ask (songs: 30), and reads nothing. (Reopen this tab to refresh the status.)",
            color = J.Text, style = MaterialTheme.typography.bodySmall
        )
        OutlinedButton(onClick = {
            ctx.startActivity(
                android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("Open Accessibility settings") }
        Text(
            "Open apps from the background: ${if (overlay) "allowed" else "not allowed"}. Android stops an app from " +
                "opening other apps unless it is on screen. Allow this once so \"Hey Jarvis, open YouTube\" works " +
                "while JARVIS is in the background. (Reopen this tab to refresh the status.)",
            color = J.Text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)
        )
        OutlinedButton(onClick = {
            ctx.startActivity(
                android.content.Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + ctx.packageName)
                )
            )
        }) { Text("Allow opening apps from the background") }
        Text(
            "WhatsApp calls start straight away after you confirm. WhatsApp messages open the chat with your text " +
                "ready; you press send. Closing an app sends it home and stops its background processes.",
            color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)
        )
    }
}
