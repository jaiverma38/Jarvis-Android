package com.jarvis.assistant.wake

/**
 * Streaming "Hey Jarvis" detector logic, following the openWakeWord design:
 *
 *   80 ms audio chunk (1280 samples, 16 kHz)
 *     -> melspectrogram of the latest 1760 samples (8 new frames x 32 bins)
 *     -> speech embedding of the latest 76 mel frames (96 numbers)
 *     -> wake-word classifier over the latest 16 embeddings (score 0..1)
 *
 * The three model steps are injected as functions so this logic is pure Kotlin and unit-testable.
 * Audio lives only in a small in-memory buffer that is overwritten continuously. Nothing is stored.
 */
class WakeWordPipeline(
    private val mel: (FloatArray) -> FloatArray,
    private val embed: (FloatArray) -> FloatArray,
    private val classify: (FloatArray) -> Float,
    /**
     * Battery saver: while the microphone hears only near-silence, the heavy embedding and classifier steps are
     * skipped (the last embedding is repeated, which is what silence looks like) and the score is 0. They run
     * again as soon as the sound rises above [quietRms], and for [HANG_CHUNKS] chunks afterwards.
     */
    private val energyGate: Boolean = false,
    private val quietRms: Float = DEFAULT_QUIET_RMS
) {
    private var hang = 0
    private var lastEmbedding: FloatArray? = null
    private val raw = FloatArray(CHUNK + CONTEXT)
    private val melFrames = ArrayDeque<FloatArray>()
    private val embeddings = ArrayDeque<FloatArray>()
    private var chunks = 0

    init {
        reset()
    }

    fun reset() {
        raw.fill(0f)
        melFrames.clear()
        embeddings.clear()
        repeat(MEL_WINDOW) { melFrames.addLast(FloatArray(MEL_BINS) { 1f }) }
        repeat(EMB_FRAMES) { embeddings.addLast(FloatArray(EMB_SIZE)) }
        chunks = 0
        hang = 0
        lastEmbedding = null
    }

    private fun rms(chunk: ShortArray): Float {
        var sum = 0.0
        for (v in chunk) sum += v.toDouble() * v.toDouble()
        return Math.sqrt(sum / chunk.size).toFloat()
    }

    /** Feed exactly [CHUNK] samples. Returns the wake score, or 0 while warming up. */
    fun process(chunk: ShortArray): Float {
        require(chunk.size == CHUNK) { "Expected $CHUNK samples" }
        System.arraycopy(raw, CHUNK, raw, 0, CONTEXT)
        for (i in 0 until CHUNK) raw[CONTEXT + i] = chunk[i].toFloat()

        val melOut = mel(raw.copyOf())
        require(melOut.size % MEL_BINS == 0) { "Unexpected melspectrogram size ${melOut.size}" }
        for (f in 0 until melOut.size / MEL_BINS) {
            melFrames.addLast(melOut.copyOfRange(f * MEL_BINS, (f + 1) * MEL_BINS))
        }
        while (melFrames.size > MEL_KEEP) melFrames.removeFirst()

        val window = FloatArray(MEL_WINDOW * MEL_BINS)
        var row = 0
        for (f in melFrames.drop(melFrames.size - MEL_WINDOW)) {
            System.arraycopy(f, 0, window, row * MEL_BINS, MEL_BINS)
            row++
        }
        if (energyGate) {
            if (rms(chunk) >= quietRms) hang = HANG_CHUNKS else if (hang > 0) hang--
        }
        val repeat = lastEmbedding
        val skipHeavy = energyGate && hang == 0 && chunks >= WARMUP_CHUNKS && repeat != null
        val emb = if (skipHeavy) repeat!!.copyOf() else embed(window)
        require(emb.size == EMB_SIZE) { "Unexpected embedding size ${emb.size}" }
        lastEmbedding = emb
        embeddings.addLast(emb)
        while (embeddings.size > EMB_FRAMES) embeddings.removeFirst()

        chunks++
        if (chunks < WARMUP_CHUNKS || skipHeavy) return 0f

        val flat = FloatArray(EMB_FRAMES * EMB_SIZE)
        var i = 0
        for (e in embeddings) {
            System.arraycopy(e, 0, flat, i * EMB_SIZE, EMB_SIZE)
            i++
        }
        return classify(flat)
    }

    companion object {
        const val SAMPLE_RATE = 16_000
        const val CHUNK = 1280
        const val CONTEXT = 480
        const val MEL_BINS = 32
        const val MEL_WINDOW = 76
        const val MEL_KEEP = 120
        const val EMB_SIZE = 96
        const val EMB_FRAMES = 16
        const val WARMUP_CHUNKS = 20
        const val HANG_CHUNKS = 25
        const val DEFAULT_QUIET_RMS = 110f
    }
}
