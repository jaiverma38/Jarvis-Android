package com.jarvis.assistant.wake

/**
 * Streaming "Hey Jarvis" detector logic, following the openWakeWord design:
 *
 *   80 ms audio chunk (1280 samples, 16 kHz)
 *     -> melspectrogram of the latest 1760 samples (8 new frames x 32 bins)
 *     -> speech embedding of the latest 76 mel frames (96 numbers)
 *     -> wake-word classifier over the latest 16 embeddings (score 0..1)
 *
 * The three model steps are injected as functions so this logic is pure Kotlin and unit-testable.
 * Audio lives only in a small in-memory buffer that is overwritten continuously. Nothing is stored.
 */
class WakeWordPipeline(
    private val mel: (FloatArray) -> FloatArray,
    private val embed: (FloatArray) -> FloatArray,
    private val classify: (FloatArray) -> Float
) {
    private val raw = FloatArray(CHUNK + CONTEXT)
    private val melFrames = ArrayDeque<FloatArray>()
    private val embeddings = ArrayDeque<FloatArray>()
    private var chunks = 0

    init {
        reset()
    }

    fun reset() {
        raw.fill(0f)
        melFrames.clear()
        embeddings.clear()
        repeat(MEL_WINDOW) { melFrames.addLast(FloatArray(MEL_BINS) { 1f }) }
        repeat(EMB_FRAMES) { embeddings.addLast(FloatArray(EMB_SIZE)) }
        chunks = 0
    }

    /** Feed exactly [CHUNK] samples. Returns the wake score, or 0 while warming up. */
    fun process(chunk: ShortArray): Float {
        require(chunk.size == CHUNK) { "Expected $CHUNK samples" }
        System.arraycopy(raw, CHUNK, raw, 0, CONTEXT)
        for (i in 0 until CHUNK) raw[CONTEXT + i] = chunk[i].toFloat()

        val melOut = mel(raw.copyOf())
        require(melOut.size % MEL_BINS == 0) { "Unexpected melspectrogram size ${melOut.size}" }
        for (f in 0 until melOut.size / MEL_BINS) {
            melFrames.addLast(melOut.copyOfRange(f * MEL_BINS, (f + 1) * MEL_BINS))
        }
        while (melFrames.size > MEL_KEEP) melFrames.removeFirst()

        val window = FloatArray(MEL_WINDOW * MEL_BINS)
        var row = 0
        for (f in melFrames.drop(melFrames.size - MEL_WINDOW)) {
            System.arraycopy(f, 0, window, row * MEL_BINS, MEL_BINS)
            row++
        }
        val emb = embed(window)
        require(emb.size == EMB_SIZE) { "Unexpected embedding size ${emb.size}" }
        embeddings.addLast(emb)
        while (embeddings.size > EMB_FRAMES) embeddings.removeFirst()

        chunks++
        if (chunks < WARMUP_CHUNKS) return 0f

        val flat = FloatArray(EMB_FRAMES * EMB_SIZE)
        var i = 0
        for (e in embeddings) {
            System.arraycopy(e, 0, flat, i * EMB_SIZE, EMB_SIZE)
            i++
        }
        return classify(flat)
    }

    companion object {
        const val SAMPLE_RATE = 16_000
        const val CHUNK = 1280
        const val CONTEXT = 480
        const val MEL_BINS = 32
        const val MEL_WINDOW = 76
        const val MEL_KEEP = 120
        const val EMB_SIZE = 96
        const val EMB_FRAMES = 16
        const val WARMUP_CHUNKS = 20
    }
}
