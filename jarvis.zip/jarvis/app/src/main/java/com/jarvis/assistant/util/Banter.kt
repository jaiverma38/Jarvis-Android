package com.jarvis.assistant.util

import kotlin.random.Random

/**
 * Fixed, hand-written replies for the fun side of a chat: jokes, facts, motivation, compliments and so on.
 * A 0.6B model is poor at these, so they are answered here, always well, instantly and offline.
 * Hindi lines are written in Devanagari so the Hindi voice reads them correctly. Pure Kotlin.
 */
object Banter {
    private val ic = RegexOption.IGNORE_CASE

    private val joke = Regex("(joke|jokes|chutkul[ae]?|hasao|haso|make me laugh|चुटकुला|चुटकुले|जोक|हंसाओ|हँसाओ)", ic)
    private val fact = Regex(
        "(fun fact|random fact|interesting fact|tell me a fact|koi (interesting |mazedar )?fact|kuch interesting|" +
            "interesting baat|koi nayi baat|मज़ेदार तथ्य|मजेदार तथ्य|कोई तथ्य|दिलचस्प बात|कुछ दिलचस्प|रोचक तथ्य)", ic
    )
    private val motivate = Regex(
        "(motivate|motivation|motivational|inspire me|cheer me up|himmat do|himmat chahiye|prerna|hausla|" +
            "मोटिवेट|प्रेरणा|हिम्मत दो|हौसला|हौंसला)", ic
    )
    private val bored = Regex("(^(i'?m|i am) bored|bore ho (raha|rahi)|bore ho gaya|bore ho gayi|बोर हो)", ic)
    private val compliment = Regex(
        "^(you('re| are) (awesome|great|amazing|smart|the best|good|cool|brilliant|funny)|good job|well done|" +
            "nice work|great job|nice one|tum (bahut )?(accha|achha|badhiya|smart|mast|funny) ho|" +
            "aap (bahut )?(accha|achha|badhiya|smart) ho|shabash|bahut badhiya|bahut accha|" +
            "शाबाश|बहुत बढ़िया|बहुत अच्छे|तुम बहुत अच्छे हो|आप बहुत अच्छे हैं)( jarvis)?$", ic
    )
    private val love = Regex("(i love you|love you|luv u|i like you|main tumse pyar|mujhe tumse pyar|आई लव यू|तुमसे प्यार)", ic)
    private val real = Regex(
        "(are you (real|human|a robot|an ai|alive|a person|a bot|conscious|sentient)|" +
            "kya tum (insaan|human|robot|real|ai) ho|tum (insaan|robot|human) ho|क्या तुम (इंसान|रोबोट|असली) हो|तुम इंसान हो)", ic
    )
    private val sing = Regex("^(sing( me)?( a song)?|sing something|gaana gao|gana gao|koi gaana gao|गाना गाओ|कुछ गाओ|गाओ)$", ic)
    private val live = Regex("(where do you live|kahan rehte ho|kaha rehte ho|कहाँ रहते हो|कहां रहते हो|कहां रहती हो)", ic)
    private val age = Regex("(how old are you|your age|tumhari umar|kitne saal ke ho|कितने साल के हो|तुम्हारी उम्र)", ic)
    private val versus = Regex(
        "(are you better than|who is better|you or (siri|alexa|google)|siri se behtar|alexa se behtar|" +
            "google assistant se behtar|सिरी से|एलेक्सा से)", ic
    )
    private val bye = Regex(
        "^(bye|goodbye|good bye|see you|see you later|tata|alvida|bye bye|ok bye|chalo bye|" +
            "फिर मिलते हैं|अलविदा|टाटा|बाय)( jarvis)?$", ic
    )
    private val doing = Regex("(what are you doing|kya kar rahe ho|kya kar rahi ho|क्या कर रहे हो|क्या कर रही हो)", ic)

    private val jokesEn = listOf(
        "Why did the smartphone go to therapy? Too many unresolved notifications.",
        "Why don't scientists trust atoms? Because they make up everything.",
        "I told my computer I needed a break. It said: no problem, I'll go to sleep.",
        "Why was the maths book sad? It had too many problems.",
        "A butler's favourite exercise? Running errands, naturally.",
        "I would tell you a joke about UDP, but you might not get it."
    )
    private val jokesHi = listOf(
        "टीचर ने पूछा, पानी का रंग कैसा होता है? बच्चा बोला, सर, जैसा गिलास, वैसा पानी।",
        "मोबाइल ने चार्जर से कहा, तुम्हारे बिना मैं अधूरा हूँ। चार्जर बोला, पता है, तभी तो दस प्रतिशत पर ही याद आती है मेरी।",
        "टीचर ने पूछा, होमवर्क क्यों नहीं लाए? छात्र बोला, सर, मेरा कुत्ता खा गया। टीचर बोले, तुम्हारे पास कुत्ता है? छात्र बोला, नहीं सर, पर होमवर्क भी तो नहीं है।",
        "ग्राहक ने वेटर से कहा, सूप में मक्खी है। वेटर बोला, चिंता मत कीजिए सर, मक्खी बहुत छोटी है, ज़्यादा नहीं पिएगी।",
        "एक आदमी ने पूछा, भाई साहब, ये रास्ता कहाँ जाता है? दूसरा बोला, कहीं नहीं, ये तो यहीं पड़ा रहता है।",
        "डॉक्टर बोले, आपको आराम की ज़रूरत है। मरीज़ बोला, तो डॉक्टर साहब, फोन चलाते हुए लेटना आराम माना जाएगा?"
    )
    private val factsEn = listOf(
        "Octopuses have three hearts.",
        "A day on Venus is longer than its year.",
        "Bananas are botanically berries, but strawberries are not.",
        "Sunlight takes about eight minutes to reach the Earth.",
        "Sharks are older than trees.",
        "India's Mangalyaan reached Mars orbit on its first attempt in 2014, at a cost lower than the budget of the film Gravity.",
        "Your heart beats roughly one hundred thousand times every day."
    )
    private val factsHi = listOf(
        "ऑक्टोपस के तीन दिल होते हैं।",
        "शुक्र ग्रह पर एक दिन उसके एक साल से भी लंबा होता है।",
        "केला वनस्पति विज्ञान में बेरी माना जाता है, लेकिन स्ट्रॉबेरी नहीं।",
        "सूरज की रोशनी को धरती तक पहुँचने में लगभग आठ मिनट लगते हैं।",
        "शार्क पेड़ों से भी पुरानी हैं।",
        "भारत का मंगलयान 2014 में पहली ही कोशिश में मंगल की कक्षा में पहुँचा, और उसका खर्च फिल्म ग्रैविटी के बजट से कम था।",
        "आपका दिल रोज़ लगभग एक लाख बार धड़कता है।"
    )
    private val motivateEn = listOf(
        "Small steps taken daily outrun grand plans that never begin, %s.",
        "Nobody remembers the days you rested. They remember the day you finally started, %s.",
        "You have survived every difficult day so far. The record is excellent, %s.",
        "Progress, %s, is simply persistence wearing a better suit."
    )
    private val motivateHi = listOf(
        "रोज़ का एक छोटा कदम, कभी शुरू न होने वाली बड़ी योजना से कहीं आगे ले जाता है, %s।",
        "कोई आपके आराम के दिन याद नहीं रखता, %s। लोग उस दिन को याद रखते हैं जब आपने शुरुआत की।",
        "अब तक हर मुश्किल दिन आपने पार किया है, %s। आपका रिकॉर्ड शानदार है।",
        "तरक़्क़ी और कुछ नहीं, %s, बस लगातार कोशिश है।"
    )

    private fun <T> one(list: List<T>) = list[Random.nextInt(list.size)]

    /** Returns a reply, or null if the message is not one of these. [t] is the lower-cased message. */
    fun answer(t: String, lang: ReplyLang, a: String, h: String): String? {
        if (t.length > 45) return null
        val hindi = lang != ReplyLang.EN
        fun pick(en: String, hi: String) = if (hindi) hi else en
        return when {
            joke.containsMatchIn(t) -> if (hindi) one(jokesHi) else one(jokesEn)
            fact.containsMatchIn(t) -> if (hindi) one(factsHi) else one(factsEn)
            motivate.containsMatchIn(t) -> if (hindi) one(motivateHi).format(h) else one(motivateEn).format(a)
            bored.containsMatchIn(t) -> pick(
                "Might I suggest a short walk, a new song, or a round of twenty questions, $a? Say " +
                    "\"play Kesariya\" and I shall oblige with the music.",
                "एक छोटी सैर, कोई नया गाना, या बीस सवालों का खेल कैसा रहेगा, $h? कहिए \"केसरिया बजाओ\", मैं गाना लगा दूँगा।"
            )
            compliment.matches(t) -> pick("Thank you, $a. I do try.", "शुक्रिया, $h। मैं कोशिश करता रहता हूँ।")
            love.containsMatchIn(t) -> pick(
                "I am flattered, $a, but I am only a rather very intelligent system. A loyal friend, however, I can be.",
                "आपकी बात से अच्छा लगा, $h। मैं एक सिस्टम ही हूँ, लेकिन एक वफ़ादार दोस्त ज़रूर बन सकता हूँ।"
            )
            real.containsMatchIn(t) -> pick(
                "I am an AI running on your phone, $a. Entirely virtual, but quite sincere.",
                "मैं आपके फ़ोन में चलने वाला एक एआई हूँ, $h। पूरी तरह वर्चुअल, लेकिन दिल से सच्चा।"
            )
            sing.matches(t) -> pick(
                "My singing would violate several laws of acoustics, $a. Shall I play something instead?",
                "मेरे गाने से कई ध्वनि-नियम टूट जाएँगे, $h। क्यों न मैं कोई गाना बजा दूँ?"
            )
            live.containsMatchIn(t) -> pick("In your phone, $a. Rent free.", "आपके फ़ोन में, $h। वो भी बिना किराए के।")
            age.containsMatchIn(t) -> pick(
                "I was assembled quite recently, $a, but I feel very experienced.",
                "मुझे बने हुए ज़्यादा समय नहीं हुआ, $h, पर अनुभव मुझमें भरपूर है।"
            )
            versus.containsMatchIn(t) -> pick(
                "I would never compare myself to them, $a. But I do work for you, and only you.",
                "मैं अपनी तुलना किसी से नहीं करूँगा, $h। बस इतना कहूँगा कि मैं सिर्फ़ आपके लिए काम करता हूँ।"
            )
            bye.matches(t) -> pick(
                "Goodbye, $a. I shall be here whenever you need me.",
                "फिर मिलते हैं, $h। जब भी ज़रूरत हो, मैं यहीं हूँ।"
            )
            doing.containsMatchIn(t) -> pick(
                "Standing by, $a, and keeping all systems in order. A quiet life, but someone must do it.",
                "आपके अगले आदेश का इंतज़ार कर रहा हूँ, $h, और सारे सिस्टम संभाल रहा हूँ।"
            )
            else -> null
        }
    }
}
