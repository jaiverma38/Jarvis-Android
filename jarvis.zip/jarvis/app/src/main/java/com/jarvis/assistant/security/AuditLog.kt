package com.jarvis.assistant.security

import com.jarvis.assistant.data.AuditDao
import com.jarvis.assistant.data.AuditEntity

/**
 * Records which phone actions ran and what happened. Entries deliberately contain no
 * message text, no phone numbers (only the last two digits) and no notification content.
 */
class AuditLog(private val dao: AuditDao) {
    suspend fun record(action: String, detail: String, outcome: String) {
        dao.insert(
            AuditEntity(
                time = System.currentTimeMillis(),
                action = action.take(40),
                detail = detail.take(120),
                outcome = outcome.take(120)
            )
        )
    }
}
