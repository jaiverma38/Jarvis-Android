package com.jarvis.assistant.security

import android.content.Context

object SecretNames {
    const val GEMINI = "gemini_api_key"
    const val OPENAI_COMPAT = "openai_compat_api_key"
}

/**
 * Stores user-entered API keys encrypted with the Android Keystore.
 * Keys are never shown again after saving, never logged and never sent anywhere
 * except to the provider the user selected.
 *
 * Honest limit: an API key that is bundled inside an APK can always be extracted,
 * so this app has no built-in key. The user enters their own key here.
 */
class SecureKeyStore(context: Context, private val crypto: KeystoreCrypto) {
    private val prefs = context.getSharedPreferences("secure_keys", Context.MODE_PRIVATE)

    fun put(name: String, value: String) {
        prefs.edit().putString(name, crypto.encrypt(value.trim())).apply()
    }

    fun get(name: String): String? =
        prefs.getString(name, null)?.let { crypto.decryptOrNull(it) }?.takeIf { it.isNotBlank() }

    fun has(name: String): Boolean = get(name) != null

    fun remove(name: String) {
        prefs.edit().remove(name).apply()
    }

    fun removeAll() {
        prefs.edit().clear().apply()
    }
}
