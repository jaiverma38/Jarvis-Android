package com.jarvis.assistant.wake

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.container
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service that keeps the "Hey Jarvis" listener alive while the app is in the background.
 * It shows a permanent notification (Android also shows its green microphone indicator), and has a Stop button.
 * Android 12 only allows this service to START while the app is visible, so after a reboot or if the system
 * kills it, open JARVIS once to start it again.
 */
class WakeService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val c = container()
        if (intent?.action == ACTION_STOP) {
            c.settings.update { it.copy(wakeEnabled = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                0
            }
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification("Starting…"), type)
        } catch (e: Exception) {
            c.settings.update { it.copy(wakeEnabled = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        c.wake.enable()
        scope.launch {
            c.wake.status.collect { st ->
                when (st.state) {
                    WakeState.ERROR -> {
                        // Never keep claiming to listen when we are not.
                        c.settings.update { it.copy(wakeEnabled = false) }
                        stopSelf()
                    }
                    else -> NotificationManagerCompat.from(this@WakeService).let { nm ->
                        runCatching { nm.notify(NOTIFICATION_ID, notification(text(st))) }
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun text(st: WakeStatus) = when (st.state) {
        WakeState.LISTENING -> "Listening for \"Hey Jarvis\". Audio is processed on this phone and not saved."
        WakeState.PAUSED -> "Handling a voice command…"
        WakeState.STARTING -> "Starting…"
        else -> "Wake word is off."
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, WakeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, JarvisApp.CHANNEL_WAKE)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle("JARVIS wake word is ON")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .addAction(0, "Turn off", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    override fun onDestroy() {
        container().wake.disable()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.jarvis.assistant.action.STOP_WAKE"
        const val NOTIFICATION_ID = 1002
    }
}
