package com.jarvis.assistant.wake

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.data.WakeSensitivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class WakeState { OFF, STARTING, LISTENING, PAUSED, ERROR }

data class WakeStatus(val state: WakeState, val detail: String = "")

/**
 * Local "Hey Jarvis" listening, similar in idea to Google's hotword detection but running on the CPU
 * (third-party apps cannot use the phone's low-power DSP).
 *
 * Privacy design: audio is read in 80 ms pieces into a small in-memory buffer, turned into numbers by a
 * tiny on-device model, and immediately overwritten. Nothing is written to disk, logged or sent anywhere.
 * When the wake phrase is heard, this class RELEASES the microphone and hands over to the command listener.
 *
 * Android 12 note: the microphone may only be used in the background by a foreground service that was
 * started while the app was visible. [WakeService] is that service.
 */
class WakeWordController(private val ctx: Context, private val settings: SettingsStore) {

    private val _status = MutableStateFlow(WakeStatus(WakeState.OFF))
    val status: StateFlow<WakeStatus> = _status.asStateFlow()

    /** Called on the main thread right after the wake phrase is detected. The microphone is already released. */
    var onWake: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var isWanted = false
        private set

    @Volatile
    private var pausedForCommand = false

    @Volatile
    private var running = false

    private var thread: Thread? = null
    private var models: OnnxFeatureModels? = null

    private fun hasMic() =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Called by [WakeService] once it is a foreground service. */
    fun enable() {
        isWanted = true
        pausedForCommand = false
        startCapture()
    }

    fun disable() {
        isWanted = false
        stopCapture()
        models?.close()
        models = null
        if (_status.value.state != WakeState.ERROR) _status.value = WakeStatus(WakeState.OFF)
    }

    /** Releases the microphone so the command listener (or the orb button) can use it. */
    fun pauseForCommand() {
        if (!isWanted) return
        pausedForCommand = true
        stopCapture()
        _status.value = WakeStatus(WakeState.PAUSED, "Handling a command")
    }

    /** Starts listening for the wake phrase again, if the user has it switched on. */
    fun resume() {
        pausedForCommand = false
        if (isWanted) startCapture()
    }

    @Synchronized
    private fun startCapture() {
        if (running || pausedForCommand) return
        thread?.let { if (it.isAlive && it !== Thread.currentThread()) it.join(1500) }
        if (!hasMic()) {
            fail("Microphone permission is missing.")
            return
        }
        running = true
        _status.value = WakeStatus(WakeState.STARTING)
        val t = Thread({ captureLoop() }, "wake-word")
        thread = t
        t.start()
    }

    @Synchronized
    private fun stopCapture() {
        running = false
        val t = thread
        thread = null
        if (t != null && t !== Thread.currentThread()) t.join(1500)
    }

    private fun threshold(): Float = when (settings.current.wakeSensitivity) {
        WakeSensitivity.LOW -> 0.70f
        WakeSensitivity.MEDIUM -> 0.50f
        WakeSensitivity.HIGH -> 0.35f
    }

    private fun captureLoop() {
        var rec: AudioRecord? = null
        var detected = false
        try {
            val m = models ?: OnnxFeatureModels.load(ctx).also { models = it }
            val pipeline = WakeWordPipeline(m::mel, m::embed, m::classify)

            val minBuf = AudioRecord.getMinBufferSize(
                WakeWordPipeline.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val bufBytes = maxOf(minBuf, WakeWordPipeline.CHUNK * 2 * 4)
            @Suppress("MissingPermission")
            val r = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                WakeWordPipeline.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufBytes
            )
            rec = r
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("The microphone could not be opened. Another app may be using it.")
            }
            r.startRecording()
            if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                throw IllegalStateException("The microphone is busy (a call or another app is using it).")
            }
            _status.value = WakeStatus(WakeState.LISTENING)

            val chunk = ShortArray(WakeWordPipeline.CHUNK)
            var filled = 0
            var lastHit = 0L
            while (running) {
                val n = r.read(chunk, filled, chunk.size - filled)
                if (n < 0) throw IllegalStateException("Microphone read error ($n).")
                filled += n
                if (filled < chunk.size) continue
                filled = 0
                val score = pipeline.process(chunk)
                if (score >= threshold()) {
                    val now = System.currentTimeMillis()
                    if (now - lastHit > 2000) {
                        lastHit = now
                        detected = true
                        break
                    }
                }
            }
        } catch (t: Throwable) {
            running = false
            fail(t.message?.take(160) ?: t.javaClass.simpleName)
        } finally {
            rec?.let {
                runCatching { it.stop() }
                it.release()
            }
            if (detected) {
                running = false
                pausedForCommand = true
                _status.value = WakeStatus(WakeState.PAUSED, "Heard \"Hey Jarvis\"")
                main.post { onWake?.invoke() }
            }
        }
    }

    private fun fail(message: String) {
        _status.value = WakeStatus(WakeState.ERROR, message)
    }
}
