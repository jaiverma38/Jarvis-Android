package com.jarvis.assistant.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.MainViewModel
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(vm: MainViewModel, c: AppContainer, onOpened: () -> Unit) {
    val list by remember { c.repo.conversations() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Conversations", color = J.Cyan, style = MaterialTheme.typography.titleLarge)
            Button(onClick = { vm.newChat(); onOpened() }) { Text("New chat") }
        }
        if (list.isEmpty()) {
            Text("No saved conversations yet. They are stored encrypted on this phone only.", color = J.Dim)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { item ->
                HoloCard(Modifier.clickable { vm.openConversation(item); onOpened() }) {
                    Text(item.title, color = J.Text, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                    Text(df.format(Date(item.updatedAt)), color = J.Dim, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { vm.openConversation(item); onOpened() }) { Text("Open") }
                        TextButton(onClick = { vm.deleteConversation(item) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}
