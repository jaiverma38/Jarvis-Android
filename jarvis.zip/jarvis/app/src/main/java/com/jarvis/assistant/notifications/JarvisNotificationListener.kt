package com.jarvis.assistant.notifications

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.jarvis.assistant.JarvisApp

data class SeenNotification(val app: String, val title: String, val text: String, val time: Long)

/**
 * Opt-in notification reader. It only collects anything when BOTH the system "Notification access"
 * permission is granted AND "Let JARVIS read notifications" is on in JARVIS settings.
 * Content is kept in memory only (last 20), never written to disk, never logged, never sent anywhere.
 */
class JarvisNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        clear()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!enabled()) return
        remember(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        synchronized(buffer) { buffer.removeAll { it.time == sbn.postTime } }
    }

    private fun enabled(): Boolean =
        (application as? JarvisApp)?.container?.settings?.current?.notificationReading == true

    private fun remember(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val label = appLabel(sbn.packageName)
        synchronized(buffer) {
            buffer.add(SeenNotification(label, title.take(80), text.take(160), sbn.postTime))
            while (buffer.size > MAX_ITEMS) buffer.removeAt(0)
        }
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        pkg
    }

    companion object {
        private const val MAX_ITEMS = 20
        private val buffer = ArrayList<SeenNotification>()

        @Volatile
        var instance: JarvisNotificationListener? = null
            private set

        /** Most recent first. */
        fun snapshot(): List<SeenNotification> =
            synchronized(buffer) { buffer.toList().asReversed() }

        fun clear() = synchronized(buffer) { buffer.clear() }
    }
}
