package com.jarvis.assistant.util

/**
 * The Hindi speech recogniser writes app names and a few command words in Devanagari. The command parser's
 * rules for apps, music, closing apps and WhatsApp are written in Roman letters, so this converts those words
 * (word by word) before parsing. The text shown on screen is not changed. Best effort.
 */
object DevanagariCommands {
    private val words = mapOf(
        "यूट्यूब" to "youtube", "यूटयूब" to "youtube", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "वॉट्सएप" to "whatsapp", "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook", "गूगल" to "google",
        "क्रोम" to "chrome", "कैमरा" to "camera", "गैलरी" to "gallery", "कैलकुलेटर" to "calculator",
        "स्पॉटिफाई" to "spotify", "स्पोटिफाई" to "spotify", "टेलीग्राम" to "telegram", "मैप्स" to "maps",
        "जियोसावन" to "jiosaavn", "सावन" to "saavn", "गाना" to "gaana", "गाने" to "gaane",
        "बजाओ" to "bajao", "बजा" to "baja", "चलाओ" to "chalao", "लगाओ" to "lagao", "सुनाओ" to "sunao",
        "अगला" to "next", "पिछला" to "previous", "रोको" to "roko", "पॉज" to "pause", "प्ले" to "play",
        "बंद" to "band", "करो" to "karo", "कर" to "kar", "दो" to "do", "खोलो" to "kholo", "खोल" to "khol",
        "कॉल" to "call", "फोन" to "phone", "फ़ोन" to "phone", "वॉइस" to "voice", "मैसेज" to "message", "संदेश" to "message", "भेजो" to "bhejo", "भेज" to "bhej",
        "को" to "ko", "से" to "se", "पर" to "par", "पे" to "pe", "में" to "mein", "की" to "ki", "कि" to "ki",
        "वीडियो" to "video", "म्यूजिक" to "music", "म्यूज़िक" to "music"
    )

    fun normalize(text: String): String {
        if (!SpeechText.looksDevanagari(text)) return text
        return text.split(Regex("\\s+")).joinToString(" ") { words[it] ?: it }
    }
}
