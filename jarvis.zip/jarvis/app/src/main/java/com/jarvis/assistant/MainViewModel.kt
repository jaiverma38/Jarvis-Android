package com.jarvis.assistant

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.jarvis.assistant.ai.ModelSpec
import com.jarvis.assistant.data.ConversationItem
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/** Thin screen-side handle. All real work happens in [AssistantCore], which outlives the screen. */
class MainViewModel(private val c: AppContainer) : ViewModel() {
    private val core get() = c.core

    val state: StateFlow<ChatUiState> get() = core.state
    val listenAgain: SharedFlow<Unit> get() = core.listenAgain

    fun toggleVoice() = core.toggleVoice()
    fun startVoice() = core.startVoice()
    fun checkVoice() = core.checkVoice()
    fun send(raw: String, spoken: Boolean = false) = core.send(raw, spoken)
    fun confirmPending() = core.confirmPending()
    fun cancelPending() = core.cancelPending()
    fun stopGenerating() = core.stopGenerating()
    fun newChat() = core.newChat()
    fun openConversation(item: ConversationItem) = core.openConversation(item)
    fun deleteConversation(item: ConversationItem) = core.deleteConversation(item)
    fun clearAllHistory() = core.clearAllHistory()
    fun dismissBanner() = core.dismissBanner()
    fun loadModel() = core.loadModel()
    fun unloadModel() = core.unloadModel()
    fun runBenchmark() = core.runBenchmark()
    fun deleteModel(spec: ModelSpec) = core.deleteModel(spec)

    companion object {
        fun factory(c: AppContainer) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(c) as T
        }
    }
}
