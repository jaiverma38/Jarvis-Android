package com.jarvis.assistant.util

enum class ReplyLang { EN, HINGLISH, HI }

/** Decides whether a message is English, Hinglish (Hindi in Roman letters) or Hindi (Devanagari). Pure Kotlin. */
object LangDetect {
    private val hinglish = Regex(
        "\\b(kya|kaise|kese|kaisa|kaisi|kyun|kyu|kyon|kab|kahan|kaun|kon|kitna|kitne|kitni|kaunsa|kaunsi|hai|hain|" +
            "hoon|nahi|nahin|mujhe|mera|meri|mere|tumhara|tumhari|tumhare|aapka|aapki|aapke|aap|tum|tera|teri|" +
            "karo|karna|karke|batao|bataiye|bata|dikhao|sunao|chahiye|sakte|sakta|sakti|wala|wali|aur|lekin|bhi|" +
            "abhi|aaj|kal|accha|achha|theek|bhai|yaar|samjhao|baare|matlab|kuch|bahut|zyada|thoda|jaldi|namaste|" +
            "namaskar|suprabhat|shukriya|dhanyavad|malik|haal|hal)\\b",
        RegexOption.IGNORE_CASE
    )

    fun of(text: String): ReplyLang = when {
        SpeechText.looksDevanagari(text) -> ReplyLang.HI
        hinglish.containsMatchIn(text) -> ReplyLang.HINGLISH
        else -> ReplyLang.EN
    }
}
