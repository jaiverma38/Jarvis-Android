package com.jarvis.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.jarvis.assistant.actions.ActionRouter
import com.jarvis.assistant.ai.ChatEngine
import com.jarvis.assistant.ai.GeminiProvider
import com.jarvis.assistant.ai.LiteRtProvider
import com.jarvis.assistant.ai.ModelManager
import com.jarvis.assistant.ai.NetworkMonitor
import com.jarvis.assistant.ai.OpenAiCompatProvider
import com.jarvis.assistant.data.ChatRepository
import com.jarvis.assistant.data.JarvisDatabase
import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.security.AuditLog
import com.jarvis.assistant.security.KeystoreCrypto
import com.jarvis.assistant.security.SecureKeyStore
import com.jarvis.assistant.voice.ListeningService
import com.jarvis.assistant.voice.VoiceController
import com.jarvis.assistant.wake.WakeService
import com.jarvis.assistant.wake.WakeWordController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Hand-written dependency container. No DI framework, no reflection. */
class AppContainer(val app: Application) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val settings = SettingsStore(app)
    val crypto = KeystoreCrypto()
    val secrets = SecureKeyStore(app, crypto)

    val db: JarvisDatabase = Room.databaseBuilder(app, JarvisDatabase::class.java, "jarvis.db").build()
    val repo = ChatRepository(db, crypto)
    val audit = AuditLog(db.auditDao())

    val models = ModelManager(app, appScope, settings)
    val network = NetworkMonitor(app)
    val local = LiteRtProvider(app, models, settings)
    val gemini = GeminiProvider(settings, secrets)
    val openAi = OpenAiCompatProvider(settings, secrets)
    val failover = com.jarvis.assistant.ai.FailoverProvider(settings, gemini, openAi)
    val chat = ChatEngine(settings, network, local, gemini, openAi, failover)

    val actions = ActionRouter(app, audit, settings, repo)
    val voice = VoiceController(app, settings)

    val wake = WakeWordController(app, settings)

    /** True while the app screen is visible. Used to decide whether a Confirm dialog can be shown. */
    @Volatile
    var uiVisible = false

    val core: AssistantCore by lazy { AssistantCore(this) }

    init {
        wake.onWake = { core.startFromWake() }
    }

    private val main = Handler(Looper.getMainLooper())

    fun startWakeService(): Boolean = try {
        ContextCompat.startForegroundService(app, Intent(app, WakeService::class.java))
        true
    } catch (e: Exception) {
        false
    }

    fun startApiService(): Boolean = try {
        ContextCompat.startForegroundService(app, Intent(app, com.jarvis.assistant.api.ApiService::class.java))
        true
    } catch (e: Exception) {
        false
    }

    fun stopApiService() {
        app.stopService(Intent(app, com.jarvis.assistant.api.ApiService::class.java))
    }

    /** The Jarvis key other devices use. Created on first use; can be regenerated. */
    fun jarvisApiKey(regenerate: Boolean = false): String {
        if (!regenerate) secrets.get(com.jarvis.assistant.security.SecretNames.JARVIS_API)?.let { return it }
        val chars = "abcdefghijkmnpqrstuvwxyz23456789"
        val rnd = java.security.SecureRandom()
        val key = "jv-" + (1..28).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
        secrets.put(com.jarvis.assistant.security.SecretNames.JARVIS_API, key)
        return key
    }

    fun stopWakeService() {
        app.stopService(Intent(app, WakeService::class.java))
    }

    fun startListeningService(): Boolean = try {
        ContextCompat.startForegroundService(app, Intent(app, ListeningService::class.java))
        true
    } catch (e: Exception) {
        false
    }

    fun stopListeningService() {
        app.stopService(Intent(app, ListeningService::class.java))
    }

    /**
     * Turns everything off: wake word (and its setting), microphone, speech, generation, and frees the model's RAM.
     * The wake word stays off until the user switches it on again in Settings.
     */
    fun shutdownEverything() {
        settings.update { it.copy(wakeEnabled = false) }
        stopWakeService()
        wake.disable()
        stopListeningService()
        voice.stopListening()
        voice.stopSpeaking()
        core.stopGenerating()
        core.unloadModel()
    }

    /** Called by the Stop button on the microphone notification. */
    fun stopListeningFromNotification() {
        main.post { voice.stopListening() }
    }
}

class JarvisApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_LISTENING,
                "Microphone status",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Shown only while JARVIS is listening." }
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_WAKE,
                "Wake word status",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Shown while JARVIS listens for \"Hey Jarvis\"." }
        )
        container.core // start the assistant core so voice events are handled even without a screen
        // Retention: delete old chats according to the user's setting.
        container.appScope.launch {
            runCatching { container.repo.purge(container.settings.current.retentionDays) }
        }
    }

    companion object {
        const val CHANNEL_LISTENING = "listening"
        const val CHANNEL_WAKE = "wake"
    }
}

fun Context.container(): AppContainer = (applicationContext as JarvisApp).container
