package com.jarvis.assistant.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

private enum class Confirm { HISTORY, FACTS, AUDIT, EVERYTHING }

@Composable
fun PrivacyScreen(vm: MainViewModel, c: AppContainer) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val facts by remember { c.repo.facts() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val audit by remember { c.repo.audit() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val s by c.settings.state.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM)

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        val json = c.repo.exportJson()
                        ctx.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) } != null
                    } catch (e: Exception) {
                        false
                    }
                }
                Toast.makeText(ctx, if (ok) "Exported." else "Export failed.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Privacy", color = J.Cyan, style = MaterialTheme.typography.titleLarge)

        HoloCard(title = "Where your data lives") {
            Text(
                "Chats and memories are encrypted with a key held in the Android Keystore and stored only on this " +
                    "phone. There is no cloud sync, no analytics and no tracking. Cloud backup is switched off. " +
                    "Text leaves the phone only when you use an online AI mode, and goes only to the provider you chose.",
                color = J.Text, style = MaterialTheme.typography.bodyMedium
            )
        }

        HoloCard(title = "Keep conversations for") {
            val options = listOf(0 to "Forever", 7 to "7 days", 30 to "30 days", 90 to "90 days")
            options.forEach { (days, label) ->
                RadioRow(s.retentionDays == days, label) {
                    c.settings.update { it.copy(retentionDays = days) }
                    scope.launch { c.repo.purge(days) }
                }
            }
            Text("Older conversations are deleted when the app starts and when you change this.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall)
        }

        HoloCard(title = "Things I remember about you (${facts.size})") {
            if (facts.isEmpty()) {
                Text("Nothing saved. Say \"remember that …\" and confirm to add something.", color = J.Dim)
            }
            facts.forEach { f ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(f.text, color = J.Text, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { c.repo.deleteFact(f.id) } }) { Text("Delete") }
                }
            }
            if (facts.isNotEmpty()) {
                OutlinedButton(onClick = { confirm = Confirm.FACTS }) { Text("Delete all memories") }
            }
        }

        HoloCard(title = "Your data") {
            Button(onClick = { exporter.launch("jarvis-export.json") }) { Text("Export chats and memories (JSON)") }
            Text("The file is plain text and not encrypted. Keep it somewhere safe.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { confirm = Confirm.HISTORY }, modifier = Modifier.padding(top = 8.dp)) {
                Text("Delete all conversations")
            }
            OutlinedButton(onClick = { confirm = Confirm.EVERYTHING }, modifier = Modifier.padding(top = 8.dp)) {
                Text("Delete everything (chats, memories, audit log, API keys)")
            }
        }

        HoloCard(title = "Action audit log") {
            Text(
                "A record of phone actions JARVIS ran. It never contains message text, notification content or full phone numbers.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall
            )
            if (audit.isEmpty()) Text("No actions yet.", color = J.Dim)
            audit.take(30).forEach { a ->
                Text("${df.format(Date(a.time))}  ${a.action}  ${a.detail}  → ${a.outcome}",
                    color = J.Text, style = MaterialTheme.typography.bodySmall)
            }
            if (audit.isNotEmpty()) {
                TextButton(onClick = { confirm = Confirm.AUDIT }) { Text("Clear audit log") }
            }
        }
    }

    confirm?.let { which ->
        val (title, body) = when (which) {
            Confirm.HISTORY -> "Delete all conversations?" to "This cannot be undone."
            Confirm.FACTS -> "Delete all memories?" to "This cannot be undone."
            Confirm.AUDIT -> "Clear the audit log?" to "This cannot be undone."
            Confirm.EVERYTHING -> "Delete everything?" to
                "Conversations, memories, the audit log and saved API keys will be removed. Downloaded models stay."
        }
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = {
                Button(onClick = {
                    when (which) {
                        Confirm.HISTORY -> vm.clearAllHistory()
                        Confirm.FACTS -> scope.launch { c.repo.clearFacts() }
                        Confirm.AUDIT -> scope.launch { c.repo.clearAudit() }
                        Confirm.EVERYTHING -> {
                            vm.clearAllHistory()
                            scope.launch {
                                c.repo.clearFacts()
                                c.repo.clearAudit()
                            }
                            c.secrets.removeAll()
                        }
                    }
                    confirm = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}
