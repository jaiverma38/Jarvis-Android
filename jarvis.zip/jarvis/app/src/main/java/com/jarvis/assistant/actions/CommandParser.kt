package com.jarvis.assistant.actions

import java.util.Locale

/**
 * Turns clear user commands (English, Hinglish, simple Hindi) into [Action]s using fixed rules.
 * Anything that is not clearly a command returns null and goes to the AI as normal chat.
 * Pure Kotlin so it can be unit-tested without a phone.
 */
object CommandParser {

    private val wake = Regex("^(hey |ok |okay )?(jarvis|जार्विस|जारविस)[,:]?\\s*", RegexOption.IGNORE_CASE)
    private val ic = RegexOption.IGNORE_CASE

    private val torchWord = Regex("torch|tourch|flash ?light|टॉर्च|फ्लैशलाइट|फ़्लैशलाइट", ic)
    private val onWords = Regex("\\b(on|chalu|chalao|jalao|jala do|enable)\\b|चालू|जलाओ|जला दो", ic)
    private val offWords = Regex("\\b(off|band|bujhao|bujha do|disable)\\b|बंद|बुझाओ|बुझा दो", ic)

    private val upWords = Regex(
        "\\b(up|increase|badhao|badha|zyada|jyada|louder|raise|higher|brighter)\\b|बढ़ा|ज्यादा|ज़्यादा",
        ic
    )
    private val downWords = Regex(
        "\\b(down|decrease|kam|lower|reduce|ghatao|ghata|dim|dimmer|softer)\\b|घटा|कम",
        ic
    )

    private val settingsKeywords = linkedMapOf(
        "wifi" to SettingsPanel.WIFI,
        "wi-fi" to SettingsPanel.WIFI,
        "internet" to SettingsPanel.WIFI,
        "bluetooth" to SettingsPanel.BLUETOOTH,
        "display" to SettingsPanel.DISPLAY,
        "screen" to SettingsPanel.DISPLAY,
        "sound" to SettingsPanel.SOUND,
        "battery" to SettingsPanel.BATTERY,
        "location" to SettingsPanel.LOCATION,
        "apps" to SettingsPanel.APPS,
        "storage" to SettingsPanel.STORAGE,
        "nfc" to SettingsPanel.NFC
    )

    fun parse(raw: String): Action? {
        val cleaned = raw.trim().replace(Regex("\\s+"), " ").trimEnd('.', '!', '?', '।')
        val s = wake.replace(cleaned, "").trim()
        if (s.isEmpty() || s.length > 200) return null
        val l = s.lowercase(Locale.ROOT)

        remember(s)?.let { return it }
        if (isHelp(l)) return Action.Help
        notifications(l)?.let { return it }
        sms(s)?.let { return it }
        dial(l)?.let { return it }
        if (l.length > 80) return null
        timer(l)?.let { return it }
        alarm(l)?.let { return it }
        torch(l)?.let { return it }
        volume(l)?.let { return it }
        brightness(l)?.let { return it }
        deviceInfo(l)?.let { return it }
        settingsPanel(l)?.let { return it }
        openApp(l)?.let { return it }
        return null
    }

    private fun remember(s: String): Action? {
        val m = Regex(
            "^(?:please )?(?:remember|yaad rakh(?:o|na)?|याद रखो)\\s+(?:that\\s+)?(.{3,300})$", ic
        ).find(s) ?: return null
        return Action.Remember(m.groupValues[1].trim())
    }

    private fun isHelp(l: String) = Regex(
        "^(help|what can you do|commands|kya kar sakte ho|tum kya kar sakte ho|आप क्या कर सकते हैं)$"
    ).matches(l)

    private fun notifications(l: String): Action? {
        if (l.length > 60) return null
        val en = Regex("\\b(read|check|show|tell)\\b.*\\bnotifications?\\b").containsMatchIn(l)
        val hi = Regex("notifications? (padho|sunao|dikhao)|नोटिफिकेशन (पढ़ो|सुनाओ|दिखाओ)").containsMatchIn(l)
        return if (en || hi) Action.ReadNotifications else null
    }

    private fun sms(s: String): Action? {
        val m = Regex(
            "^(?:sms|text|message)\\s+(?:to\\s+)?(\\+?\\d[\\d\\s-]{4,}?)\\s+(?:saying|that says|that|:|-)\\s*(.{1,300})$", ic
        ).find(s) ?: return null
        val number = normalizeNumber(m.groupValues[1]) ?: return null
        return Action.ComposeSms(number, m.groupValues[2].trim())
    }

    private fun dial(l: String): Action? {
        val a = Regex("^(?:call|dial|phone)\\s+(\\+?\\d[\\d\\s-]{4,})$").find(l)
        val b = Regex("^(\\+?\\d[\\d\\s-]{4,})\\s+(?:ko\\s+)?(?:call|dial)(?:\\s+karo)?$").find(l)
        val digits = (a ?: b)?.groupValues?.get(1) ?: return null
        return normalizeNumber(digits)?.let { Action.Dial(it) }
    }

    private fun normalizeNumber(raw: String): String? {
        val n = raw.filter { it.isDigit() || it == '+' }
        val digits = n.count { it.isDigit() }
        return if (digits in 5..15 && n.lastIndexOf('+') <= 0) n else null
    }

    private fun timer(l: String): Action? {
        if (!Regex("timer|टाइमर").containsMatchIn(l)) return null
        val unit = Regex(
            "(\\d{1,5})\\s*(seconds?|secs?|sec|minutes?|mins?|min|hours?|hrs?|ghante|ghanta|सेकंड|मिनट|घंटे|घंटा)"
        )
        var total = 0L
        for (m in unit.findAll(l)) {
            val n = m.groupValues[1].toLong()
            val u = m.groupValues[2]
            total += when {
                u.startsWith("sec") || u == "सेकंड" -> n
                u.startsWith("min") || u == "मिनट" -> n * 60
                else -> n * 3600
            }
        }
        return if (total in 1..86_400) Action.Timer(total.toInt()) else null
    }

    private fun alarm(l: String): Action? {
        if (!Regex("alarm|अलार्म").containsMatchIn(l)) return null
        if (Regex("\\b(cancel|delete|remove|band)\\b").containsMatchIn(l)) return null
        val t = Regex("\\b(\\d{1,2})(?:[:.](\\d{2}))?\\b").find(l) ?: return null
        var hour = t.groupValues[1].toInt()
        val minute = t.groupValues[2].ifEmpty { "0" }.toInt()
        val pm = Regex("\\b(pm|shaam|sham|evening|raat|night|dopahar|afternoon)\\b|शाम|रात|दोपहर").containsMatchIn(l)
        val am = Regex("\\b(am|subah|morning)\\b|सुबह").containsMatchIn(l)
        if (pm && hour < 12) hour += 12
        if (am && hour == 12) hour = 0
        if (hour !in 0..23 || minute !in 0..59) return null
        return Action.Alarm(hour, minute)
    }

    private fun torch(l: String): Action? {
        if (!torchWord.containsMatchIn(l)) return null
        return when {
            offWords.containsMatchIn(l) -> Action.Torch(false)
            onWords.containsMatchIn(l) -> Action.Torch(true)
            else -> Action.Torch(null)
        }
    }

    private fun percent(l: String): Int? =
        Regex("(\\d{1,3})\\s*(%|percent|prati?shat|प्रतिशत)?").find(l)
            ?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it in 0..100 }

    private fun volume(l: String): Action? {
        val hasWord = Regex("volume|awaaz|awaz|आवाज़|आवाज|वॉल्यूम").containsMatchIn(l)
        if (Regex("\\bmute\\b|चुप").containsMatchIn(l) && (hasWord || l.trim() == "mute")) {
            return Action.Volume(VolumeMode.MUTE, 0)
        }
        if (!hasWord) return null
        return when {
            upWords.containsMatchIn(l) -> Action.Volume(VolumeMode.UP, null)
            downWords.containsMatchIn(l) -> Action.Volume(VolumeMode.DOWN, null)
            else -> percent(l)?.let { Action.Volume(VolumeMode.SET, it) }
        }
    }

    private fun brightness(l: String): Action? {
        if (!Regex("brightness|ब्राइटनेस|roshni|रोशनी").containsMatchIn(l)) return null
        return when {
            upWords.containsMatchIn(l) -> Action.Brightness(BrightnessMode.UP, null)
            downWords.containsMatchIn(l) -> Action.Brightness(BrightnessMode.DOWN, null)
            else -> percent(l)?.let { Action.Brightness(BrightnessMode.SET, it) }
        }
    }

    private fun deviceInfo(l: String): Action? = when {
        Regex(
            "^(?:what is |what's |check |show |tell me )?(?:my |the |phone )?" +
                "(?:battery(?: level| status| percentage| percent| kitni hai| kitni)?|kitni battery(?: hai| bachi hai)?)" +
                "(?: status| level| left| remaining)?$"
        ).matches(l) || Regex("^बैटरी( कितनी| कितना)?( है| बची है)?$").matches(l) ->
            Action.DeviceInfo(InfoTopic.BATTERY)
        Regex("^(?:check |show )?(?:my |phone )?(?:storage|free space)(?: status| kitni hai| left)?$").matches(l) ->
            Action.DeviceInfo(InfoTopic.STORAGE)
        Regex("^(?:check |show )?(?:my |phone )?(?:ram|memory)(?: status| usage| kitni hai| left)?$").matches(l) ->
            Action.DeviceInfo(InfoTopic.MEMORY)
        Regex("^(?:check |show )?(?:my |phone )?(?:network|internet) (?:status|check)$").matches(l) ->
            Action.DeviceInfo(InfoTopic.NETWORK)
        Regex("^(?:device|phone|system) (?:info|information|details|status)$").matches(l) ->
            Action.DeviceInfo(InfoTopic.ALL)
        else -> null
    }

    private fun settingsPanel(l: String): Action? {
        val verb = Regex("^(open|show|kholo|khol do|खोलो|खोल दो)\\s+")
        val hasVerb = verb.containsMatchIn(l)
        val hasSettingsWord = Regex("settings?|सेटिंग").containsMatchIn(l)
        if (!hasVerb && !hasSettingsWord) return null
        val body = l.replace(verb, "")
            .replace(Regex("\\s*(settings?|सेटिंग्स?)\\s*"), " ")
            .replace(Regex("\\s*(kholo|khol do|open karo|खोलो|खोल दो)\\s*$"), "")
            .trim()
        if (body.isEmpty()) return if (hasSettingsWord) Action.OpenSettings(SettingsPanel.ROOT) else null
        val panel = settingsKeywords[body] ?: return null
        return if (hasSettingsWord || panel == SettingsPanel.WIFI || panel == SettingsPanel.BLUETOOTH ||
            panel == SettingsPanel.NFC
        ) {
            Action.OpenSettings(panel)
        } else {
            null
        }
    }

    private fun openApp(l: String): Action? {
        val a = Regex("^(?:open|launch|kholo|khol do|khol|खोलो)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$").find(l)
        val b = Regex("^(.+?)\\s+(?:kholo|khol do|khol de|open karo|खोलो|खोल दो|खोलिए)$").find(l)
        val target = (a ?: b)?.groupValues?.get(1)?.trim() ?: return null
        if (target.isEmpty() || target.length > 30 || target.count { it == ' ' } > 3) return null
        return Action.OpenApp(target)
    }
}
