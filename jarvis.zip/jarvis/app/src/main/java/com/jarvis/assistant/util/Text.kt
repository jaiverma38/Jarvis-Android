package com.jarvis.assistant.util

/** Removes Qwen3-style reasoning blocks from model output. Pure Kotlin, unit-tested. */
object ThinkFilter {
    private val completeBlock = Regex("<think>.*?</think>", RegexOption.DOT_MATCHES_ALL)

    fun strip(raw: String): String {
        var out = completeBlock.replace(raw, "")
        val open = out.indexOf("<think>")
        if (open >= 0) {
            // A thinking block that has not finished streaming yet: hide it.
            out = out.substring(0, open)
        }
        val close = out.lastIndexOf("</think>")
        if (close >= 0) {
            // Template pre-opened the block, so only the closing tag appears.
            out = out.substring(close + "</think>".length)
        }
        return out.trim()
    }
}

/** Prepares assistant text for text-to-speech. */
object SpeechText {
    private val markdown = Regex("[*_#`>~|]+")
    private val links = Regex("https?://\\S+")

    fun clean(text: String): String =
        links.replace(markdown.replace(text, ""), "link")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun looksDevanagari(text: String): Boolean {
        if (text.isEmpty()) return false
        val deva = text.count { it in 'ऀ'..'ॿ' }
        return deva * 5 > text.length
    }
}

/** User-facing error messages. Never includes keys, URLs with secrets or response bodies. */
object Errors {
    fun friendly(e: Throwable): String = when (e) {
        is java.net.UnknownHostException, is java.net.ConnectException ->
            "No internet connection."
        is java.net.SocketTimeoutException ->
            "The request timed out."
        is javax.net.ssl.SSLException ->
            "Secure connection failed."
        is OutOfMemoryError ->
            "Not enough memory for this model. Close other apps or choose a smaller model."
        else -> e.message?.take(200) ?: "Something went wrong."
    }
}
