package com.jarvis.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Presses WhatsApp's Send button (after "send ... on WhatsApp") or its Call confirmation button, only while a
 * task is armed by [WaAutomation] (about 20 seconds after you asked), and only inside WhatsApp windows.
 * It does not read, log or store any screen content. It is limited to the WhatsApp packages in its config.
 */
class WhatsAppAutomationService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var polling = false

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (WaAutomation.active() != null) tryAct()
    }

    fun startPolling() {
        if (polling) return
        polling = true
        handler.post(object : Runnable {
            override fun run() {
                if (WaAutomation.active() == null) {
                    polling = false
                    return
                }
                tryAct()
                handler.postDelayed(this, 500)
            }
        })
    }

    private fun tryAct() {
        val task = WaAutomation.active() ?: return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (!pkg.startsWith("com.whatsapp")) return
        val node = when (task) {
            WaAutomation.Task.SEND -> findSend(root, pkg)
            WaAutomation.Task.CALL -> findCall(root)
        } ?: return
        if (clickNode(node)) WaAutomation.disarm()
    }

    private fun findSend(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        root.findAccessibilityNodeInfosByViewId("$pkg:id/send").firstOrNull()?.let { return it }
        return findBy(root) { n ->
            val d = n.contentDescription?.toString()?.trim() ?: return@findBy false
            d.equals("Send", true) || d == "भेजें"
        }
    }

    private fun findCall(root: AccessibilityNodeInfo): AccessibilityNodeInfo? = findBy(root) { n ->
        val label = (n.text ?: n.contentDescription)?.toString()?.trim() ?: return@findBy false
        n.className?.toString()?.endsWith("Button") == true &&
            (label.equals("Call", true) || label.equals("Voice call", true) || label.equals("Video call", true) ||
                label.equals("कॉल", true))
    }

    private fun findBy(n: AccessibilityNodeInfo, test: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (test(n)) return n
        for (i in 0 until n.childCount) {
            val child = n.getChild(i) ?: continue
            findBy(child, test)?.let { return it }
        }
        return null
    }

    private fun clickNode(start: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = start
        var hops = 0
        while (n != null && hops < 4) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            hops++
        }
        return false
    }

    companion object {
        @Volatile
        var instance: WhatsAppAutomationService? = null
    }
}
