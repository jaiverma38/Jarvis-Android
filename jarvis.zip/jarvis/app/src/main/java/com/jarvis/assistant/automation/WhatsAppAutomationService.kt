package com.jarvis.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Presses WhatsApp's Send button (after "send ... on WhatsApp") or its Call confirmation button, only while a
 * task is armed by [WaAutomation] (about 20 seconds after you asked), and only inside WhatsApp windows.
 * It does not read, log or store any screen content. It is limited to the WhatsApp packages in its config.
 */
class WhatsAppAutomationService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var polling = false

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (WaAutomation.active() != null) tryAct()
    }

    fun startPolling() {
        if (polling) return
        polling = true
        handler.post(object : Runnable {
            override fun run() {
                if (WaAutomation.active() == null) {
                    polling = false
                    return
                }
                tryAct()
                handler.postDelayed(this, 500)
            }
        })
    }

    private fun tryAct() {
        val task = WaAutomation.active() ?: return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (task == WaAutomation.Task.PLAY) {
            tryPlay(root, pkg)
            return
        }
        if (task == WaAutomation.Task.SOCIAL) {
            trySocial(root, pkg)
            return
        }
        if (!pkg.startsWith("com.whatsapp")) return
        val node = when (task) {
            WaAutomation.Task.SEND -> findSend(root, pkg)
            WaAutomation.Task.CALL -> findCall(root)
            WaAutomation.Task.PLAY, WaAutomation.Task.SOCIAL -> null
        } ?: return
        if (clickNode(node)) WaAutomation.disarm()
    }

    private var lastPlayKey = ""
    private var playStable = 0

    /**
     * After JARVIS opened a music app's search results, taps the first result whose text contains the song
     * words, which starts the song. Acts only inside the music app JARVIS opened, never on the search box or
     * the top bar, and only once.
     */
    private fun tryPlay(root: AccessibilityNodeInfo, pkg: String) {
        if (pkg !in MUSIC_PACKAGES) return
        WaAutomation.playPkg?.let { if (it != pkg) return }
        val age = System.currentTimeMillis() - WaAutomation.armedAt
        if (age < 2500) return
        val tokens = WaAutomation.playTokens
        if (tokens.isEmpty()) return
        if (WaAutomation.driveSearch && !WaAutomation.typed && age >= 2500) {
            driveSearchBox(root)
            return
        }
        val rect = android.graphics.Rect()
        var full: AccessibilityNodeInfo? = null
        var partial: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo) {
            if (full != null) return
            val label = (n.text ?: n.contentDescription)?.toString()?.lowercase()
            if (!label.isNullOrBlank() && n.className?.toString()?.contains("EditText") != true) {
                n.getBoundsInScreen(rect)
                if (rect.top > 330 && rect.height() > 0) {
                    if (tokens.all { label.contains(it) }) full = n
                    else if (partial == null && label.contains(tokens.first())) partial = n
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        val node = full ?: if (age > 8000) partial else null
        if (node == null) {
            playStable = 0
            return
        }
        node.getBoundsInScreen(rect)
        val key = "${node.text}|${rect.top}"
        if (key == lastPlayKey) playStable++ else {
            lastPlayKey = key
            playStable = 0
        }
        if (playStable >= 1 && clickNode(node)) {
            WaAutomation.disarm()
            lastPlayKey = ""
            playStable = 0
        }
    }

    /** Opens the app's search box, types the song and presses the keyboard's search key. */
    private fun driveSearchBox(root: AccessibilityNodeInfo) {
        val edit = findBy(root) { it.className?.toString()?.contains("EditText") == true && it.isEnabled }
        if (edit != null) {
            val args = android.os.Bundle()
            args.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, WaAutomation.queryText
            )
            edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            if (edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                if (android.os.Build.VERSION.SDK_INT >= 30) edit.performAction(android.R.id.accessibilityActionImeEnter)
                WaAutomation.typed = true
                WaAutomation.restartClock()
            }
            return
        }
        val searchIcon = findBy(root) { n ->
            val d = (n.contentDescription ?: n.text)?.toString()?.trim()?.lowercase() ?: return@findBy false
            d == "search" || d.startsWith("search ") || d == "खोजें"
        }
        if (searchIcon != null) clickNode(searchIcon)
    }

    // ---- YouTube and Instagram: open the first result, then write a comment ----

    private var lastSocialAct = 0L

    private fun label(n: AccessibilityNodeInfo): String =
        (n.contentDescription ?: n.text)?.toString()?.trim()?.lowercase().orEmpty()

    private fun isEdit(n: AccessibilityNodeInfo) = n.className?.toString()?.contains("EditText") == true && n.isEnabled

    private fun setText(edit: AccessibilityNodeInfo, text: String): Boolean {
        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        edit.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        return edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun scrollDown(root: AccessibilityNodeInfo) {
        findBy(root) { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    /**
     * Works only inside YouTube or Instagram, only while a task armed by "search/play/comment ..." is open
     * (45 to 75 seconds), and only does what was asked: open the first result, or write the comment you
     * dictated and press Send. Screen text is matched to find buttons and is never stored or sent anywhere.
     */
    private fun trySocial(root: AccessibilityNodeInfo, pkg: String) {
        val app = WaAutomation.socialApp ?: return
        if (pkg != app.pkg) return
        val op = WaAutomation.socialOp ?: return
        val now = System.currentTimeMillis()
        val since = now - WaAutomation.stageAt
        val tokens = WaAutomation.socialTokens
        val yt = app == com.jarvis.assistant.actions.SocialApp.YOUTUBE
        val wantsComment = op == com.jarvis.assistant.actions.SocialOp.COMMENT
        if (now - lastSocialAct < 1000) return
        val rect = android.graphics.Rect()

        when (WaAutomation.stage) {
            99 -> WaAutomation.disarm()

            // Instagram: open the search tab and type the query.
            0 -> {
                if (since < 2500) return
                val edit = findBy(root) { isEdit(it) }
                if (edit != null) {
                    if (setText(edit, WaAutomation.socialQuery)) {
                        if (android.os.Build.VERSION.SDK_INT >= 30) edit.performAction(android.R.id.accessibilityActionImeEnter)
                        lastSocialAct = now
                        if (op == com.jarvis.assistant.actions.SocialOp.SEARCH) WaAutomation.disarm()
                        else WaAutomation.nextStage(1)
                    }
                    return
                }
                val search = findBy(root) { n ->
                    val d = label(n)
                    n.getBoundsInScreen(rect)
                    (d == "search and explore" || d == "search" || d.startsWith("search and")) && rect.height() > 0
                }
                if (search != null && clickNode(search)) lastSocialAct = now
            }

            // Open the first result.
            1 -> {
                if (since < 2500) return
                var full: AccessibilityNodeInfo? = null
                var any: AccessibilityNodeInfo? = null
                fun walk(n: AccessibilityNodeInfo) {
                    if (full != null) return
                    val d = label(n)
                    if (d.isNotBlank() && !isEdit(n)) {
                        n.getBoundsInScreen(rect)
                        if (rect.top > 330 && rect.height() > 120) {
                            if (yt) {
                                val video = d.contains(" views") || d.contains(" view ") || d.contains("minutes") ||
                                    d.contains("seconds") || d.contains(" ago")
                                if (video && !d.contains("subscribers") && !d.contains("sponsored")) {
                                    if (tokens.all { d.contains(it) }) full = n else if (any == null) any = n
                                }
                            } else if (tokens.isNotEmpty() && d.contains(tokens.first())) {
                                if (tokens.all { d.contains(it) }) full = n else if (any == null) any = n
                            }
                        }
                    }
                    for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
                }
                walk(root)
                val node = full ?: if (since > 6000) any else null
                if (node == null) {
                    if (since > 25_000) WaAutomation.disarm()
                    return
                }
                if (clickNode(node)) {
                    lastSocialAct = now
                    when {
                        !yt && op != com.jarvis.assistant.actions.SocialOp.SEARCH -> WaAutomation.nextStage(2)
                        wantsComment -> WaAutomation.nextStage(10)
                        else -> WaAutomation.disarm()
                    }
                }
            }

            // Instagram profile: open its first reel or post.
            2 -> {
                if (since < 2500) return
                val reel = findBy(root) { n ->
                    val d = label(n)
                    n.getBoundsInScreen(rect)
                    rect.top > 330 && (d.startsWith("reel by") || d.contains("reel by") ||
                        d.startsWith("video by") || d.startsWith("photo by") || d.startsWith("post by"))
                }
                if (reel != null && clickNode(reel)) {
                    lastSocialAct = now
                    if (wantsComment) WaAutomation.nextStage(10) else WaAutomation.disarm()
                } else if (since > 12_000) {
                    if (wantsComment) WaAutomation.nextStage(10) else WaAutomation.disarm()
                }
            }

            // Open the comment box.
            10 -> {
                if (since < 3000) return
                if (findBy(root) { isEdit(it) } != null) {
                    WaAutomation.nextStage(11)
                    return
                }
                val opener = findBy(root) { n ->
                    val d = label(n)
                    if (yt) d.startsWith("comments") && !d.contains("turned off")
                    else d == "comment" || d.startsWith("comment,") || d.startsWith("comment ")
                }
                val node = findBy(root) { label(it).startsWith("add a comment") } ?: opener
                if (node != null && clickNode(node)) {
                    lastSocialAct = now
                } else {
                    WaAutomation.stageTries++
                    if (WaAutomation.stageTries % 3 == 0) scrollDown(root)
                    if (since > 40_000) WaAutomation.disarm()
                }
            }

            // Type the comment.
            11 -> {
                val edit = findBy(root) { isEdit(it) }
                if (edit == null) {
                    if (since > 10_000) WaAutomation.nextStage(10)
                    return
                }
                if (setText(edit, WaAutomation.commentText)) {
                    lastSocialAct = now
                    WaAutomation.nextStage(12)
                }
            }

            // Press Send / Post.
            12 -> {
                if (since < 800) return
                val send = findBy(root) { n ->
                    val d = label(n)
                    n.getBoundsInScreen(rect)
                    rect.height() > 0 && (d == "send" || d == "send comment" || d == "post" || d == "post comment")
                }
                if (send != null && clickNode(send)) {
                    lastSocialAct = now
                    WaAutomation.disarm()
                } else if (since > 10_000) {
                    WaAutomation.disarm()
                }
            }
        }
    }

    private fun findSend(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        root.findAccessibilityNodeInfosByViewId("$pkg:id/send").firstOrNull()?.let { return it }
        return findBy(root) { n ->
            val d = n.contentDescription?.toString()?.trim() ?: return@findBy false
            d.equals("Send", true) || d == "भेजें"
        }
    }

    /**
     * 1) a confirmation button ("Call", "Voice call", "Video call") if WhatsApp shows one;
     * 2) otherwise the call icon in the chat's top bar (matched by its description, only near the top of the
     *    screen so old "Voice call" entries inside the chat are never tapped).
     */
    private fun findCall(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val wanted = if (WaAutomation.video) "video call" else "voice call"
        findBy(root) { n ->
            val label = (n.text ?: n.contentDescription)?.toString()?.trim() ?: return@findBy false
            n.className?.toString()?.endsWith("Button") == true &&
                (label.equals("Call", true) || label.equals(wanted, true) || label.equals("कॉल", true))
        }?.let { return it }
        val rect = android.graphics.Rect()
        return findBy(root) { n ->
            val d = n.contentDescription?.toString()?.trim() ?: return@findBy false
            if (!(d.equals(wanted, true) || (!WaAutomation.video && d.equals("Call", true)))) return@findBy false
            n.getBoundsInScreen(rect)
            rect.top in 0..420 && rect.height() > 0
        }
    }

    private fun findBy(n: AccessibilityNodeInfo, test: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (test(n)) return n
        for (i in 0 until n.childCount) {
            val child = n.getChild(i) ?: continue
            findBy(child, test)?.let { return it }
        }
        return null
    }

    private fun clickNode(start: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = start
        var hops = 0
        while (n != null && hops < 4) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            hops++
        }
        return false
    }

    companion object {
        val MUSIC_PACKAGES = setOf(
            "com.spotify.music", "com.google.android.apps.youtube.music", "com.google.android.youtube",
            "com.jio.media.jiobeats", "com.gaana", "com.bsbportal.music", "com.amazon.mp3",
            "com.apple.android.music", "com.hungama.myplay.activity", "music.ytstream.youtify"
        )

        @Volatile
        var instance: WhatsAppAutomationService? = null
    }
}
