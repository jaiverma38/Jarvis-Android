package com.jarvis.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Presses WhatsApp's Send button (after "send ... on WhatsApp") or its Call confirmation button, only while a
 * task is armed by [WaAutomation] (about 20 seconds after you asked), and only inside WhatsApp windows.
 * It does not read, log or store any screen content. It is limited to the WhatsApp packages in its config.
 */
class WhatsAppAutomationService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var polling = false

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (WaAutomation.active() != null) tryAct()
    }

    fun startPolling() {
        if (polling) return
        polling = true
        handler.post(object : Runnable {
            override fun run() {
                if (WaAutomation.active() == null) {
                    polling = false
                    return
                }
                tryAct()
                handler.postDelayed(this, 500)
            }
        })
    }

    private fun tryAct() {
        val task = WaAutomation.active() ?: return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (task == WaAutomation.Task.PLAY) {
            tryPlay(root, pkg)
            return
        }
        if (!pkg.startsWith("com.whatsapp")) return
        val node = when (task) {
            WaAutomation.Task.SEND -> findSend(root, pkg)
            WaAutomation.Task.CALL -> findCall(root)
            WaAutomation.Task.PLAY -> null
        } ?: return
        if (clickNode(node)) WaAutomation.disarm()
    }

    private var lastPlayKey = ""
    private var playStable = 0

    /**
     * After JARVIS opened a music app's search results, taps the first result whose text contains the song
     * words, which starts the song. Acts only inside the music app JARVIS opened, never on the search box or
     * the top bar, and only once.
     */
    private fun tryPlay(root: AccessibilityNodeInfo, pkg: String) {
        if (pkg !in MUSIC_PACKAGES) return
        WaAutomation.playPkg?.let { if (it != pkg) return }
        val age = System.currentTimeMillis() - WaAutomation.armedAt
        if (age < 2500) return
        val tokens = WaAutomation.playTokens
        if (tokens.isEmpty()) return
        if (WaAutomation.driveSearch && !WaAutomation.typed && age >= 2500) {
            driveSearchBox(root)
            return
        }
        val rect = android.graphics.Rect()
        var full: AccessibilityNodeInfo? = null
        var partial: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo) {
            if (full != null) return
            val label = (n.text ?: n.contentDescription)?.toString()?.lowercase()
            if (!label.isNullOrBlank() && n.className?.toString()?.contains("EditText") != true) {
                n.getBoundsInScreen(rect)
                if (rect.top > 330 && rect.height() > 0) {
                    if (tokens.all { label.contains(it) }) full = n
                    else if (partial == null && label.contains(tokens.first())) partial = n
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        val node = full ?: if (age > 8000) partial else null
        if (node == null) {
            playStable = 0
            return
        }
        node.getBoundsInScreen(rect)
        val key = "${node.text}|${rect.top}"
        if (key == lastPlayKey) playStable++ else {
            lastPlayKey = key
            playStable = 0
        }
        if (playStable >= 1 && clickNode(node)) {
            WaAutomation.disarm()
            lastPlayKey = ""
            playStable = 0
        }
    }

    /** Opens the app's search box, types the song and presses the keyboard's search key. */
    private fun driveSearchBox(root: AccessibilityNodeInfo) {
        val edit = findBy(root) { it.className?.toString()?.contains("EditText") == true && it.isEnabled }
        if (edit != null) {
            val args = android.os.Bundle()
            args.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, WaAutomation.queryText
            )
            edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            if (edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                if (android.os.Build.VERSION.SDK_INT >= 30) edit.performAction(android.R.id.accessibilityActionImeEnter)
                WaAutomation.typed = true
                WaAutomation.restartClock()
            }
            return
        }
        val searchIcon = findBy(root) { n ->
            val d = (n.contentDescription ?: n.text)?.toString()?.trim()?.lowercase() ?: return@findBy false
            d == "search" || d.startsWith("search ") || d == "खोजें"
        }
        if (searchIcon != null) clickNode(searchIcon)
    }

    private fun findSend(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        root.findAccessibilityNodeInfosByViewId("$pkg:id/send").firstOrNull()?.let { return it }
        return findBy(root) { n ->
            val d = n.contentDescription?.toString()?.trim() ?: return@findBy false
            d.equals("Send", true) || d == "भेजें"
        }
    }

    /**
     * 1) a confirmation button ("Call", "Voice call", "Video call") if WhatsApp shows one;
     * 2) otherwise the call icon in the chat's top bar (matched by its description, only near the top of the
     *    screen so old "Voice call" entries inside the chat are never tapped).
     */
    private fun findCall(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val wanted = if (WaAutomation.video) "video call" else "voice call"
        findBy(root) { n ->
            val label = (n.text ?: n.contentDescription)?.toString()?.trim() ?: return@findBy false
            n.className?.toString()?.endsWith("Button") == true &&
                (label.equals("Call", true) || label.equals(wanted, true) || label.equals("कॉल", true))
        }?.let { return it }
        val rect = android.graphics.Rect()
        return findBy(root) { n ->
            val d = n.contentDescription?.toString()?.trim() ?: return@findBy false
            if (!(d.equals(wanted, true) || (!WaAutomation.video && d.equals("Call", true)))) return@findBy false
            n.getBoundsInScreen(rect)
            rect.top in 0..420 && rect.height() > 0
        }
    }

    private fun findBy(n: AccessibilityNodeInfo, test: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (test(n)) return n
        for (i in 0 until n.childCount) {
            val child = n.getChild(i) ?: continue
            findBy(child, test)?.let { return it }
        }
        return null
    }

    private fun clickNode(start: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = start
        var hops = 0
        while (n != null && hops < 4) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            hops++
        }
        return false
    }

    companion object {
        val MUSIC_PACKAGES = setOf(
            "com.spotify.music", "com.google.android.apps.youtube.music", "com.google.android.youtube",
            "com.jio.media.jiobeats", "com.gaana", "com.bsbportal.music", "com.amazon.mp3",
            "com.apple.android.music", "com.hungama.myplay.activity", "music.ytstream.youtify"
        )

        @Volatile
        var instance: WhatsAppAutomationService? = null
    }
}
