package com.jarvis.assistant.util

/**
 * Lets the assistant decide how long an answer should be and in which language and script, then states it
 * to the model as a short instruction added to the question. Small models follow an instruction placed next
 * to the question far better than one buried in the system prompt. Pure Kotlin.
 */
object ReplyStyle {
    enum class Length { SHORT, MEDIUM, LONG }

    private val ic = RegexOption.IGNORE_CASE

    private val wantsLong = Regex(
        "(explain|describe|elaborate|in detail|detailed|essay|story|history of|how does|how do|how can|how is|" +
            "step by step|compare|difference between|pros and cons|advantages|disadvantages|tutorial|plan for|" +
            "itinerary|speech|teach me|walk me through|" +
            "samjhao|samjha do|samjhaiye|vistar|kahani|kahaani|nibandh|poori jaankari|detail mein|kaise kaam|" +
            "kaise hota|kaise banta|kyun hota|kyon hota|antar|fark|" +
            "समझाओ|समझाइए|समझा दो|विस्तार|कहानी|निबंध|कैसे काम|कैसे होता|कैसे बनता|क्यों होता|इतिहास|अंतर|फर्क)", ic
    )

    private val simpleFact = Regex(
        "^(who|what|when|where|which|how many|how much|how old|how far|how tall|is |are |was |were |do |does |can |" +
            "kaun|kon|kab|kahan|kitna|kitne|kitni|kaunsa|kaunsi|kya |" +
            "कौन|कब|कहाँ|कहां|कितना|कितने|कितनी|कौनसा|कौन सा|क्या )", ic
    )

    fun length(text: String): Length {
        val t = text.trim()
        if (wantsLong.containsMatchIn(t)) return Length.LONG
        val words = t.split(Regex("\\s+")).size
        if (words <= 5) return Length.SHORT
        if (words <= 14 && simpleFact.containsMatchIn(t)) return Length.SHORT
        return Length.MEDIUM
    }

    /** The instruction line added after the user's question. [devanagari] is the user's Hindi script setting. */
    fun wrap(text: String, lang: ReplyLang, devanagari: Boolean): String = text + "\n\n" + hint(text, lang, devanagari)

    /** Just the instruction line; [text] is the user's own words, used to judge the length. */
    fun hint(text: String, lang: ReplyLang, devanagari: Boolean): String {
        val language = when {
            lang == ReplyLang.EN -> "Reply in English."
            lang == ReplyLang.HI || devanagari ->
                "Reply in simple, natural spoken Hindi written in Devanagari script, not in Roman letters."
            else -> "Reply in Hinglish: Hindi written in Roman letters."
        }
        val size = when (length(text)) {
            Length.SHORT -> "Keep it to one or two short sentences."
            Length.MEDIUM -> "Answer in three to five sentences."
            Length.LONG -> "Give a clear, well-organised explanation of about six to ten sentences."
        }
        return "(Instructions for this answer: $language $size Use plain sentences that sound natural " +
            "when spoken aloud, no lists, no markdown. Be accurate; if unsure, say so.)"
    }
}
