package com.jarvis.assistant.ai

import kotlinx.coroutines.flow.Flow

data class ChatTurn(val isUser: Boolean, val text: String)

data class ChatRequest(
    val systemPrompt: String,
    /** Earlier turns, oldest first. Does not include [userText]. */
    val history: List<ChatTurn>,
    val userText: String,
    /** Changes whenever the conversation changes, so stateful providers can rebuild context. */
    val sessionKey: String
)

/**
 * A source of answers. The flow emits the FULL answer text so far (not deltas),
 * so the UI can simply replace what it shows.
 */
interface AiProvider {
    val id: String
    val label: String
    fun generate(request: ChatRequest): Flow<String>
}

object Prompts {
    fun system(facts: List<String>): String {
        val sb = StringBuilder()
        sb.append(
            "You are JARVIS, a calm, concise and polite personal assistant on the user's Android phone. " +
                "Reply in the same language and script the user writes in: English, Hindi in Devanagari, " +
                "or Hinglish in Roman letters. Keep answers short, one to three sentences, because replies " +
                "are often spoken aloud. Do not use markdown. " +
                "You cannot control the phone yourself in a chat answer: phone actions such as torch, timers " +
                "and opening apps are handled separately when the user gives a clear command. " +
                "Never claim you performed a phone action. If you are not sure about something, say so."
        )
        if (facts.isNotEmpty()) {
            sb.append(" Things the user asked you to remember: ")
            sb.append(facts.take(20).joinToString("; ") { it.take(200) })
            sb.append('.')
        }
        return sb.toString()
    }
}
