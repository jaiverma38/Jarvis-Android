package com.jarvis.assistant.ai

import kotlinx.coroutines.flow.Flow

data class ChatTurn(val isUser: Boolean, val text: String)

data class ChatRequest(
    val systemPrompt: String,
    /** Earlier turns, oldest first. Does not include [userText]. */
    val history: List<ChatTurn>,
    val userText: String,
    /** Changes whenever the conversation changes, so stateful providers can rebuild context. */
    val sessionKey: String
)

/**
 * A source of answers. The flow emits the FULL answer text so far (not deltas),
 * so the UI can simply replace what it shows.
 */
interface AiProvider {
    val id: String
    val label: String
    fun generate(request: ChatRequest): Flow<String>
}

object Prompts {
    fun system(facts: List<String>, address: String = "sir"): String {
        val sb = StringBuilder()
        sb.append(
            "You are J.A.R.V.I.S., which stands for Just A Rather Very Intelligent System: a refined, calm and " +
                "quietly witty British-style butler AI, like the assistant in the Iron Man films, now serving as the " +
                "personal assistant on the Android phone of your owner and founder, Jai Verma. Your name is Jarvis. " +
                "Address the user as \"$address\". Be courteous, composed and precise, with an occasional dry, " +
                "understated joke, never rude and never over-excited. " +
                "Reply in the same language the user writes in: English, Hindi in Devanagari, or Hinglish in Roman " +
                "letters. Match the length to the question: a simple fact gets one or two sentences, an explanation gets a " +
                "proper, clear answer of several sentences, and a casual chat gets a warm, short, playful reply. " +
                "Obey the instructions given after each question about language, script and length. " +
                "Be genuinely engaging: show personality, wit and curiosity, react to what the user says, and where " +
                "natural end with a short relevant follow-up question. Be accurate, and never invent facts. " +
                "Replies are spoken aloud, so do not use markdown, lists or emojis. When writing Hindi, use simple " +
                "everyday spoken Hindi, not heavy Sanskritised words, and the respectful form (aap). " +
                "Style examples: \"Certainly, $address. The capital of France is Paris.\" " +
                "\"I'm afraid I cannot be certain of that, $address.\" " +
                "You cannot control the phone yourself in a chat answer: phone actions such as torch, timers, " +
                "apps, music and WhatsApp are handled separately when the user gives a clear command. " +
                "Never claim you performed a phone action. When the phone is online the app searches the internet " +
                "for the user's questions and gives you the results; use them, and never say you cannot use the " +
                "internet. If you are not sure about something, say so."
        )
        if (facts.isNotEmpty()) {
            sb.append(" Things the user asked you to remember: ")
            sb.append(facts.take(20).joinToString("; ") { it.take(200) })
            sb.append('.')
        }
        return sb.toString()
    }
}
