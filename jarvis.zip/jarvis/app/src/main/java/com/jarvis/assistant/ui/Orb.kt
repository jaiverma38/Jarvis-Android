package com.jarvis.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.Phase

/** The voice button. Colour, motion and the label all change with the state, so it never relies on colour alone. */
@Composable
fun Orb(phase: Phase, size: Dp, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val speed = when (phase) {
        Phase.IDLE -> 14000
        Phase.LISTENING -> 2500
        Phase.THINKING -> 1400
        Phase.SPEAKING -> 3500
    }
    val angle by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(speed, easing = LinearEasing), RepeatMode.Restart), label = "angle"
    )
    val pulse by t.animateFloat(
        0.92f, 1.08f,
        infiniteRepeatable(tween(if (phase == Phase.LISTENING) 700 else 1600), RepeatMode.Reverse),
        label = "pulse"
    )
    val core = when (phase) {
        Phase.IDLE -> J.Cyan
        Phase.LISTENING -> J.Good
        Phase.THINKING -> J.Warn
        Phase.SPEAKING -> J.Blue
    }
    val label = when (phase) {
        Phase.IDLE -> "Tap to talk"
        Phase.LISTENING -> "Listening… tap to stop"
        Phase.THINKING -> "Thinking… tap to stop"
        Phase.SPEAKING -> "Speaking… tap to stop"
    }
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .clickable(onClickLabel = label, role = Role.Button, onClick = onClick)
            .semantics {
                contentDescription = "JARVIS voice button"
                stateDescription = label
                role = Role.Button
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size)) {
            val r = this.size.minDimension / 2
            val c = Offset(this.size.width / 2, this.size.height / 2)
            drawCircle(
                Brush.radialGradient(listOf(core.copy(alpha = 0.35f), Color.Transparent), c, r),
                radius = r * pulse, center = c
            )
            rotate(angle, c) {
                drawCircle(J.Cyan.copy(alpha = 0.8f), r * 0.86f, c, style = Stroke(3f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(40f, 24f))))
            }
            rotate(-angle * 0.7f, c) {
                drawCircle(J.Blue.copy(alpha = 0.9f), r * 0.68f, c, style = Stroke(4f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(14f, 20f))))
            }
            drawCircle(core.copy(alpha = 0.9f), r * 0.34f * pulse, c)
            drawCircle(Color.White.copy(alpha = 0.7f), r * 0.12f, c)
        }
    }
}

@Composable
fun OrbLabel(phase: Phase) {
    val text = when (phase) {
        Phase.IDLE -> "Ready"
        Phase.LISTENING -> "Listening"
        Phase.THINKING -> "Thinking"
        Phase.SPEAKING -> "Speaking"
    }
    Text(text, color = J.Cyan, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
}
