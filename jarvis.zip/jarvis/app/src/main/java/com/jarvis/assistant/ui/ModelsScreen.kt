package com.jarvis.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.MainViewModel
import com.jarvis.assistant.ai.DownloadState
import com.jarvis.assistant.ai.LoadState
import com.jarvis.assistant.ai.ModelSpec
import com.jarvis.assistant.ai.ModelStatus

private fun mb(bytes: Long) = "%.0f MB".format(bytes / 1_000_000.0)

@Composable
fun ModelsScreen(vm: MainViewModel, c: AppContainer) {
    val statuses by c.models.statuses.collectAsStateWithLifecycle(initialValue = emptyList())
    val settings by c.settings.state.collectAsStateWithLifecycle()
    val load by c.local.loadState.collectAsStateWithLifecycle()
    val ui by vm.state.collectAsStateWithLifecycle()
    var customUrl by remember { mutableStateOf("") }
    var customError by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf<ModelSpec?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("On-device models", color = J.Cyan, style = MaterialTheme.typography.titleLarge)

        HoloCard(title = "Storage") {
            Text(
                "Models use ${mb(c.models.usedBytes())}. Free space on the phone: ${mb(c.models.freeBytes())}.",
                color = J.Text
            )
            Text(
                "Models are stored inside JARVIS's private folder. Uninstalling the app removes them.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall
            )
        }

        statuses.forEach { st ->
            HoloCard(title = st.spec.name) {
                Text(st.spec.note, color = J.Dim, style = MaterialTheme.typography.bodySmall)
                Text(
                    "License: ${st.spec.license}" +
                        if (st.spec.contextTokens > 0) "  •  Context: ${st.spec.contextTokens} tokens" else "",
                    color = J.Dim, style = MaterialTheme.typography.bodySmall
                )
                Text(statusLine(st), color = J.Text, modifier = Modifier.padding(top = 6.dp))
                st.sha256?.let {
                    Text(
                        "SHA-256: ${it.take(16)}…  " +
                            if (st.serverVerified) "(matches the hash published by the server)"
                            else "(no server hash available to compare)",
                        color = if (st.serverVerified) J.Good else J.Warn,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                DownloadControls(st, c, vm, onDelete = { confirmDelete = st.spec })
                if (st.installedBytes != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = settings.selectedModelId == st.spec.id,
                            onClick = { c.settings.update { s -> s.copy(selectedModelId = st.spec.id) } }
                        )
                        Text("Use this model", color = J.Text)
                    }
                }
            }
        }

        HoloCard(title = "Add a model by link (advanced)") {
            Text(
                "Paste an HTTPS link to a .litertlm file. JARVIS cannot check its license, size or safety. " +
                    "Large models can crash the app on 8 GB of RAM.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = customUrl,
                onValueChange = { customUrl = it.take(400); customError = null },
                label = { Text("https://…/model.litertlm") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
            customError?.let { Text(it, color = J.Bad, style = MaterialTheme.typography.bodySmall) }
            OutlinedButton(onClick = {
                c.models.addCustom(customUrl).fold(
                    onSuccess = { customUrl = "" },
                    onFailure = { customError = it.message }
                )
            }) { Text("Add to list") }
        }

        HoloCard(title = "Run on this phone") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()) {
                Text("Try GPU backend (experimental)", color = J.Text, modifier = Modifier.weight(1f))
                Switch(
                    checked = settings.useGpu,
                    onCheckedChange = { on -> c.settings.update { s -> s.copy(useGpu = on) } }
                )
            }
            Text(
                "CPU is the safe default. GPU support on the Mali-G76 of this phone is unverified. " +
                    "If it fails, JARVIS shows an error; switch back to CPU.",
                color = J.Dim, style = MaterialTheme.typography.bodySmall
            )
            Text(loadText(load), color = if (load is LoadState.Error) J.Bad else J.Text, modifier = Modifier.padding(top = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                Button(
                    onClick = vm::loadModel,
                    enabled = c.local.isModelInstalled() && !ui.loadingModel && !ui.benchmarkRunning
                ) { Text(if (ui.loadingModel) "Loading…" else "Load") }
                OutlinedButton(onClick = vm::unloadModel, enabled = load is LoadState.Ready) { Text("Unload") }
            }
            Button(
                onClick = vm::runBenchmark,
                enabled = c.local.isModelInstalled() && !ui.benchmarkRunning && !ui.loadingModel,
                modifier = Modifier.padding(top = 8.dp)
            ) { Text(if (ui.benchmarkRunning) "Benchmarking…" else "Run benchmark") }
            if (settings.lastBenchmark.isNotBlank()) {
                Text(settings.lastBenchmark, color = J.Good, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 6.dp))
            }
        }
    }

    confirmDelete?.let { spec ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete ${spec.name}?") },
            text = { Text("The downloaded file is removed from this phone. You can download it again later.") },
            confirmButton = {
                Button(onClick = { vm.deleteModel(spec); confirmDelete = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }
}

private fun loadText(s: LoadState) = when (s) {
    LoadState.Unloaded -> "Not loaded in memory."
    is LoadState.Loading -> "Loading ${s.modelName}…"
    is LoadState.Ready -> "Ready: ${s.modelName} on ${s.backend}, loaded in ${s.loadMs} ms."
    is LoadState.Error -> "Error: ${s.message}"
}

private fun statusLine(st: ModelStatus): String = when (val d = st.download) {
    is DownloadState.Running -> "Downloading… ${mb(d.done)}" + if (d.total > 0) " of ${mb(d.total)}" else ""
    is DownloadState.Paused -> "Paused at ${mb(d.done)}"
    DownloadState.Verifying -> "Verifying integrity…"
    is DownloadState.Failed -> "Failed: ${d.message}"
    DownloadState.Idle ->
        if (st.installedBytes != null) "Installed (${mb(st.installedBytes)})"
        else "Not downloaded" + if (st.spec.approxBytes > 0) " (about ${mb(st.spec.approxBytes)})" else ""
}

@Composable
private fun DownloadControls(st: ModelStatus, c: AppContainer, vm: MainViewModel, onDelete: () -> Unit) {
    val d = st.download
    if (d is DownloadState.Running) {
        if (d.total > 0) {
            LinearProgressIndicator(
                progress = { (d.done.toFloat() / d.total).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            )
        } else {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp))
        }
    } else if (d is DownloadState.Verifying) {
        LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
        when {
            d is DownloadState.Running -> {
                OutlinedButton(onClick = { c.models.pause(st.spec.id) }) { Text("Pause") }
                OutlinedButton(onClick = { c.models.cancel(st.spec) }) { Text("Cancel") }
            }
            d is DownloadState.Verifying -> Unit
            d is DownloadState.Paused || d is DownloadState.Failed -> {
                Button(onClick = { c.models.start(st.spec) }) { Text("Resume") }
                OutlinedButton(onClick = { c.models.cancel(st.spec) }) { Text("Discard") }
            }
            st.installedBytes != null -> OutlinedButton(onClick = onDelete) { Text("Delete") }
            else -> Button(onClick = { c.models.start(st.spec) }) { Text("Download") }
        }
        if (st.spec.custom && st.installedBytes == null && d is DownloadState.Idle) {
            TextButton(onClick = { vm.deleteModel(st.spec) }) { Text("Remove from list") }
        }
    }
}
