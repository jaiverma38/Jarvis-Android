package com.jarvis.assistant.ai

import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.security.SecretNames
import com.jarvis.assistant.security.SecureKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class ApiException(val code: Int) : IOException("HTTP $code") {
    /** Never includes the response body, which could echo request details. */
    fun friendly(): String = when (code) {
        400 -> "The provider rejected the request (400). Check the model name."
        401, 403 -> "The provider rejected your API key (HTTP $code)."
        404 -> "Model or endpoint not found (404). Check the model name and base URL."
        429 -> "Rate limit or quota reached (429). Try again later."
        in 500..599 -> "The provider had a server problem (HTTP $code)."
        else -> "The provider returned HTTP $code."
    }
}

internal object Http {
    private const val MAX_RESPONSE = 1_000_000

    fun postJson(url: String, headers: Map<String, String>, body: String): String {
        val u = URL(url)
        require(u.protocol == "https") { "Only HTTPS endpoints are allowed." }
        val c = u.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 90_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) throw ApiException(code)
            return c.inputStream.use { readCapped(it) }
        } finally {
            c.disconnect()
        }
    }

    /** Plain GET over HTTPS for the keyless web-search helpers. Short timeouts, capped size. */
    fun getText(url: String, timeoutMs: Int = 6_000, accept: String = "application/json"): String {
        val u = URL(url)
        require(u.protocol == "https") { "Only HTTPS endpoints are allowed." }
        val c = u.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", "JarvisAssistant/1.0 (personal Android app)")
            c.setRequestProperty("Accept", accept)
            val code = c.responseCode
            if (code !in 200..299) throw ApiException(code)
            return c.inputStream.use { readCapped(it) }
        } finally {
            c.disconnect()
        }
    }

    private fun readCapped(input: InputStream): String {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > MAX_RESPONSE) throw IOException("Response too large.")
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }
}

/** Google Gemini over HTTPS. The key is read from the encrypted store at call time only. */
class GeminiProvider(
    private val settings: SettingsStore,
    private val secrets: SecureKeyStore
) : AiProvider {
    override val id = "gemini"
    override val label = "Gemini (online)"

    fun isConfigured() = secrets.has(SecretNames.GEMINI) && settings.current.geminiModel.isNotBlank()

    override fun generate(request: ChatRequest): Flow<String> = flow {
        val key = secrets.get(SecretNames.GEMINI)
            ?: throw IllegalStateException("No Gemini API key saved. Add one in Settings.")
        val model = settings.current.geminiModel.trim()
        require(model.matches(Regex("[A-Za-z0-9._-]{1,80}"))) { "Invalid Gemini model name." }

        val contents = JSONArray()
        for (t in request.history) contents.put(part(if (t.isUser) "user" else "model", t.text))
        contents.put(part("user", request.userText))
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", request.systemPrompt)))
            )
            .put("contents", contents)

        val response = withContext(Dispatchers.IO) {
            try {
                Http.postJson(
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                    mapOf("x-goog-api-key" to key),
                    body.toString()
                )
            } catch (e: ApiException) {
                throw IllegalStateException(e.friendly())
            }
        }
        val parts = JSONObject(response).optJSONArray("candidates")
            ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val text = buildString {
            if (parts != null) for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
        }.trim()
        emit(text.ifBlank { "Gemini returned no answer. It may have been blocked by a safety filter." })
    }

    private fun part(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))
}

/**
 * Any OpenAI-compatible chat endpoint over HTTPS (for example NVIDIA's integrate.api.nvidia.com/v1
 * or OpenRouter). The user supplies base URL, model name and key.
 */
class OpenAiCompatProvider(
    private val settings: SettingsStore,
    private val secrets: SecureKeyStore
) : AiProvider {
    override val id = "openai-compat"
    override val label = "Cloud API (online)"

    fun isConfigured(): Boolean {
        val s = settings.current
        return secrets.has(SecretNames.OPENAI_COMPAT) &&
            s.openAiModel.isNotBlank() &&
            s.openAiBaseUrl.trim().startsWith("https://")
    }

    override fun generate(request: ChatRequest): Flow<String> = flow {
        val key = secrets.get(SecretNames.OPENAI_COMPAT)
            ?: throw IllegalStateException("No API key saved. Add one in Settings.")
        val s = settings.current
        val base = s.openAiBaseUrl.trim().trimEnd('/')
        require(base.startsWith("https://")) { "Base URL must start with https://" }

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", request.systemPrompt))
        for (t in request.history) {
            messages.put(JSONObject().put("role", if (t.isUser) "user" else "assistant").put("content", t.text))
        }
        messages.put(JSONObject().put("role", "user").put("content", request.userText))
        val body = JSONObject()
            .put("model", s.openAiModel.trim())
            .put("messages", messages)
            .put("stream", false)
            .put("max_tokens", 512)

        val response = withContext(Dispatchers.IO) {
            try {
                Http.postJson("$base/chat/completions", mapOf("Authorization" to "Bearer $key"), body.toString())
            } catch (e: ApiException) {
                throw IllegalStateException(e.friendly())
            }
        }
        val text = JSONObject(response).optJSONArray("choices")
            ?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty().trim()
        emit(text.ifBlank { "The provider returned an empty answer." })
    }
}
