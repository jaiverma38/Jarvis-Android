package com.jarvis.assistant.ai

import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.security.SecretNames
import com.jarvis.assistant.security.SecureKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class ApiException(val code: Int) : IOException("HTTP $code") {
    /** Never includes the response body, which could echo request details. */
    fun friendly(): String = when (code) {
        400 -> "The provider rejected the request (400). Check the model name."
        401, 403 -> "The provider rejected your API key (HTTP $code)."
        404 -> "Model or endpoint not found (404). Check the model name and base URL."
        429 -> "Rate limit or quota reached (429). Try again later."
        in 500..599 -> "The provider had a server problem (HTTP $code)."
        else -> "The provider returned HTTP $code."
    }
}

internal object Http {
    private const val MAX_RESPONSE = 1_000_000

    /** Plain HTTP is allowed only for a device on your own local network (another phone running the Jarvis API). */
    fun isLanHost(host: String): Boolean {
        val h = host.lowercase()
        if (h.endsWith(".local")) return true
        // Tailscale's private network (traffic between your devices is encrypted by Tailscale itself).
        if (h.endsWith(".ts.net")) return true
        val p = h.split('.').mapNotNull { it.toIntOrNull() }
        if (p.size != 4) return false
        return p[0] == 10 || (p[0] == 192 && p[1] == 168) || (p[0] == 172 && p[1] in 16..31) ||
            (p[0] == 100 && p[1] in 64..127)
    }

    fun postJson(url: String, headers: Map<String, String>, body: String): String {
        val u = URL(url)
        require(u.protocol == "https" || (u.protocol == "http" && isLanHost(u.host))) {
            "Only HTTPS endpoints are allowed (plain HTTP only for devices on your own Wi-Fi or Tailscale)."
        }
        val c = u.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 90_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) throw ApiException(code)
            return c.inputStream.use { readCapped(it) }
        } finally {
            c.disconnect()
        }
    }

    /** Plain GET over HTTPS for the keyless web-search helpers. Short timeouts, capped size. */
    fun getText(
        url: String,
        timeoutMs: Int = 6_000,
        accept: String = "application/json",
        headers: Map<String, String> = emptyMap()
    ): String {
        val u = URL(url)
        require(u.protocol == "https") { "Only HTTPS endpoints are allowed." }
        val c = u.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", "JarvisAssistant/1.0 (personal Android app)")
            c.setRequestProperty("Accept", accept)
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val code = c.responseCode
            if (code !in 200..299) throw ApiException(code)
            return c.inputStream.use { readCapped(it) }
        } finally {
            c.disconnect()
        }
    }

    private fun readCapped(input: InputStream): String {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > MAX_RESPONSE) throw IOException("Response too large.")
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }
}

/** Google Gemini over HTTPS. The key is read from the encrypted store at call time only. */
class GeminiProvider(
    private val settings: SettingsStore,
    private val secrets: SecureKeyStore
) : AiProvider {
    override val id = "gemini"
    override val label = "Gemini (online)"

    fun isConfigured() = secrets.has(SecretNames.GEMINI) && settings.current.geminiModel.isNotBlank()

    fun hasKey() = secrets.has(SecretNames.GEMINI)

    override fun generate(request: ChatRequest): Flow<String> = flow {
        val model = settings.current.geminiModel.trim()
        val text = try {
            call(model, request)
        } catch (e: ApiException) {
            throw IllegalStateException(e.friendly())
        }
        emit(text.ifBlank { "Gemini returned no answer. It may have been blocked by a safety filter." })
    }

    /** One call to one named model. Throws [ApiException] with the HTTP code so a caller can switch models. */
    suspend fun call(model: String, request: ChatRequest): String {
        val key = secrets.get(SecretNames.GEMINI)
            ?: throw IllegalStateException("No Gemini API key saved. Add one in Settings.")
        require(model.matches(Regex("[A-Za-z0-9._-]{1,80}"))) { "Invalid Gemini model name." }

        // Gemma models do not accept a separate system instruction: fold it into the first message.
        val foldSystem = model.startsWith("gemma", ignoreCase = true)
        val contents = JSONArray()
        var first = true
        val turns = request.history.map { (if (it.isUser) "user" else "model") to it.text } +
            ("user" to request.userText)
        for ((role, text) in turns) {
            val t = if (foldSystem && first && role == "user") request.systemPrompt + "\n\n" + text else text
            if (first && foldSystem && role != "user") contents.put(part("user", request.systemPrompt))
            contents.put(part(role, t))
            first = false
        }
        val body = JSONObject().put("contents", contents)
        if (!foldSystem) {
            body.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", request.systemPrompt)))
            )
        }

        val response = withContext(Dispatchers.IO) {
            Http.postJson(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                mapOf("x-goog-api-key" to key),
                body.toString()
            )
        }
        val parts = JSONObject(response).optJSONArray("candidates")
            ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        return buildString {
            if (parts != null) for (i in 0 until parts.length()) {
                val po = parts.optJSONObject(i) ?: continue
                if (po.optBoolean("thought", false)) continue
                append(po.optString("text"))
            }
        }.trim()
    }

    /** Asks Google which models this key can use (generateContent only). Returns model ids like "gemini-3.8-flash". */
    suspend fun listModels(): List<String> {
        val key = secrets.get(SecretNames.GEMINI)
            ?: throw IllegalStateException("No Gemini API key saved. Add one first.")
        val out = ArrayList<String>()
        var token = ""
        repeat(5) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200" +
                (if (token.isNotEmpty()) "&pageToken=$token" else "")
            val text = withContext(Dispatchers.IO) {
                try {
                    Http.getText(url, 10_000, "application/json", mapOf("x-goog-api-key" to key))
                } catch (e: ApiException) {
                    throw IllegalStateException(e.friendly())
                }
            }
            val o = JSONObject(text)
            val arr = o.optJSONArray("models") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                var ok = false
                for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
                if (ok) out.add(m.optString("name").removePrefix("models/"))
            }
            token = o.optString("nextPageToken")
            if (token.isEmpty()) return out
        }
        return out
    }

    private fun part(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))
}

/**
 * Any OpenAI-compatible chat endpoint over HTTPS (for example NVIDIA's integrate.api.nvidia.com/v1
 * or OpenRouter). The user supplies base URL, model name and key.
 */
class OpenAiCompatProvider(
    private val settings: SettingsStore,
    private val secrets: SecureKeyStore
) : AiProvider {
    override val id = "openai-compat"
    override val label: String
        get() = "Cloud · ${settings.current.openAiModel.trim().substringAfterLast('/').ifBlank { "online" }}"

    fun isConfigured(): Boolean {
        val s = settings.current
        return secrets.has(SecretNames.OPENAI_COMPAT) &&
            s.openAiModel.isNotBlank() &&
            (s.openAiBaseUrl.trim().startsWith("https://") ||
                (s.openAiBaseUrl.trim().startsWith("http://") &&
                    Http.isLanHost(s.openAiBaseUrl.trim().removePrefix("http://").substringBefore('/').substringBefore(':'))))
    }

    override fun generate(request: ChatRequest): Flow<String> = flow {
        val text = try {
            call(request)
        } catch (e: ApiException) {
            throw IllegalStateException(e.friendly())
        }
        emit(text.ifBlank { "The provider returned an empty answer." })
    }

    /** Throws [ApiException] with the HTTP code so a caller can switch to another provider. */
    suspend fun call(request: ChatRequest): String {
        val key = secrets.get(SecretNames.OPENAI_COMPAT)
            ?: throw IllegalStateException("No API key saved. Add one in Settings.")
        val s = settings.current
        val base = s.openAiBaseUrl.trim().trimEnd('/')
        require(base.startsWith("https://")) { "Base URL must start with https://" }

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", request.systemPrompt))
        for (t in request.history) {
            messages.put(JSONObject().put("role", if (t.isUser) "user" else "assistant").put("content", t.text))
        }
        messages.put(JSONObject().put("role", "user").put("content", request.userText))
        val body = JSONObject()
            .put("model", s.openAiModel.trim())
            .put("messages", messages)
            .put("stream", false)
            .put("max_tokens", 1024)
        // gpt-oss models "think" first and the thinking counts against max_tokens: keep it short.
        if (s.openAiModel.contains("gpt-oss", ignoreCase = true)) body.put("reasoning_effort", "low")

        val response = withContext(Dispatchers.IO) {
            Http.postJson("$base/chat/completions", mapOf("Authorization" to "Bearer $key"), body.toString())
        }
        return JSONObject(response).optJSONArray("choices")
            ?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty().trim()
    }
}
