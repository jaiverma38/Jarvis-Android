Wake-word model files are downloaded into this folder by the GitHub Actions workflow before the build.
See NOTICE.md (openWakeWord models: CC BY-NC-SA 4.0, non-commercial use only).
