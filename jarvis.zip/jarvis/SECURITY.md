# Security design

- **No code execution from AI.** The model's text is never parsed into actions. Phone actions come only from
  `CommandParser` (fixed rules on what the user said or typed) and run through an allowlisted `Action` type.
  There is no shell, no `Runtime.exec`, no dynamic code loading, no accessibility service.
- **Confirmation.** Brightness changes, opening the dialer or an SMS draft, reading notifications and saving
  memories need an on-screen Confirm tap. JARVIS never places calls or sends SMS by itself (no CALL_PHONE or
  SEND_SMS permission is declared).
- **Offline means offline.** In Offline mode the AI provider is the on-device model only. There is no automatic
  fallback to the internet in any mode.
- **Data at rest.** Chats, titles, memories and API keys are encrypted with AES-256-GCM using a non-exportable
  Android Keystore key. Cloud backup and device transfer are disabled.
- **Network.** HTTPS only (cleartext blocked by network security config and by code). Model downloads follow
  redirects manually, refuse non-HTTPS hops and verify SHA-256 against the hash Hugging Face publishes when present.
- **Logging.** The app writes no message text, keys or notification content to logcat or files. The audit log
  stores action names only (phone numbers reduced to the last two digits).
- **API keys.** Entered by the user, stored encrypted, sent only to the chosen provider (in a header, not in the URL).
  A key bundled in an APK can always be extracted, so none is bundled.
- **Microphone.** Two modes, both visible: push-to-talk (orb) and an optional, off-by-default "Hey Jarvis" listener. The wake listener keeps a permanent notification with a Turn off button, runs a small on-device model on 80 ms pieces of audio held only in memory, writes nothing to disk, sends nothing anywhere, and releases the microphone as soon as the phrase is heard. It switches itself off on any error rather than pretend to listen.
  Speech recognition is performed by the phone's system speech service; JARVIS cannot guarantee whether that
  service processes audio on the device or on Google's servers.
- **Speaker identification.** Not implemented. Anyone who can unlock and use the phone can use JARVIS.

## Reporting a problem

Open an issue in your repository, or describe the problem privately to the repository owner.
