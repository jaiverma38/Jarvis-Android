// JARVIS gateway for Cloudflare Workers (free plan). Any device can use your Gemini (Google AI Studio) and
// Groq keys through YOUR OWN Jarvis key. The real keys stay secret inside Cloudflare.
//
// Secrets (Worker -> Settings -> Variables and Secrets -> Add, type "Secret"):
//   JARVIS_KEY     : any long random text you choose; this is "your Jarvis key" for all your devices
//   GEMINI_API_KEY : your Google AI Studio key (optional if you add the Groq key)
//   GROQ_API_KEY   : your Groq key (optional if you add the Gemini key)
// Optional plain variables:
//   GEMINI_MODELS  : comma separated, tried in order. Default below.
//   GROQ_MODELS    : comma separated, tried in order after Gemini. Default below.
//
// Auto-switch: the model name "jarvis" (or "jarvis-online") tries every Gemini model, then every Groq model.
// If one answers 429 (limit reached), 404 (no such model), 5xx or a network error, the next one is tried.
// Endpoints (OpenAI compatible):  GET /v1/models   POST /v1/chat/completions

const GEMINI = "https://generativelanguage.googleapis.com/v1beta/openai";
const GROQ = "https://api.groq.com/openai/v1";
const DEFAULT_GEMINI = ["gemini-3.8-flash", "gemini-3.6-flash", "gemini-3-flash", "gemini-2.5-flash",
  "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-2.5-flash-lite"];
const DEFAULT_GROQ = ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"];
const NAME_OK = /^[A-Za-z0-9._\/-]{1,80}$/;

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", ...cors } });
const err = (message, status, type) => json({ error: { message, type } }, status);

function same(a, b) { // compares without stopping at the first difference
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
const list = (text, dflt) => {
  const l = (text || "").split(",").map((x) => x.trim()).filter((x) => NAME_OK.test(x));
  return l.length ? l : dflt;
};

// Models that said "limit reached" rest for a while (kept per Worker instance, best effort).
const rest = new Map();
const penalize = (key, status) => {
  const ms = status === 429 ? 65_000 : status === 404 || status === 400 ? 3_600_000 : 30_000;
  rest.set(key, Date.now() + ms);
};
const resting = (key) => (rest.get(key) || 0) > Date.now();

function chain(env) {
  const out = [];
  if (env.GEMINI_API_KEY) for (const m of list(env.GEMINI_MODELS, DEFAULT_GEMINI)) out.push({ kind: "gemini", model: m });
  if (env.GROQ_API_KEY) for (const m of list(env.GROQ_MODELS, DEFAULT_GROQ)) out.push({ kind: "groq", model: m });
  return out;
}

// Gemma models do not take a system message: put it in front of the first user message.
function forModel(body, c) {
  const b = { ...body, model: c.model };
  if (typeof b.max_tokens === "number" && b.max_tokens > 2048) b.max_tokens = 2048;
  if (c.kind === "groq" && c.model.includes("gpt-oss") && !b.reasoning_effort) b.reasoning_effort = "low";
  if (c.kind === "gemini" && c.model.startsWith("gemma") && Array.isArray(b.messages)) {
    const sys = b.messages.filter((m) => m.role === "system").map((m) => m.content).join("\n");
    const rest2 = b.messages.filter((m) => m.role !== "system");
    const i = rest2.findIndex((m) => m.role === "user");
    if (sys && i >= 0) rest2[i] = { ...rest2[i], content: sys + "\n\n" + rest2[i].content };
    b.messages = rest2;
  }
  return b;
}

async function callUpstream(c, body, env) {
  const base = c.kind === "gemini" ? GEMINI : GROQ;
  const key = c.kind === "gemini" ? env.GEMINI_API_KEY : env.GROQ_API_KEY;
  return fetch(base + "/chat/completions", {
    method: "POST",
    headers: { Authorization: "Bearer " + key, "Content-Type": "application/json" },
    body: JSON.stringify(forModel(body, c)),
  });
}

function wrap(upstream, used) {
  const headers = new Headers(upstream.headers);
  Object.entries(cors).forEach(([k, v]) => headers.set(k, v));
  headers.set("X-Jarvis-Model", used);
  return new Response(upstream.body, { status: upstream.status, headers });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (url.pathname === "/" || url.pathname === "/health") return json({ name: "JARVIS gateway", status: "ok" });

    const models = chain(env);
    if (!env.JARVIS_KEY || models.length === 0) {
      return err("Gateway is not configured: add JARVIS_KEY and at least one of GEMINI_API_KEY / GROQ_API_KEY.", 500, "not_configured");
    }
    const given = (request.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "").trim();
    if (!same(given, env.JARVIS_KEY)) return err("Invalid or missing Jarvis key.", 401, "invalid_api_key");

    if (request.method === "GET" && url.pathname === "/v1/models") {
      const data = ["jarvis", ...models.map((m) => m.model)].map((id) => ({ id, object: "model", owned_by: "jarvis" }));
      return json({ object: "list", data });
    }

    if (request.method === "POST" && url.pathname === "/v1/chat/completions") {
      let body;
      try { body = await request.json(); } catch { return err("Body must be JSON.", 400, "invalid_request"); }

      // A specific model that you configured: use only that one.
      const auto = !body.model || body.model === "jarvis" || body.model === "jarvis-online";
      let order;
      if (auto) {
        const ready = models.filter((m) => !resting(m.kind + ":" + m.model));
        order = ready.length ? ready : models;
      } else {
        order = models.filter((m) => m.model === body.model);
        if (!order.length) return err("Model not allowed: " + body.model, 400, "model_not_allowed");
      }

      let last = null;
      for (const c of order) {
        const key = c.kind + ":" + c.model;
        try {
          const up = await callUpstream(c, body, env);
          if (up.ok || (up.status < 500 && up.status !== 429 && up.status !== 404 && !(up.status === 400 && auto))) {
            return wrap(up, c.model);
          }
          penalize(key, up.status);
          last = up.status;
        } catch (e) {
          penalize(key, 503);
          last = 503;
        }
      }
      return err("Every model is busy or unavailable right now (last status " + last + ").", 503, "all_models_unavailable");
    }
    return err("Not found.", 404, "not_found");
  },
};
