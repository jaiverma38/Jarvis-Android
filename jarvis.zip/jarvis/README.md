# JARVIS: personal AI assistant for Android

Kotlin + Jetpack Compose app for the Realme Narzo 20 Pro (Android 12, 8 GB). Offline AI runs on the phone through
Google LiteRT-LM; online AI (Gemini or any OpenAI-compatible API) is optional and uses your own key.
The APK is built by GitHub Actions, so no PC is needed.

> **Status: written but not yet compiled or run.** This project was produced without access to an Android
> toolchain. The first GitHub Actions build is the first real compile. Expect to fix a few compile errors
> (send the log to get them fixed). Nothing here has been tested on a device. See "Known limitations".

## Build the APK from your phone

1. Create a **public** GitHub repository (public repos get free Actions minutes).
2. Upload the project. Two ways:
   - **Unpacked:** unzip on the phone, then in the repo choose *Add file > Upload files* and upload the
     *contents* of the folder (keep the `.github/workflows` folder, a file manager that hides dot-folders may skip it).
   - **Zip route:** upload `jarvis.zip` to the repo root. The zip contains its own `.github` folder, but GitHub only
     runs workflows from the repo's own `.github/workflows`, so first create the file
     `.github/workflows/build-from-zip.yml` by pasting its text (it is inside the zip), then run it from the Actions tab.
3. Open the **Actions** tab > **Android CI** > **Run workflow** (or push to `main`).
4. When it is green, open the run > **Artifacts** > download `jarvis-debug-apk`, unzip, install `app-debug.apk`
   (allow "install unknown apps" for your browser/files app).
5. If the build is red, open the failed step, copy the last ~40 lines of the log and send them back.

## First run on the phone

1. **Models** tab > download *Qwen3 0.6B (INT4)* (about 330 MB, Wi-Fi recommended). Wait for the green SHA-256 line.
2. Tap **Use this model**, then **Run benchmark**. This tells you the real speed on your Helio G95.
   Leave the GPU switch off unless you want to experiment.
3. **Chat** tab: type "hello", or tap the orb (grants the microphone permission the first time).
4. Try: `torch on`, `timer 2 minutes`, `open YouTube`, `volume 40`, `battery`, `open wifi settings`, `help`.
5. **Wake word:** Settings > *Wake word* > switch on (allow the microphone). Say "Hey Jarvis", wait for the beep, then say a command.
6. Optional online AI: **Settings** > choose provider > paste your key > set *AI mode* to Auto or Online.
   For NVIDIA keys choose *OpenAI-compatible*; base URL `https://integrate.api.nvidia.com/v1`; pick a model
   name from NVIDIA's current list (names change).

## What works, and what does not

| Feature | State |
|---|---|
| Chat with on-device model (LiteRT-LM, CPU) | Implemented, untested |
| GPU backend | Switch provided, unverified on Mali-G76 |
| Model download, pause/resume, SHA-256, delete | Implemented, untested |
| Online Gemini / OpenAI-compatible, key in Keystore | Implemented, untested |
| Offline mode never touches the network for AI | By design: provider routing, no fallback |
| Voice in/out (Hindi, English, Hinglish) | Uses Android system speech. Offline recognition depends on the Google app's language packs and **cannot be detected on Android 12**; errors say so |
| Push-to-talk with microphone notification and Stop | Implemented, untested |
| Wake word "Hey Jarvis" (opt-in switch in Settings) | Implemented, untested: openWakeWord model on ONNX Runtime, CPU, audio never stored or sent |
| Recognising only the owner's voice | **Not implemented**; Android has no safe built-in API for it |
| Phone actions: apps, settings, torch, volume, brightness, timer, alarm, device info, dialer/SMS draft | Implemented, untested |
| Notification reading | Opt-in only, memory only |
| Local history, memories, retention, export, delete, audit log | Implemented, untested (encrypted with Keystore) |
| Actions chosen by the AI model itself | **Not implemented on purpose**: only your own clear commands trigger actions |
| "Obeys every command" | No: a safe allowlist is enforced; sensitive actions need your confirmation |
| Iron Man personality | Light persona in the system prompt; a 0.6B model will be basic |

## Known limitations and risks

- A 0.6B model is small: weak reasoning, limited Hindi. Use Gemini/NVIDIA online for quality.
- Speed on the Helio G95 is unknown until you run the benchmark.
- The app asks for a Qwen "no think" switch (`/no_think`); other models ignore it.
- LiteRT-LM version is `latest.release` (as Google's docs suggest). If a future release changes the API, pin an
  older version in `gradle/libs.versions.toml`.
- If a streamed answer appears with repeated text, the library returns cumulative chunks; tell me and it is a one-line change.
- Dependency versions (Kotlin 2.3.21, KSP 2.3.5, AGP 8.13.0, Compose BOM 2025.09.00, Room 2.7.2) were chosen from
  documentation and not compile-tested. A version mismatch is the most likely first CI failure.
- **Wake word is not Google-grade.** Google runs its detector on a special low-power chip that apps cannot use; JARVIS uses the CPU, so expect extra battery use (check Settings > Battery after a day) and more false or missed wake-ups than Google Assistant. Use the Sensitivity setting to tune it.
- Wake word shows Android's green microphone dot and a permanent notification while on. Android 12 only lets a microphone service *start* while the app is visible, so after a reboot (or if the system kills it) open JARVIS once.
- The wake word only reacts to the phrase, not to who says it. Loud music, calls or other apps using the mic can block it.
- The three wake-word model files (openWakeWord, CC BY-NC-SA 4.0: personal, non-commercial use) are downloaded from the openWakeWord GitHub release by the Actions workflow. If that download step fails (red build), send me the log.
- Only HTTPS model links work; models that need a Hugging Face login are not supported.

## Signed release build

1. Create a keystore (on a phone use an online-free method such as Termux: `keytool -genkeypair -v -keystore release.jks -alias jarvis -keyalg RSA -keysize 2048 -validity 10000`). Keep it private and backed up. **Never upload it to the repo** (`.gitignore` blocks `*.jks`).
2. Make base64 text: `base64 -w0 release.jks`.
3. In the repo: *Settings > Secrets and variables > Actions > New repository secret*, add
   `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
4. *Actions > Release APK (signed) > Run workflow*. Download `jarvis-release-apk`.

Debug APKs are signed with a throwaway debug key and are fine for personal use.

## Project layout

```
app/src/main/java/com/jarvis/assistant/
  JarvisApp.kt, MainActivity.kt, MainViewModel.kt
  ai/         AiProvider, LiteRtProvider, OnlineProviders, ModelRegistry, ModelManager, ChatEngine
  voice/      VoiceController, ListeningService
  actions/    Action, CommandParser, ActionRouter
  notifications/ JarvisNotificationListener
  data/       Room entities/DAOs, ChatRepository, SettingsStore
  security/   KeystoreCrypto, SecureKeyStore, AuditLog
  ui/         Theme, Orb, Chat/History/Models/Privacy/Settings screens
```

See `SECURITY.md` for the security design and `NOTICE.md` for licenses.
