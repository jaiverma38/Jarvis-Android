# Third-party notices

JARVIS is an independent project. It is not affiliated with or endorsed by Marvel, Disney or any
rights holder of the "Iron Man" franchise; the name and look are an homage only.

## Libraries (all fetched by Gradle at build time, not copied into this repository)

| Component | License |
|---|---|
| Google LiteRT-LM (`com.google.ai.edge.litertlm:litertlm-android`) | Apache-2.0 |
| AndroidX (Core, Activity, Lifecycle, Compose, Room, WorkManager) | Apache-2.0 |
| Kotlin and kotlinx.coroutines | Apache-2.0 |
| KSP | Apache-2.0 |

## Language model (downloaded by the user on demand, never bundled in the APK)

| Model | Source | License |
|---|---|---|
| Qwen3-0.6B (LiteRT-LM conversion) | huggingface.co/litert-community/Qwen3-0.6B | Apache-2.0 (as stated on the model card) |

Models added by link in the app are the user's responsibility: JARVIS cannot check their license.

## Wake-word models (downloaded into the APK by the GitHub Actions build, not stored in this repository)

| Component | Source | License |
|---|---|---|
| openWakeWord `melspectrogram.onnx`, `embedding_model.onnx`, `hey_jarvis_v0.1.onnx` | github.com/dscripka/openWakeWord (release v0.5.1) | **CC BY-NC-SA 4.0**: non-commercial use only, attribution and share-alike |
| Microsoft ONNX Runtime (`onnxruntime-android`) | github.com/microsoft/onnxruntime | MIT |

Personal use is fine. Do not sell or commercially distribute an APK that contains the wake-word models.
The embedding model is a re-implementation of Google's speech embedding model by the openWakeWord author.

## Online services

Gemini and any OpenAI-compatible API are used only if you select them and enter your own key.
Their terms and privacy policies apply to what you send them.
